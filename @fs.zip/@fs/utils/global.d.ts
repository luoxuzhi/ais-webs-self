declare interface Window {
    sjcl: any
    clientKey: any
    clientNonce: any
    decrypt: any
}

declare module 'asmcrypto.js'
declare module 'universal-cookie'
declare module 'js-crypto-hash'
declare module 'js-crypto-hkdf'
declare module '@fs/utils/crypto'
declare module 'sjcl'
