// 参考文档：https://www.rollupjs.com/guide/command-line-reference

import ts from 'rollup-plugin-typescript2'
import { terser } from 'rollup-plugin-terser'
import clear from 'rollup-plugin-clear'
import resolve from '@rollup/plugin-node-resolve'
import commonjs from '@rollup/plugin-commonjs'
import json from '@rollup/plugin-json'
import nodePolyfills from 'rollup-plugin-polyfill-node'

const chunksMap = {
    commonjsHelpers: ['commonjsHelpers'],
    core: ['crypto\\core.ts'],
    AES: ['crypto\\AES.ts'],
    ECDH: ['crypto\\ECDH.ts'],
    SIGN: ['crypto\\sign.ts'],
}

export default {
    input: 'index.ts',
    output: [
        {
            name: 'fs-utils.umd.js',
            file: 'dist/fs-utils.umd.js',
            format: 'umd', // 输出类型 (amd, cjs, es, iife, umd, system)
        },
        {
            dir: 'dist',
            name: 'fs-utils.esm.js',
            format: 'es', // 输出类型 (amd, cjs, es, iife, umd, system)
            entryFileNames: 'fs-utils.esm.js',
            manualChunks: id => {
                const matchedChunk = Object.entries(chunksMap).find(([, keywords]) => keywords.some(module => id.includes(module)))
                if (matchedChunk) return matchedChunk[0]
            },
        },
    ],
    plugins: [
        clear({
            // 清除文件夹
            targets: ['dist', 'types'],
        }),
        // 外部模块支持
        resolve({
            preferBuiltins: true,
        }),
        // node拓展
        nodePolyfills(),
        // 支持commonjs
        // https://www.npmjs.com/package/@rollup/plugin-commonjs#transformmixedesmodules
        commonjs({
            // requireReturnsDefault: 'auto',
            // transformMixedEsModules: true,
        }),
        // 支持json
        json(),
        // ts编译
        ts(),
        // 压缩
        terser(),
    ],
}
