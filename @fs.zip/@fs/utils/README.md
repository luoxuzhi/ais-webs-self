# @fs/utils

@fs/utils 是一个工具库，包括前端常见场景的解决方案

---

## 快速开始

### 主页

http://gl.fotechwealth.com.local/H5/common/tree/release/projects/@fs-utils

### 安装

```bash
yarn add @fs/utils

```

### API

[API 文档](http://gl.fotechwealth.com.local/H5/common/tree/release/projects/@fs-utils/doc)
