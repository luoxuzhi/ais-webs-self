import { AESCrypto } from './AES'
import { hex_to_bytes, string_to_bytes, bytes_to_string, bytes_to_base64 } from 'asmcrypto.js'
import { compute } from 'js-crypto-hkdf'
import Hash from 'js-crypto-hash'
import { KEYUTIL, KJUR } from 'jsrsasign'
import elliptic from 'elliptic'

import { default_crypto_keys } from './config'

const EC = elliptic.ec
const ec = new EC('p384')

interface GetECDHAndLocalKeyParams {
    localKey?: elliptic.ec.KeyPair
    server_ecdh_key?: elliptic.ec.KeyPair
}

interface ECDHResult {
    errorRes?: any
    clientNonce: string
    serverNonce: string
    serverPublicKey: string
    signature: string
    localKey?: GetECDHAndLocalKeyParams['localKey']
    cdata: string
}

export class ECDHCrypto extends AESCrypto {
    // ECDH服务端公钥
    protected server_public_key_base64: string
    // ECDSA签名密钥
    protected sign_public_key_base64: string

    protected server_key: elliptic.ec.KeyPair

    protected verify_key: elliptic.ec.KeyPair

    protected ec = ec

    // 项目传入密钥
    constructor(cryptoKeys?: { server_public_key_base64: string; sign_public_key_base64: string }) {
        super()
        const {
            server_public_key_base64 = default_crypto_keys.server_public_key_base64,
            sign_public_key_base64 = default_crypto_keys.sign_public_key_base64,
        } = cryptoKeys ?? {}

        this.server_public_key_base64 = server_public_key_base64
        this.sign_public_key_base64 = sign_public_key_base64

        const key2Pem = (key: string): any => KEYUTIL.getKey(this.formatAsPem(key))
        this.server_key = this.ec.keyFromPublic(key2Pem(this.server_public_key_base64).pubKeyHex, 'hex')
        this.verify_key = this.ec.keyFromPublic(key2Pem(this.sign_public_key_base64).pubKeyHex, 'hex')
    }

    /**
     * 获取Base64 pem格式公私钥
     * @param {String} hex 公私钥的Hex字符串
     * @returns pem
     */
    BinToPem = (hex: string): string => {
        const sequence = new KJUR.asn1.DERSequence({
            array: [
                new KJUR.asn1.DERObjectIdentifier({ oid: '1.2.840.10045.2.1' }), // ecPublicKey
                new KJUR.asn1.DERObjectIdentifier({ oid: '1.3.132.0.34' }), // P-384
            ],
        })
        const bit_string = new KJUR.asn1.DERBitString({
            hex: '0x' + hex,
        })
        const seq = new KJUR.asn1.DERSequence({
            array: [sequence as any, bit_string],
        }) as any
        return bytes_to_base64(hex_to_bytes(seq.getEncodedHex()))
    }

    // 填充key
    padUint8Array = (array, paddingByte, targetLength) => {
        // 计算需要填充的字节数
        const paddingBytes = targetLength - array.length
        if (paddingBytes <= 0) {
            return array
        }

        // 创建一个缺失长度的 Uint8Array，
        const paddedArray = new Uint8Array(targetLength).fill(paddingByte)

        for (let i = paddingBytes; i < paddedArray.length; i++) {
            paddedArray[i] = array[i - 1]
        }

        console.error('paddingBytes error ====>', paddingBytes, paddedArray)

        return paddedArray
    }

    // 获取临时会话密钥及客户端公私钥
    GetECDHAndLocalKey = async (keys?: GetECDHAndLocalKeyParams) => {
        let { localKey = null, server_ecdh_key = null } = keys ?? {}
        localKey = localKey || this.ec.genKeyPair()
        server_ecdh_key = server_ecdh_key || this.server_key
        const shared = localKey.derive(server_ecdh_key.getPublic())
        let shared_key_bytes = hex_to_bytes(shared.toString('hex'))
        const SHARED_LENGTH = 48 // 与后端协定的key的长度
        shared_key_bytes = this.padUint8Array(shared_key_bytes, 0x00, SHARED_LENGTH)
        const derivedKey = await compute(
            shared_key_bytes,
            'SHA-256',
            32,
            '',
            new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
        )
        const ECDHKey: string = bytes_to_string(derivedKey.key)
        // console.log('🚀 ~ ECDHCrypto ~ GetECDHAndLocalKey= ~ ECDHKey:', ECDHKey)
        return { ECDHKey, localKey }
    }

    /**
     * 临时会话密钥加密
     * @param {Object} data 需要加密的对象
     * @param {String} ECDHKey  临时会话协商秘钥
     * @param {String} localKey  客户端公私钥对
     */
    ECDHEncrypt = (data: any, ECDHKey: string, localKey: GetECDHAndLocalKeyParams['localKey']) => {
        const cdata = this.AESEncrypt(data, ECDHKey)
        data = Object.assign({}, data)
        data.params = {
            kver: 1,
            cdata,
            clientPublicKey: this.BinToPem(localKey?.getPublic('hex') ?? ''),
            clientNonce: this.createUUID(),
        }
        return data
    }

    // 临时会话返回数据验证及解密
    ECDHVerifyAndDecrypt = async <T = any>(params: ECDHResult): Promise<T> => {
        let result = params.errorRes ?? { jsonrpc: '2.0', id: '', error: { code: 100003, msg: 'Decrypt error' } }
        let msgNonce = Array.from(string_to_bytes(params.clientNonce))
        msgNonce = msgNonce.concat.apply(msgNonce, [
            Array.from(string_to_bytes(params.serverNonce)),
            Array.from(string_to_bytes(params.serverPublicKey)),
        ])
        const hashSign = await Hash.compute(new Uint8Array(msgNonce as any[]), 'SHA-384')
        if (this.verify_key.verify(hashSign, params.signature)) {
            const server_ecdh_key = this.ec.keyFromPublic((KEYUTIL.getKey(this.formatAsPem(params.serverPublicKey)) as any).pubKeyHex, 'hex')
            const { ECDHKey } = await this.GetECDHAndLocalKey({ localKey: params.localKey, server_ecdh_key })
            result = JSON.parse(this.AESDecrypt(params.cdata, ECDHKey))
        }
        return result
    }
}
