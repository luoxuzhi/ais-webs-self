/* eslint-disable no-bitwise */
/* eslint-disable no-plusplus */
/* eslint-disable new-cap */

import { v4 as uuidv4, v5 as uuidv5 } from 'uuid'

export abstract class CryptoCore {
    /**
     * 创建uuid5
     * @param {string} uin
     * @returns string
     */
    createUUID = (uin: string = '') => {
        return uuidv5(uin + new Date().valueOf() + '', uuidv4())
            .split('-')
            .join('')
    }

    /**
     * 公钥 base64字符串转成标准的pem格式
     * @param {string} str 公钥
     * @returns {string}
     */
    formatAsPem = (strPub: string) => {
        let str = strPub
        const typeString = 'PUBLIC KEY'
        let finalString = `-----BEGIN ${typeString}-----\n`
        while (str.length > 0) {
            finalString += `${str.substring(0, 64)}\n`
            str = str.substring(64)
        }
        finalString = `${finalString}-----END ${typeString}-----`
        return finalString
    }

    /**
     * 获取指定长度的字符串(数字+字母)
     * @param n 长度
     * @returns 字符串
     */
    getRndStr = (n: number, ishex: boolean = false) => {
        let str = ''
        // 若是16进制，则取前6个字母
        const letterNum = ishex ? 6 : 26
        const total = ishex ? 22 : 62
        const upperNum = ishex ? 16 : 36
        for (let i = 0; i < n; i++) {
            const tmp = Math.floor(Math.random() * total)
            if (tmp < 10) {
                // 数字
                str += Math.floor(Math.random() * 10)
            } else if (tmp < upperNum) {
                // 大写字母
                str += String.fromCharCode(Math.floor(65 + Math.random() * letterNum))
            } else {
                // 小写字母
                str += String.fromCharCode(Math.floor(97 + Math.random() * letterNum))
            }
        }
        return str
    }

    isString = o => {
        return Object.prototype.toString.call(o).slice(8, -1) === 'String'
    }

    //生成随机数代码
    getArrayRound = (length = 12) => {
        const arr = [] as number[]
        for (let i = 0; i < length; i++) {
            const randomNum6 = Math.round(Math.random() * 128)
            arr.push(randomNum6)
        }
        return arr
    }

    // oss额外转换
    ossEncodeTool = (str: string) => {
        // 对字符串进行编码
        const encode = encodeURI(str)
        // 对编码的字符串转化base64
        const base64 = Buffer.from(encode, 'utf8').toString('base64')
        return base64
    }

    // protected IV = this.getRndStr(12)
}
