import { CryptoCore } from './core'
import { bytes_to_base64, string_to_bytes, AES_GCM, base64_to_bytes, bytes_to_string } from 'asmcrypto.js'
import SJCL from './sjcl'

// 在SJCL引入之后再引入
import 'sjcl/core/codecBytes'
import 'sjcl/core/hkdf'

export class AESCrypto extends CryptoCore {
    // AES-GCM-256 加密函数
    AESEncrypt = (word: any, key: string): string => {
        word = this.isString(word) ? word : JSON.stringify(word)
        const text = string_to_bytes(word, true)
        key = this.isString(key) ? string_to_bytes(key) : key
        const nonce = new Uint8Array(this.getArrayRound())
        const encText = AES_GCM.encrypt(text, key, nonce)
        return bytes_to_base64(new Uint8Array(Array.from(nonce).concat(Array.from(encText))))
    }

    // AES-GCM-256 解密函数
    AESDecrypt = (cipherText: string, cipherKey: string) => {
        const cipher_int_array = Array.from(base64_to_bytes(cipherText)) as any[]
        const cipherNonce = new Uint8Array(cipher_int_array.slice(0, 12))
        const cipherTextArr = new Uint8Array(cipher_int_array.slice(12))
        cipherKey = string_to_bytes(cipherKey)
        const rst = AES_GCM.decrypt(cipherTextArr, cipherKey, cipherNonce)
        return bytes_to_string(rst, true)
    }

    // AES-GCM-256 OSS授权码加密
    // https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001000651@toc23
    // authorize = Base64（AES(Base64(鉴权内容)+密钥))
    OssEncrypt = (word: any, key: string) => {
        word = this.isString(word) ? word : JSON.stringify(word)
        const text = string_to_bytes(word, true)
        const base64Str = this.ossEncodeTool(bytes_to_base64(text))
        const base64Byte = base64_to_bytes(base64Str)
        key = this.isString(key) ? string_to_bytes(key) : key
        const nonce = new Uint8Array(this.getArrayRound())
        const encText = AES_GCM.encrypt(base64Byte, key, nonce)
        return this.ossEncodeTool(bytes_to_base64(new Uint8Array(Array.from(nonce).concat(Array.from(encText)))))
    }

    // SJCL版本AES加密 用于登录鉴权
    // eslint-disable-next-line max-params
    aesgcmEncrypt = (dataStr, key, dataEncode = 'utf8String', keyEncode = 'utf8String', ad = '', tag = '') => {
        let keyBit
        if (keyEncode === 'bits') {
            keyBit = key
        } else {
            keyBit = SJCL.codec[keyEncode].toBits(key)
        }
        const aes = new SJCL.cipher.aes(keyBit)
        const dataBit = SJCL.codec[dataEncode].toBits(dataStr)
        // const iv = getRndStr(12) // 计数器CTR的初始值，12位utf8字符串
        const iv = this.getRndStr(12) // 计数器CTR的初始值，12位utf8字符串
        console.log('iv', iv)
        const ivBit = SJCL.codec.utf8String.toBits(iv)
        const adBit = SJCL.codec.utf8String.toBits(ad)
        const tlen = tag.length * 4
        const cipherBit = SJCL.mode.gcm.encrypt(aes, dataBit, ivBit, adBit, tlen)
        const cipherByte = SJCL.codec.bytes.fromBits(cipherBit)
        const ivByte = string_to_bytes(iv)
        // const tagByte = string_to_bytes(tag)
        const totalArr = Array.from(ivByte).concat(Array.from(cipherByte))
        // .concat(Array.from(tagByte))
        const totalBit = SJCL.codec.bytes.toBits(totalArr)
        const totalBase64 = SJCL.codec.base64.fromBits(totalBit)
        return totalBase64
    }

    /**
     * 登录鉴权
     * @param {String} phone 手机号
     * @param {String} code  验证码
     * @param {String} salt  盐
     */
    loginEncrypt = (phone, code, salt) => {
        // console.log('loginEncrypt in=============')
        // console.log('phone', phone)
        // console.log('code', code)
        // console.log('salt', salt)
        const count = 10000 // 迭代次数
        const length = 32 * 8 // 输出长度为32个字节
        const S1 = SJCL.misc.pbkdf2(code, salt, count, length)
        // console.log('S1 base64', SJCL.codec.base64.fromBits(S1))
        // const phoneArr: Array<any> = Array.from(stringToBytes(phone))
        // const S1Arr: Array<any> = Array.from(SJCL.codec.bytes.fromBits(S1))
        // const phoneS1 = new Uint8Array(phoneArr.concat(S1Arr))
        // console.log('S1 hex', SJCL.codec.hex.fromBits(S1))
        const phoneHex = SJCL.codec.hex.fromBits(SJCL.codec.utf8String.toBits(phone))
        // console.log('phone hex', phoneHex)
        const phoneS1 = `${phoneHex}${SJCL.codec.hex.fromBits(S1)}`
        const S1PhoneBits = SJCL.codec.hex.toBits(phoneS1)

        const S2 = SJCL.misc.pbkdf2(S1PhoneBits, salt, count, length)
        // console.log('S2 base64', SJCL.codec.base64.fromBits(S2))

        const ts = new Date().getTime().toString()
        // const ts = TS
        const rndkey = this.getRndStr(32)
        // const rndkey = Rndkey
        const data = `${phone} ${SJCL.codec.base64.fromBits(S1)} ${ts} ${rndkey}`
        // console.log('data', data)
        const A1 = this.aesgcmEncrypt(data, S2, 'utf8String', 'bits')
        // console.log('A1', A1)
        return {
            A1,
            rndkey,
        }
    }
}
