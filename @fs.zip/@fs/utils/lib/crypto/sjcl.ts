import SJCL from 'sjcl'

window.sjcl = SJCL

export default SJCL
