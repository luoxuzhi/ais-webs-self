import { bytes_to_hex, HmacSha256, string_to_bytes } from 'asmcrypto.js'

interface SignReqConfig {
    headers: Record<string, string>
    baseURL: string
    url: string
    params: any
    method: string
    rndKey?: string
}
interface SignProxyConfig {
    isDev: boolean
    proxy?: Record<string, any>
}

export class SignCrypto {
    // 从本地代理文件获取请求路由
    getLocalProxyHost = (config: SignReqConfig, proxy: SignProxyConfig['proxy'] = {}) => {
        const serveName =
            Object.keys(proxy).find(key => {
                return config.url.includes(key)
            }) ?? ''

        const targetUrl = proxy[serveName]?.target?.split('//')[1]?.split('/')[0] ?? ''

        return targetUrl.split(':')[0] ?? ''
    }

    /**
     * @获取消息签名
     * @param {Object} config 请求配置
     * @param {String} proxyConfig  本地调试配置
     */
    getXSign = (config: SignReqConfig, proxyConfig: SignProxyConfig) => {
        try {
            // eslint-disable-next-line prefer-const
            let h = config.headers,
                schema,
                host,
                port,
                path

            // 区分是否设置baseUrl，当前未设置
            if (!config.baseURL || config.baseURL === '/') {
                // 请求协议 - 当前固定https
                // schema = location.protocol.split(':')[0]
                schema = 'https'

                // 本地调试环境、部署环境处理
                if (proxyConfig.isDev && proxyConfig.proxy) {
                    host = this.getLocalProxyHost(config, proxyConfig.proxy)
                } else {
                    host = config.url?.split('//')[1]?.split('/')[0]
                }

                // 请求端口 - 当前无需包含端口信息
                // port = schema === 'http' ? '80' : '443'
                port = ''

                // 请求uri
                path = (host ? config.url?.split(host)[1] ?? config.url : config.url)?.split('?')[0] ?? ''
            } else {
                schema = config.baseURL.split(':')[0]
                host = config.baseURL.split('//')[1].split(':')[0]
                port = config.baseURL.split('//')[1].split(':')[1] ?? ''
                path = config.url.split('?')[0]
            }

            // query参数处理
            const query = { ...config.params }
            const _queryArray = (config.url.split('?')[1] || '').split('&').filter(item => item)
            _queryArray.forEach(item => {
                query[item.split('=')[0]] = item.split('=')[1]
            })
            const _queryKeySorted = Object.keys(query).sort((a, b) => a.localeCompare(b))
            let query_string = ''
            for (const item of _queryKeySorted) {
                query_string += `&${item}=${query[item]}`
            }
            query_string = encodeURIComponent(decodeURIComponent(query_string.slice(1)))

            // 签名原文
            const headerKeys = [
                'X-uin',
                'X-request-id',
                'X-timestamp',
                'X-device-info',
                'X-lang',
                'X-product',
                'X-antispams',
                'X-session',
                'Content-Type:application/json',
                'X-source',
            ]
            let sign = `${config.method.toUpperCase()}${schema}${port ? `${host}:${port}` : host}${path}${query_string}${headerKeys
                .map(key => {
                    const [k, defaultVal = ''] = key.split(':')
                    return h[k] || (config.method === 'post' ? defaultVal : '')
                })
                .join('')}`
            proxyConfig.isDev && console.log('🚀 ~ sign:', sign)

            // 加密签名
            const hmacSha256 = new HmacSha256(string_to_bytes(config.rndKey || localStorage.getItem('rndKey')))
            sign = bytes_to_hex(hmacSha256.process(string_to_bytes(sign)).finish().result)

            return sign
        } catch (err) {
            console.log('🚀 ~ x-sign err: ', err)
            return ''
        }
    }
}
