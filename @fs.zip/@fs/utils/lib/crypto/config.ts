export const default_crypto_keys = {
    server_public_key_base64:
        'MHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEqUY3ZXGFgYZwBZ0Tyjwl7HDbu/VZrc0RUMnb0aklgsueMERr7CakaLKzDJwIsxEmazM5Dc1FWKl7lHih5damvrFX30UWr6dIIj+9Lu+RpoERsFV2xFZUkNmDxZU65M8t',
    sign_public_key_base64:
        'MHYwEAYHKoZIzj0CAQYFK4EEACIDYgAEus0gY3/seXVTH2+yG6b3Vu0JMPHYp+vvE/TKHjwbHfJPPXd6fOBB24506haT5s8mO6YgI/yK9ov5wxdp7AoR6+m0R6Lh5tWqFxyuXNeDHxPwMogVF0IKuXvuAMfdxTfU',
}
