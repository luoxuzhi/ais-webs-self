// import * as ARMS from 'alife-logger'

// eslint-disable-next-line
import BrowerLogger from 'alife-logger'

export let armsObj = null // arms 实例
export enum ArmsEnvironment {
    prod = 'prod',
    gray = 'gray',
    pre = 'pre',
    daily = 'daily',
    local = 'local',
}

export interface ArmsIgnoreType {
    ignoreUrls?: Array<string | RegExp | Function>
    ignoreApis?: Array<string | RegExp | Function>
    ignoreErrors?: Array<string | RegExp | Function>
    ignoreResErrors?: Array<string | RegExp | Function>
}

export interface ArmsOption {
    /**
     * @参考文档 https://help.aliyun.com/zh/arms/browser-monitoring/developer-reference/sdk-reference?spm=a2c4g.66404.0.i5#sc-setusername
     */
    pid: string // 项目唯一id, fosunhani-h5
    uid?: string //用户ID，用于标识访问用户
    tag?: string //传入的标记，每条日志都会携带该标记。
    page?: string //页面名称。默认取当前页面URL的关键部分：host + pathname
    setUsername?: Function //用于设置一个方法，该方法需要返回类型为string的用户名称。
    enableSPA?: boolean // 监听页面的hashchange事件并重新上报PV，适用于单页面应用场景。
    parseHash?: Function //与enableSPA搭配使用。
    disableHook?: boolean // 禁用自动上报API
    ignoreUrlCase?: boolean //忽略Page URL大小写。
    urlHelper?: any //
    apiHelper?: any
    parseResponse?: Function //用于解析自动上报API时返回的数据。
    ignore?: ArmsIgnoreType
    disabled?: boolean //禁用日志上报功能。
    sample?: number // 对性能日志和成功API日志按照1/sample的比例采样
    pvSample?: number //PV日志采样配置
    sendResource?: boolean // 上报静态资源
    useFmp?: boolean // 采集首屏FMP（First Meaningful Paint，首次有效渲染）数据
    enableLinkTrace?: boolean // 前后端链路追踪
    release?: string // 应用版本号
    environment: ArmsEnvironment | string // 取值为：prod、gray、pre、daily和local
    behavior?: boolean // 记录报错的用户行为
    autoSendPerf?: boolean //是否允许自动发送性能日志。
    appType?: string
    imgUrl?: string // 上报地址
    enableApiCors?: boolean // 允许跨域
    linkType?: string // 链路追踪类型：tracing与链路追踪的Tracing产品做前后端链路打通
}
export interface ArmsInitOption {
    options: ArmsOption
    setConfig?: Function
}
export interface SetArmsHeaderOption<T> {
    headers: T | any
    arms?: any
}
export interface SetArmsHeaderCallback {
    uTraceId: string
    traceId: string
}

export interface ArmsToAxiosOption<T> {
    http: T | any // axios 初始化之后的 http 对象
    arms?: any
}

export interface SendArmsOption {
    response?: any
    error?: any
    arms?: any
}
/**
 * ARMS 初始化
 * @param {Object} options
 * @param {Object} setConfig
 * @returns
 */
export const armsInit = ({ options, setConfig }: ArmsInitOption): any => {
    const defauleOption: ArmsOption = {
        pid: '',
        environment: options.environment || ArmsEnvironment.local,
        appType: 'web',
        imgUrl: 'https://arms-retcode.aliyuncs.com/r.png?',
        disableHook: true,
        sendResource: true,
        enableLinkTrace: true,
        enableApiCors: true,
        linkType: 'tracing',
        behavior: true,
        enableSPA: true,
        useFmp: true,
        sample: 1,
        release: '0.0.2',
        disabled: ['daily', 'local'].includes(options.environment || ''),
        setUsername: () => localStorage.getItem('uin') || '',
        ignore: {
            ignoreErrors: [
                // 因为IOS APP重复调用已被清空的jsBridge callback，不影响具体逻辑，因此屏蔽。
                /^Can't find variable: s\d{13,21}([a-z_0-9]+)?$/, // 正则表达式
                function (str) {
                    // 方法
                    const reg = /^Script error\.?$/
                    const isUat = options.environment === 'pre' // 保留UAT上报script error错误的能力
                    if (reg.test(str) && !isUat) {
                        return true //// 不上报
                    }
                    return false // 上报
                },
            ],
            ignoreApis: [/^\/h5Log\/v1/],
        },
    }
    const armsOpt = Object.assign(defauleOption, options)
    const arms = BrowerLogger.singleton(armsOpt)
    arms.setConfig = setConfig || function () {}
    armsObj = arms
    return arms
}

/**
 * 设置ARMS请求头
 */
export const armsSetHeader = ({ headers, arms }: SetArmsHeaderOption<any>): SetArmsHeaderCallback | void => {
    if (arms) {
        const uberTraceIdObj = arms?.getUberTraceId('uber-trace-id') || {}
        const uTraceId = uberTraceIdObj['uber-trace-id'] || ''
        const traceId = uberTraceIdObj['traceId'] || ''
        headers['uber-trace-id'] = uTraceId
        headers['X-timestamp'] = new Date().getTime() + ''
        return {
            uTraceId,
            traceId,
        }
    }
    console.error('请先使用 initArms 初始化，或对 setTraceIdInHeader 传入 arms')
}

/**
 * ARMS上报接口
 */
export const sendArms = ({ response, error, arms = armsObj as any }: SendArmsOption) => {
    if (arms) {
        const getData = response || error
        let success = true
        let code = response?.data?.error?.code ?? 0
        let msg = JSON.stringify(response?.data || {})

        const headers = getData?.config?.headers || getData?.config?.headerMap || {}
        const endTime = new Date().getTime()
        const startTime = headers['X-timestamp'] || endTime
        const url = getData?.config?.url || response?.origin?.url || ''
        const duration = endTime - startTime
        const uberTraceId = headers['uber-trace-id'] || ''
        const traceId = uberTraceId.split(':')[0]

        if (error) {
            success = false
            code = 'ERROR'
            msg = JSON.stringify(error?.data?.error || error?.message || error?.desc || {})
        }

        setTimeout(() => {
            if (code && url) {
                console.warn('ARMS API 发送信息:', { url, duration, code, msg, traceId })
                arms?.api(url, success, duration, code, msg, startTime, traceId)
            }
        }, 3000)
    } else {
        console.error('请先使用 initArms 初始化，或对 setTraceIdInHeader 传入 arms')
    }
}

/**
 * ARMS 自动上报 axios 的错误
 * 用于 axios 注册时使用
 */
export const armsToAxios = ({ http, arms = armsObj }: ArmsToAxiosOption<any>): void => {
    if (arms) {
        http?.registerInterceptor('request', {
            sendArms: (config: any): any => {
                armsSetHeader({
                    headers: config?.headers,
                    arms: armsObj,
                })
                return config
            },
        })
        http?.registerInterceptor('response', {
            sendArms: (response: any, error: any): any => {
                sendArms({
                    response,
                    error,
                })
                return response
            },
        })
    } else {
        console.error('请先使用 initArms 初始化，或对 setTraceIdInHeader 传入 arms')
    }
}
