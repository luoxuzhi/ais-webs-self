// eslint-disable-next-line @typescript-eslint/no-var-requires
import sensors from 'sa-sdk-javascript/dist/web/sensorsdata.es6'
const SIT_LINK = 'https://shence-admin.xingyunplan.com:8106/sa?project=default'
const PROD_LINK = 'https://shence-admin.xingyunplan.com:8106/sa?project=production'

export interface SensorsInitOption {
    env: string
    Vue2?: any
    Vue3?: any
    initOptions?: any
    pageviewOptions?: any
}

export interface SensorsCallback {
    sensors: any
}
export const sensorsInit = ({ env, Vue2, Vue3, initOptions, pageviewOptions }: SensorsInitOption): SensorsCallback => {
    if (!env) {
        console.log('%c 神策埋点 sensorsInit() 必须传入 env 参数', 'color:#FF3300;font-size:2em;font-width:800;')
    } else {
        sensors.init({
            show_log: false,
            app_js_bridge: true,
            server_url: env === 'prod' ? PROD_LINK : SIT_LINK,
            is_track_single_page: true, // 单页面配置，默认开启，若页面中有锚点设计，需要将该配置删除，否则触发锚点会多触发 $pageview 事件
            use_client_time: true,
            send_type: 'beacon',
            ...initOptions,
        })

        // //用于采集 $pageview 事件, 添加 platform 属性为 h5
        if (initOptions?.AutoTrack !== false) {
            sensors.quick('autoTrack', {
                platform: 'h5',
                ...pageviewOptions,
            })
        }
        // 页面浏览时长
        sensors.use('PageLeave')
        // 页面加载时长
        sensors.use('PageLoad')

        // 神策SDK Ready事件
        sensors.quick('isReady', function () {
            console.log('%c 神策SDK Ready!', 'color:#24d536;font-size:30px;font-width:800;')
        })
        if (Vue2) {
            Vue2.prototype.$sensorsTrack = sensors.track
            Vue2.prototype.$sensors = sensors
        } else if (Vue3) {
            Vue3.config.globalProperties.$sensors = sensors
            Vue3.config.globalProperties.$sensorsTrack = sensors.track
        } else {
            console.log('%c 神策埋点须传入参数 { Vue2 或 Vue3 }', 'color:#FF3300;font-size:2em;font-width:800;')
        }
    }

    return { sensors }
}

// 手动触发$pageView上报 - 因为自动$pageView的上报会因为首次打开页面时页面标题为空（pages.js里面的title属性为空 - 因为在app内打开新的webview会闪现“理财|风测...”因此为空)
export const autoTrackSinglePage = (pageviewOptions = {}) => {
    sensors.quick('autoTrackSinglePage', {
        platform: 'h5',
        ...pageviewOptions,
    })
}
