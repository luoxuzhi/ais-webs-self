### 神策埋点

#### 使用方式

```js
// 引入
import { sensorsInit } from '@fs/utils'
import Vue from 'vue'

// 注：Vue2 或 Vue3 必传其中的一个

// Vue2 用法
sensorsInit({
    env: 'dev', // dev | sit | uat | prod
    Vue2: Vue,
    initOptions: {
        show_log: true, // 是否打开 log
        app_js_bridge: false, //
        platform: 'web-wf', // 自定义 platform
        // ...
        // --- 扩展的功能
        AutoTrack: false, // 是否开启 autoTrack; 默认开启
    },
})

//Vue3用法
sensorsInit({
    env: 'dev',
    Vue3: Vue,
})

// 其它参数参考
/**
 * @env
 * @Vue2
 * @Vue3
 * @initOptions
 * @pageviewOptions
 */
import { SensorsInitOption } from '@fs/utils'

/** 其它用法 */
import { autoTrackSinglePage } from '@fs/utils'
//手动触发$pageView上报
autoTrackSinglePage({
    // ...pageviewOptions
})
```
