## crypto

公共加解密

### 介绍

https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001000140

> 安全与加密
> 1，核心/敏感信息二次加密，公开数据不用加密
>
> 2，登陆前使用 ECDSA/ECDH 交换临时会话密钥
>
> 3，登陆后使用会话密钥进行对称加密
>
> 4，交易时使用交易会话密钥进行对称加密
>
> 5，对于要求身份认证但要求不高的认证，例如串流行情，使用会话 JWT
>
> 6，对于行情、资讯等公开数据，不用加密，需要防范 DDOS 攻击
>
> 7，核心接口都会启用强制加密，前端可以根据后端返回 Headers 中的 X-return-Code 是否为 0 或者其他约定的错误码，决定是否解密。（注：目前 dev 为联调方便未开启强制加密）
>
> ===
>
> 消息签名：登录之后的接口使用，目的为验证请求头是否可信

#### 对称加密算法

```
AES 是对称加密算法，也就是说加密和解密都是采用同一个的密钥（rndKey）。

AES 加密的时候，会把文件切分成一个个的小块进行加密，每个块是128位，也就是16个字节。如果文件大小不是16字节的整数倍，那就要在末尾添加一些数据凑够。每个块都会被单独去进行加密。

加密的时候，AES 算法会有两个输入一个输出。输入是密钥和文件内容，输出是密文。解密时候会把密文和密钥所输入，输出就是文件原文。

------
登录鉴权 - 部分接口的额外鉴权
https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001000142@toc13

------
OSS授权码加密 - oss直链的鉴权
https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001000651@toc23

```

#### 临时会话加密算法

```
ECDH ( Elliptic Curve Diffie-Hellman Key Exchange ) 是一种 匿名密钥协商方案 。其能让通信的双方使用各自的椭圆曲线公私密钥对，在不安全的信道中协商出来一个 共享密钥，这个密钥一般作为“对称加密”的密钥而被双方在后续数据传输中使用。

算法解析：
如果有两个秘密数字 a 和 b （即分别属于 A 和 B 的两个私钥），和一个使用点 G 作为生成元的 ECC 椭圆曲线，我们就可以在不安全信道中传输 (a*G)、(b*G) 的值了（即可以传输 A 和 B 的公钥）。
接下来即可从这些值派生出共享密钥：secret = (a*G)*b=(b*G)*a 。这条等式可以写作下面的形式：
aPubKey * bPrivKey = bPubKey * aPrivKey = secret

据此可得算法过程如下：
A 生成一个随机 ECC 密钥对： {aPrivKey, aPubKey = aPrivKey * G}
B 生成一个随机 ECC 密钥对：{bPrivKey, bPubKey = bPrivKey * G}
A 和 B 通过不可靠信道（比如互联网）交换各自的公钥
A 计算共享密钥 sharedKey = bPubKey * aPrivKey
B 计算共享密钥 sharedKey = aPubKey * bPrivKey
A 和 B 即拥有相同的共享密钥 sharedKey == bPubKey * aPrivKey == aPubKey * bPrivKey

---------
ECDSA签名算法
https://zhuanlan.zhihu.com/p/31671646

```

#### 签名算法

```
根据约定生成签名原文字串（字符串处理&拼接），再根据约定的哈希加密算法，使用登录会话密钥（rndKey）进行哈希加密，得出签名字串，前后端进行签名字串比对，一致则代表签名有效
```

### 用例

#### AES & ECDH

```javascript
// 按需引入
import { AESCrypto, ECDHCrypto } from '@fs/utils/dist/lib/crypto'

// ECDH服务端公钥
const VITE_APP_PUBLIC_KEY = import.meta.env.VITE_APP_PUBLIC_KEY
// ECDSA签名密钥
const VITE_APP_SIGN_KEY = import.meta.env.VITE_APP_SIGN_KEY

const cryptoKeys = {
    server_public_key_base64: VITE_APP_PUBLIC_KEY,
    sign_public_key_base64: VITE_APP_SIGN_KEY,
}

export const AESCryptoService = new AESCrypto()
export const ECDHCryptoService = new ECDHCrypto(cryptoKeys)

// ECDH加密
const { ECDHKey, localKey } = await ECDHCryptoService.GetECDHAndLocalKey()
const data = ECDHCryptoService.ECDHEncrypt(config.data, ECDHKey, localKey)
// ECDH解密
dataAxios = await ECDHCryptoService.ECDHVerifyAndDecrypt(dataAxios.result)
```

#### SIGN

```javascript
// 按需引入
import { SignCrypto } from '@fs/utils/dist/lib/crypto'

export const SignCryptoService = new SignCrypto()
```

### 注意事项

在部分 vite 项目中，本地`yarn link @fs/utils`进行调试时，可能存在`@fs/utils/dist/lib/crypto`引入路径报错的情况；
这可能是因为该路径错误地匹配了`vite.config.alias`配置的`@`别名，导致路径解析错误；
针对这个错误，可以在`vite.config.alias`中配置`@fs`的别名，并置于`@`别名之前

```javascript
'@fs': resolve(__dirname, './node_modules/@fs')
```
