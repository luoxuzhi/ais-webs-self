# 使用方式

## 1、初始化 arms

```ts
import { armsInit, ArmsInitOption, ArmsEnvironment } from '@fs/utils'
const option: ArmsInitOption = {
    options: {
        pid: 'xxxxx-xxxx', //项目唯一id
        environment: ArmsEnvironment.local || 'xxx', // 取值为：prod、gray、pre、daily和local
        /**
         * 其余参数可选；
         * 参考arms官方文档：https://help.aliyun.com/zh/arms/browser-monitoring/developer-reference/sdk-reference?spm=a2c4g.66404.0.i5#sc-setusername
         */
    },
    //   setConfig: () => {
    //     可选：
    //     setConfig == arms.setConfig
    //     setConfig 可以改变 options 中的所有值
    //   },
}
armsInit(option)
```

## 2、接入 axios

```ts
import { armsToAxios, ArmsToAxiosOption } from '@fs/utils'
// import { FSHttp } from '@fs/xxx'
const http: HttpType | any = new FSHttp(httpOption)

// 该方法之前必须执行 armsInit()， 如果没有执行  则需要手动传入 arms 参数
const option: ArmsToAxiosOption<HttpType> = {
    http,
    //   arms,  //可选 arms = armsInit()
}
armsToAxios(option)
// 示例
```

## 3、手动上传 arms

```ts
import { sendArms, SendArmsOption } from '@fs/utils'

const option: SendArmsOption = {
    response,
    error,
    arms,
}
sendArms(option)
```

## 4、手动设置 ARMS 标识加入请求头中

```ts
import { armsSetHeader, SetArmsHeaderOption, SetArmsHeaderCallback } from '@fs/utils'
const option: SetArmsHeaderOption = {
    headers: any, // http 的 headers
    arms: any,
}
```
