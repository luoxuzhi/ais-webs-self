### 使用方式

```javascript
// 按需引入
import { FSHttp, FSAppHttp } from '@fs/utils/dist/lib/http'
import MRErrorTip from '@/config/MRErrorTip' // 可能不存在也不需要mr的项目，不需要引入
import { Toast } from 'vant'
import { getXSource } from './http.tool.js'
const { VUE_APP_ENV, VUE_APP_PUBLIC_KEY, VUE_APP_SIGN_KEY, VUE_APP_ARMS_ENV, NODE_ENV } = process.env

let http = null
// 初始化
// defaultOptions的实例，uin、session、rndKey的初始化获取方式支持传入string和函数
// 存在同花顺和app取得session不一致
// 由于旧项目对于http文件的引入时机存在过早问题，因此session、uin、rndKey三个字段建议采用`函数形式`，这样会实时通过函数执行获取数据
const sessionKey = isTHSApp() || getRunEnv() === 2 ? 'WTtoken' : 'session'
// session的处理仅限于旧项目对于同花顺的兼容导致。新项目不需要如此处理
const session: string | () => {} = localStorage.getItem(sessionKey)
const defaultOptions = {
	uin: string | () => {}: localStorage.getItem('uin'),
    session,
    rndKey: string | () => {}: localStorage.getItem('rndKey'),
	product: 'wealth', // 对应项目名称
    lang: getLangType(),
    xSource: getXSource(),
    PUBLIC_KEY: VUE_APP_PUBLIC_KEY,
    SIGN_KEY: VUE_APP_SIGN_KEY,
    VUE_APP_ENV: VUE_APP_ENV,
    NODE_ENV: NODE_ENV,
    Toast: Toast,
    MRErrorTip,
    arms: {
        pid: 'hvolair3j6@c1593183f42035d', // 每个项目对应arms pid - **初始化arms需要删除项目原来的entry中的arms文件引入**
        environment: VUE_APP_ARMS_ENV,
        // 支持用来替换内部的arms上报函数规则
        sendArms: () => {},
    },
    // 用于判断响应体是否应该走reject还是走fullfiled拦截函数
    judgeErrorResponse: res => {
        if (res.data.error) return true
        return false
    }
}

if (isHLApp) {
	const options = { adaptar: Instance <Axios, JSBridge.request>, defaultOptions }
    http = new FSAppHttp(options)
} else {
	const options = { adaptar: Instance <Axios, JSBridge.request>, defaultOptions }
    http = new FSHttp(options)
}

// 注册拦截器
http.registerInterceptor('request', {
    onFulfilled: (config) => {
        // do something
        return config
    },
    onRejected: (e) => { return Promise.reject(e) },
    options: { runWhen: config => Boolean }
})

// request 简化方式 - 传入的函数会默认作为onFullfiled函数执行
http.registerInterceptor('request',
    (config) => {
        // do something
        return config
    }
)

// response 完整方式
http.registerInterceptor('response', {
    onFulfilled: (response) => {
        // do something
        return response
    },
    onRejected: (e) => { return Promise.reject(e) },
    options: { runWhen: config => Boolean }
})

// response 简化方式 - 传入的函数会默认作为onFullfiled函数执行
http.registerInterceptor('response',
    (response) => {
        // do something
        return response
    }
)


// 执行注册拦截器到adapter里面
http.execRegisterInterceptor()

// 发起请求
// config 包含 params｜data 、 origin、encrypt、
http.request({ url, method, ...config })

```

### NOTE: 用户注册的拦截器会执行在内部拦截器（加密、解密、arms上报、通用错误处理）中间，如下图所示

![拦截器执行流程图](https://www.tapd.cn/tfl/pictures/202402/tapd_60236733_1708483255_473.png)

### NOTE：APP 内 vConsole 内容输出使用方式，效果如下

![lQDPKcfDp4OTm0PNBQDNAk-w4Nnoc_ZN0a0FnaZfD8NyAA_591_1280.jpg](/tfl/pictures/202401/tapd_60236733_1705909474_596.jpg)

-   需要在 package.json 文件中增加 vconsole-webpack-plugin，并在 vue.config.js 中引入并注册。动态插入 vconsole 插件,主要代码为以下几步

```json
"devDependencies": {
        "vconsole-webpack-plugin": "^1.7.3",
    }
```

```javascript
const vConsolePlugin = require('vconsole-webpack-plugin');  // 动态插入vconsole

//注册
plugins: [
	new vConsolePlugin({ enable: process.env.VUE_APP_ENV !== 'prod' }) // 生产不注册该插件
],
```
