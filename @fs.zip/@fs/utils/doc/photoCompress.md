## photoCompress

图片压缩

### 例子

```javascript
// 按需引入
import { photoCompress } from '@fs/utils/dist/lib/photoCompress.js'

const file = this.inputDom.files[0] // 图片
const obj = { width: 1080, height: 1080, quality: 0.7 } // 图片参数
const cb = cFile => {
    console.log('压缩完之后图片', cFile)
} // 回调函数

photoCompress(file, obj, cb)
```
