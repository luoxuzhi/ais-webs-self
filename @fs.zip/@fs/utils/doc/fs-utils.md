## fs-utils

工具库

### remH5

通过 rem 实现移动端适配

#### 例子

```javascript
import { initRem } from '@fs/utils'

// 默认配置
initRem()

// 自定义最大宽度
initRem(document, window, 440)
```

### tools

工具函数库

#### 例子

```javascript
import { isTHSApp, isHLApp } from '@fs/utils'

console.log('isTHSApp', isTHSApp())
console.log('isHLApp', isHLApp())
```
