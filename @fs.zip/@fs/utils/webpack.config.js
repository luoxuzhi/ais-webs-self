// 参考配置：https://www.webpackjs.com/concepts/

const path = require('path')

module.exports = {
    entry: './index.ts',
    mode: 'production',
    // target: ['es2020'], // 默认umd格式
    module: {
        rules: [
            {
                test: /\.tsx?$/,
                use: 'ts-loader',
                exclude: /node_modules/,
            },
        ],
    },
    resolve: {
        extensions: ['.tsx', '.ts', '.js'],
    },
    output: {
        clean: false,
        // chunkFormat: 'module',
        // filename: 'tools.webpack.esm.min.js',
        filename: 'fs-utils.webpack.min.js',
        path: path.resolve(__dirname, 'dist'),
    },
}
