module.exports = {
    extends: ['plugin:vue/essential', './vue-base.js', './index.js'],
    parser: 'vue-eslint-parser',
    parserOptions: {
        parser: '@babel/eslint-parser',
    },
}
