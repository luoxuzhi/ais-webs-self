module.exports = {
    extends: ['plugin:vue/vue3-essential', './vue-base.js', './index.js'],
    parser: 'vue-eslint-parser',
    parserOptions: {
        ecmaVersion: 2020,
        parser: '@typescript-eslint/parser',
        sourceType: 'module',
    },
    globals: {
        // vue3 单文件setup模式，防止报未定义错误
        defineProps: 'readonly',
        defineEmits: 'readonly',
        defineExpose: 'readonly',
        withDefaults: 'readonly',
    },
}
