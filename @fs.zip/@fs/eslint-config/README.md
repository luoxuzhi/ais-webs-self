## 安装

```
yarn add eslint @fs/eslint-config -D
```

## 使用

创建文件 `.eslintrc.js`

```
// vue2&js project
{
    "extends": ["@fs/eslint-config/vue2"]
}

// vue3&ts project
{
    "extends": ["@fs/eslint-config/vue3"]
}
```
