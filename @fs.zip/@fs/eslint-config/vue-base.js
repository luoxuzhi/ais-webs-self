module.exports = {
    rules: {
        'vue/multi-word-component-names': 'off', // 组件名称必须多单词
        'vue/no-reserved-component-names': 'off', // 不可与HTML标签同名 如Table
        'vue/no-unused-components': 'off', // 组件注册但未使用
    },
    plugins: ['vue'],
}
