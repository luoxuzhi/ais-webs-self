module.exports = {
    extends: ['plugin:@typescript-eslint/recommended'],
    parser: '@typescript-eslint/parser',
    plugins: ['@typescript-eslint'],
    rules: {
        '@typescript-eslint/no-unused-vars': ['warn'], // 未使用的变量
        '@typescript-eslint/no-explicit-any': ['off'], // any警告
        '@typescript-eslint/ban-types': ['off'], // 不合理的类型推断
        '@typescript-eslint/ban-ts-comment': ['off'], // 允许使用 @ts-ignore
        '@typescript-eslint/no-non-null-assertion': ['off'], //  !非空断言
        '@typescript-eslint/no-this-alias': [
            'error',
            {
                allowDestructuring: false, // Disallow `const { props, state } = this`; true by default
                allowedNames: ['self'], // Allow `const self = this`; `[]` by default
            },
        ],
    },
}
