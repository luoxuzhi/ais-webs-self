module.exports = {
    root: true,
    env: {
        browser: true,
        es6: true,
        node: true,
        commonjs: true,
        jest: true,
    },
    parser: '@babel/eslint-parser',
    parserOptions: {
        // ECMAScript modules 模式
        sourceType: 'module',
        // 即使没有 babelrc 配置文件，也使用 @babel/eslint-parser 来解析
        requireConfigFile: false,
        // 仅允许 import export 语句出现在模块的顶层
        allowImportExportEverywhere: false,
    },
    plugins: ['prettier'],
    extends: ['eslint:recommended', 'prettier'],
    rules: {
        'prettier/prettier': 'error',
        'no-console': 'off',
        'no-unused-vars': 'warn', // 未使用的变量
        'no-debugger': process.env.NODE_ENV === 'production' ? 'error' : 'warn',
        'no-async-promise-executor': 'error', // promise执行函数不可为async, 否则异步函数抛出错误，错误将会丢失
        'prefer-const': 'error',
        eqeqeq: ['warn', 'always'], // 必须使用全等
        'no-redeclare': 2, //禁止重复声明变量
        'consistent-this': [2, 'self'], //this别名
        'max-params': [2, 3], //函数最多只能有3个参数
        'no-unreachable': 2, //不能有无法执行的代码
        'default-case': 'off', //switch语句最后必须有default,改为警告
        'no-else-return': 2, //如果if语句里面有return,后面不能跟else语句
        'no-dupe-args': 2, //函数参数不能重复
        'vars-on-top': 2, //var必须放在作用域顶部
        'prefer-promise-reject-errors': 'off', // promise reject
    },
    overrides: [
        {
            files: ['*.ts', '*.tsx'],
            extends: ['./typescript.js'],
        },
    ],
}
