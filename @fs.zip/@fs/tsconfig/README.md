## 安装

```
yarn add @fs/tsconfig -D
```

## 使用

在项目 `tsconfig.json` 文件中写入

```
{
  "extends": "@fs/tsconfig"
}
```
