// 参考文档：https://www.rollupjs.com/guide/command-line-reference

import ts from 'rollup-plugin-typescript2'
import { terser } from 'rollup-plugin-terser'
import clear from 'rollup-plugin-clear'
import resolve from '@rollup/plugin-node-resolve'
import commonjs from '@rollup/plugin-commonjs'
import json from '@rollup/plugin-json'

export default {
    input: 'index.ts',
    output: [
        {
            dir: 'dist',
            name: 'fs-http',
            entryFileNames: 'fs-http.umd.js',
            format: 'umd', // 输出类型 (amd, cjs, es, iife, umd, system)
        },
        {
            dir: 'dist',
            entryFileNames: 'fs-http.esm.js',
            format: 'es', // 输出类型 (amd, cjs, es, iife, umd, system)
            name: 'fs-http',
            manualChunks: {
                FSHttpApp: ['lib/http/FSAppHttp/FSAppHttp.ts'],
                FSH5Http: ['lib/http/FSH5Http/index.ts'],
                interceptors: ['lib/http/interceptors/interceptors.ts'],
                ECDHInterceptors: ['lib/http/interceptors/ECDHInterceptors.ts'],
                LoginInterceptors: ['lib/http/interceptors/LoginInterceptors.ts'],
                // FSHttp: ['lib/http/FSHttp/FSHttp.ts'],
            },
        },
    ],
    external: ['axios', '@fs/utils', 'asmcrypto.js'],
    plugins: [
        clear({
            // 清除文件夹
            targets: ['dist', 'types'],
        }),
        // 外部模块支持
        resolve({
            preferBuiltins: true,
        }),
        // 支持commonjs
        commonjs({
            requireReturnsDefault: 'auto',
            // transformMixedEsModules: true,
        }),
        // 支持json
        json(),
        // ts编译
        ts(),
        // 压缩
        terser(),
    ],
}
