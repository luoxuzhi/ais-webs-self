declare interface Window {
    sjcl: any
    clientKey: any
    clientNonce: any
    decrypt: any
    decrypt2: any
}
