import { ERROR_COCES, LOGOUT_ERROR_CODE } from '../config/constant'
import i18n from '../common/i18n.js'
import { afterLogout } from '../common/logoutError'
import { getBooleanProperty } from '../utils'
import { CommonErrorInterceptorParams } from '../types/index'

/**
 * 通用错误拦截器
 * @param params 参数对象
 * @returns 拦截器对象 {onFulfilled, onRejected, options}
 */
export default (params: CommonErrorInterceptorParams) => {
    const interceptor = {
        onFulfilled: response => {
            try {
                const runWhen = interceptor?.options?.runWhen
                const isUnExecInterceptor = typeof runWhen === 'function' && !runWhen(response.config)
                if (isUnExecInterceptor) {
                    return Promise.reject(response)
                }
                const { config, data } = response || {}
                // 超时错误处理前置
                if (response.code === 'ECONNABORTED') {
                    if (config.timeoutShowError) {
                        typeof params?.Toast === 'function' && params?.Toast(i18n.t('serviceTimeout'))
                    }
                    return Promise.reject(response)
                }

                const { error } = data || {}
                if (error) {
                    // 通过单个接口的config参数控制是否展示MR错误提醒 - 默认为true
                    // MR 系统维护错误提醒
                    const systemMaintenance = getBooleanProperty(params, 'systemMaintenance', true)
                    if (systemMaintenance) {
                        if (error?.code === ERROR_COCES.SYSTEM_MAINTENANCE) {
                            // 第一期：1、通过初始化传入公用组件。 第二期：通过依赖方式引入？
                            typeof params?.MRErrorTip === 'function' && params?.MRErrorTip(response)
                            //  为什么要删除 - 不让后续catch执行对应代码？,是否可以优化？
                            delete error.data
                            return Promise.reject(response)
                        }
                    }
                    // 仅展示后台数据返回的错误信息
                    if (config.showError) {
                        // 通过初始化传入公用组件。Toast
                        const msg = error.data?.tips
                        // !msg && options.logger('warn', `${config?.url} error.data?.tips is empty ===> `, msg)
                        msg && params?.Toast(msg)
                        return Promise.reject(response)
                    } else if (LOGOUT_ERROR_CODE.includes(error?.code)) {
                        /*------- 登出处理  -------*/
                        afterLogout(params, error)
                        return Promise.reject(response)
                    }
                }
                return Promise.resolve(response)
            } catch (e) {
                // options.logger('error', `commonErrorInterceptor encounter error ===> `, e, 'so i reject the response')
                return Promise.reject(response)
            }
        },
        onRejected: response => {
            return Promise.reject(response)
        },
        options: {
            runWhen: function (config) {
                config = config || {}
                // 通过参数控制是否跳过通用错误拦截器
                if (config.skipCommonErrorInterceptor) return false
                return true
            },
        },
    }
    return interceptor
}
