import axios, { AxiosInstance, AxiosRequestConfig } from 'axios'
import { createUUID, emptyOnFullfilled, emptyOnReject } from '../utils.js'
import { HttpOptions, interceptor, interceptorObj, interceptorType, postData, requestConfig } from '../types/index'
import { AESCrypto } from '@fs/utils'

export class FSH5Http {
    options: AxiosRequestConfig
    _instance: AxiosInstance
    /**
     * @param {*} options
     * @param {Object} options.adapter 请求库
     * @param {Object} options.defaultOptions 默认请求参数 - https://github.com/axios/axios?tab=readme-ov-file#request-config
     */
    constructor(options?: HttpOptions) {
        const { adapter = axios, defaultOptions } = options || {}

        // 默认值
        const baseOptions: AxiosRequestConfig = {
            baseURL: '',
            timeout: 15000,
            withCredentials: false,
        }
        const finalOptions: AxiosRequestConfig = Object.assign({}, baseOptions, defaultOptions)
        // 初始化logger
        // this._logger = getLogger(finalOptions.debug)

        // 赋值全局参数
        this.options = finalOptions

        const httpRequest = adapter.create(this.options)

        this._instance = httpRequest
    }
    /**
     * 获取实例
     */
    get axiosInstance() {
        return this._instance
    }

    /**
     * 注册单个拦截器
     * @param {String} type 拦截器的类型 request | response
     * @param {Function | Object} interceptor 拦截器对象，可以只传一个函数作为onFulfilled函数使用
     * @param { Function } interceptor.onFulfilled 接受上一个拦截器成功返回的数据
     * @param { Function } interceptor.onRejected 接受上一个拦截器失败返回的错误
     * @param { Object } interceptor.options 配置参数，支持axios的拦截器参数
     * @returns {number} 拦截器注册的id
     */
    registerInterceptor(type: interceptorType, interceptor: interceptor | ((val: any) => any)) {
        const internalItp = this.normalizeInterceptor(interceptor)
        const onFulfilled = this.refactoringOnFullfilled(internalItp)
        const onRejected = this.refactoringOnRejected(internalItp)
        // 实际注册到axios上
        return this._instance.interceptors[type].use(onFulfilled, onRejected, internalItp.options)
    }
    /**
     * 请求方法
     * @param options {Object} 请求参数
     * @param options.method {String} 请求方法
     * @param options.url {String} 请求地址
     * @param options.data {Object} POST方法请求数据
     * @param options.params {Object} GET请求参数数据
     * @returns {Promise} 请求结果
     */
    request(options: requestConfig) {
        let data: postData
        const requestid: string = createUUID()
        const method = options.method?.toLowerCase()

        const rConfig = {
            requestid,
            ...options,
        }
        // 设置 josnRpc 2.0
        if (options.type !== 'from' && options.jsonRpc !== false) {
            // type = from 则不做 jsonRpc 处理，直接提交 from 格式
            data = {
                jsonrpc: '2.0',
                method: options.url, // example：/ecash/v1/subscribe
                params: options.data,
                id: requestid,
            }

            if (method === 'post') {
                rConfig.data = data
            }
        }
        if (method === 'get') {
            rConfig.params = options.params || options.data
        }
        return this._instance(rConfig)
    }
    /**
     * 标准化拦截器对象
     * @param {Function|Object} interceptor  拦截器对象
     * @param {Function} interceptor  拦截器对象
     * @returns {Object} {onFulfilled, onRejected, options}
     */
    normalizeInterceptor(interceptor: interceptor | ((val: any) => any)) {
        // interceptor 如果是函数则作为onFulfilled处理, 默认onRejected为空函数，并logger打印
        let internalItp: interceptorObj = {
            onFulfilled: emptyOnFullfilled,
            onRejected: emptyOnReject,
            options: {},
        }
        if (typeof interceptor === 'function') {
            if (process.env.NODE_ENV === 'development') {
                console.warn('registerInterceptor => interceptor is function, so i will use it as onFulfilled')
            }
            internalItp = {
                onFulfilled: interceptor,
                onRejected: emptyOnReject,
                options: {},
            }
        } else if (typeof interceptor === 'object') {
            // 补齐用户没传的参数
            internalItp = {
                onFulfilled: interceptor.onFulfilled || emptyOnFullfilled,
                onRejected: interceptor.onRejected || emptyOnReject,
                options: interceptor.options || {},
            }
        }
        return internalItp
    }
    /**
     * 重构拦截器的onFulfilled函数
     * @param {Object} interceptor 拦截器对象
     * @returns {Function} 包裹后onFulfilled的函数
     */
    refactoringOnFullfilled(interceptor: interceptorObj) {
        const onFulfilled = async (data: any): Promise<any> => {
            try {
                const res = await interceptor.onFulfilled(data, this.options)
                return Promise.resolve(res)
            } catch (error) {
                console.error(`onFulfilled error ===> `, error)
                if (error instanceof Error) {
                    return Promise.reject(data)
                }
                return Promise.reject(error)
            }
        }
        return onFulfilled
    }
    /**
     * 重构拦截器的onRejected函数
     * @param {Object} interceptor 拦截器对象
     * @returns {Function} 包裹后onFulfilled的函数
     */
    refactoringOnRejected(interceptor: interceptorObj) {
        const onRejected = async (error: any): Promise<any> => {
            try {
                const rej = await interceptor.onRejected(error, this.options)
                return Promise.reject(rej)
            } catch (e) {
                if (error instanceof Error) {
                    return Promise.reject(error)
                }
                return Promise.reject(e)
            }
        }
        return onRejected
    }

    /**
     * 注册全局的decrypt函数，方便测试环境调试
     * @param {Object} options.VUE_APP_ENV 环境变量
     * @returns {void}
     */
    registerDecryptFunction(options: any) {
        const d = async (data, key) => {
            try {
                const rndKey = localStorage.getItem(key) || ''
                if (!rndKey) return data

                data = (await new AESCrypto()).AESDecrypt(data, rndKey)
                data = JSON.parse(data)
            } catch (error) {
                console.error('decrypt error ===>', error)
            }
            return data
        }
        // 非生产会注册全局的解密函数
        if (options.VUE_APP_ENV !== 'prod') {
            // 添加响应拦截器
            window.decrypt = async data => {
                return await d(data, 'rndKey')
            }
            // 添加响应拦截器
            // @ts-ignore
            window.decrypt2 = async data => {
                return await d(data, 'rndKey2')
            }
        }
    }
}
