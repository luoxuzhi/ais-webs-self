import UAParser from 'ua-parser-js'
import { createUUID, getFromLocalStorage, getParamsData } from '../utils.js'
import { ENCRYPT_TYPES } from '../config/constant.js'
import { getLangType, getQueryString, isTHSApp, SignCrypto } from '@fs/utils'

interface CommonHeadersInterceptorParams {
    uin: string | ((config?: any) => string)
    session: string | ((config?: any) => string)
    rndKey: string | ((config?: any) => string)
    sessionKey?: string | ((config?: any) => string)
    channel: string
    product: string
    NODE_ENV: string
    xSource: string | ((config?: any) => string)
    lang?: string
    version?: string
}
/**
 * 通用请求头拦截器
 * @param params 参数对象
 * @returns 拦截器对象 {onFulfilled, onRejected, options}
 */
export default function CommonHeadersInterceptor(params: CommonHeadersInterceptorParams) {
    return {
        onFulfilled: onFulfilled(params),
        onRejected: onRejected,
        options: {},
    }
}
// x-session是否使用session作为key值
const isSessionKey: boolean = !isTHSApp() && !getQueryString('wtToken')

/**
 * fulfilled回调
 */
const onFulfilled: (p: CommonHeadersInterceptorParams) => (c: any) => any = (params: CommonHeadersInterceptorParams) => {
    return async function fn(config) {
        const headers = await getCommonHeadersForH5(params, config)
        // self.options?.logger('log', `http request CommonHeaders ===>`, headers)
        Object.assign(config.headers, headers)
        return config
    }
}

/**
 * rejected回调
 */
const onRejected: (val: any) => Promise<any> = e => {
    // this.options.error(`http request CommonHeaders error ===> `, e)
    return Promise.reject(e)
}

/**
 * 组装请求头对象
 * @param options 外部参数对象
 * @param config axios的通用参数对象
 * @returns 请求头对象
 */
const getCommonHeadersForH5 = async (
    options: CommonHeadersInterceptorParams,
    config: { requestid: string; antispams: string; encrypt: number; rndKey?: string }
) => {
    // 每次都需要新设置的内容
    const requestid: string = config.requestid || createUUID()
    const antispams = config.antispams || createUUID()
    const lang = options.lang || getLangType()
    const uin = getParamsData(options.uin, config)
    const session = getParamsData(options.session, config)
    const rndKey = getParamsData(options.rndKey, config)
    const xSource = getParamsData(options.xSource, config)

    const xDeviceInfo = getXDeviceInfo({ lang, channel: options.channel })
    const xSession = getXSession(options, config)
    const headerArr = [
        /*-----  每次都要新生成的字段 ------*/
        ['X-request-id', requestid],
        ['X-antispams', antispams],
        /*------- 不需要每次都新生成的字段 -------*/
        ['X-device-info', xDeviceInfo],
        ['X-session', xSession],
        /*------- 外部传入的参数值，属于项目初始化就会定的参数 -------*/
        ['X-product', `product=app-${options.product};version=${options.version || '0.0.1'}`],
        ['Access-Token', session],
        ['X-uin', uin],
        ['X-source', xSource],
        ['X-lang', lang],
        /*------- 当前页面的路径 -------*/
        ['X-url', location.href],
        ['X-timestamp', new Date().getTime()],
    ]

    if (options.session && rndKey) {
        const httpTools = new SignCrypto()
        config.rndKey = rndKey
        headerArr.push(['X-sign', (await httpTools.getXSign(config as any, { isDev: options.NODE_ENV !== 'production' })) || ''])
    }

    const headers = headerArr.reduce((o, [k, v]) => {
        o[k] = v
        return o
    }, {})
    return headers
}

/**
 * 获取session字符串
 * @param options 外部参数对象
 * @param config axios的通用参数对象
 * @returns session字符串
 */
const getXSession = (options: CommonHeadersInterceptorParams, config) => {
    const sessionArr: string[][] = [] // session集合可以包含session、session2、session3
    const session: string = getParamsData(options.session, config)

    if (isSessionKey) {
        const sessionKey = getParamsData(options.sessionKey, config) || 'session'
        // 登录session
        if (options.session) {
            sessionArr.push([sessionKey, session])
        }
        // APP_TRADE_FORCE_ENC 是APP内会使用的加密方式，如果接口传该类型，站外也需要传session2
        const tradeEncFlag = [ENCRYPT_TYPES.APP_TRADE_ENC, ENCRYPT_TYPES.APP_TRADE_FORCE_ENC].includes(config.encrypt)
        // 交易session2； H5交易(买入、卖出)需传session2
        const session2 = getFromLocalStorage('session2', '')
        if (tradeEncFlag && session2) {
            sessionArr.push(['session2', session2])
        }
    } else {
        sessionArr.push(['fhsId', getFromLocalStorage('WTtoken', '')])
    }
    // 行情session3 - 用来获取行情权限
    const userInfo: any = getFromLocalStorage('userInfo', {})
    const session3: string = userInfo?.permission?.token
    if (session3) {
        sessionArr.push(['session3', session3])
    }

    const xSession: string = sessionArr.reduce((str, [key, value]) => {
        str += `${key}=${value};`
        return str
    }, '')

    return xSession
}

/**
 * 获取设备信息字符串
 * @param param0 语言类型
 * @param param1 渠道（APP、H5）
 * @returns 设备信息字符串
 */
const getXDeviceInfo = ({ lang = '', channel = '' } = {}) => {
    const UA = new UAParser().getResult()
    const xDeviceInfoList = [
        ['platform', UA.os.name],
        ['osver', UA.os.version],
        ['model', UA.device.model || ''],
        ['browser', UA.browser.name],
        ['brover', UA.browser.major],
        ['lang', lang],
        ['channel', channel],
    ]
    const xDeviceInfo = xDeviceInfoList.reduce((str, [key, value]) => {
        str += `${key}=${value};`
        return str
    }, '')

    return xDeviceInfo
}
