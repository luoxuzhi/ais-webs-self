import { ECDHCrypto } from '@fs/utils'
import { ENCRYPT_TYPES } from '../../config/constant.js'
import { getParamsData } from '../../utils.js'

interface DecryptInterceptorParams {
    PUBLIC_KEY: string | ((config?: any) => string)
    SIGN_KEY: string | ((config?: any) => string)
}

/**
 * ECDH解密
 * @param params 参数对象 {PUBLIC_KEY: string | (() => string), SIGN_KEY: string | (() => string)}
 * @returns 拦截器对象 {onFulfilled, onRejected, options}
 */
export default (params: DecryptInterceptorParams) => {
    return {
        onFulfilled: async function (response) {
            const { config, data } = response
            if (config?.encrypt !== ENCRYPT_TYPES.EDCH) return response
            if (!data?.error) {
                try {
                    // 临时会话请求，需临时会话解密
                    let dataAxios = data
                    dataAxios.result.clientNonce = config.clientNonce
                    dataAxios.result.ECDHKey = config.ECDHKey
                    dataAxios.result.localKey = config.localKey

                    const server_public_key_base64 = getParamsData(params.PUBLIC_KEY, config)
                    const sign_public_key_base64 = getParamsData(params.SIGN_KEY, config)

                    const cryptoKeys = {
                        server_public_key_base64,
                        sign_public_key_base64,
                    }
                    const ECDHCryptoService = new ECDHCrypto(cryptoKeys)
                    dataAxios = await ECDHCryptoService.ECDHVerifyAndDecrypt(dataAxios.result)
                    // options.logger('log', `${config.url} ECDH ===> `, dataAxios.result)
                    response.data = dataAxios
                } catch (error) {
                    // options.logger('error', 'ECDH_Decrypt => error:', error)
                }
            }

            return Promise.resolve(response)
        },

        onRejected(response) {
            return Promise.reject(response)
        },

        options: {},
    }
}
