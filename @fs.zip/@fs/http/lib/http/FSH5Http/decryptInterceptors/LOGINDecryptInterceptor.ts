import { ENCRYPT_TYPES } from '../../config/constant.js'
import { AESCrypto } from '@fs/utils'
import { getFromLocalStorage, getParamsData } from '../../utils.js'
import { DecryptInterceptorParams, RNDKEY_TYPE } from './../../types/index'

/**
 * 登录解密
 * @param params 参数对象
 * @returns 拦截器对象 {onFulfilled, onRejected, options}
 */
export default (params: DecryptInterceptorParams) => {
    return {
        onFulfilled: async function (response) {
            const { config } = response
            //返回数据头content-type 为加密数据，则需要解密
            const isEncryptContentType = response.headers['content-type']?.includes('text/enc')
            if (typeof response.data === 'string' && isEncryptContentType) {
                try {
                    let rndKey = ''
                    // 涉及输入交易密码需要用rndKey2进行解密
                    const key = [ENCRYPT_TYPES.APP_TRADE_ENC, ENCRYPT_TYPES.APP_TRADE_FORCE_ENC].includes(config.encrypt)
                        ? 'rndKey2'
                        : getParamsData(params.rndKeyName, config) || RNDKEY_TYPE.rndKey
                    rndKey = getFromLocalStorage(key, '')
                    // options.logger('info', `decrypt ${key} => ${rndKey}`)
                    // 解密核心
                    let responseData = response.data
                    responseData = await new AESCrypto().AESDecrypt(responseData, rndKey, config.invalidKeySize)
                    responseData = JSON.parse(responseData)
                    response.data = responseData

                    // 请求参数解密 - 便于开发查看
                    decryptDataForDevelopment(response, rndKey, params)
                } catch (error) {
                    // options.logger('error', 'LOGIN_Decrypt => error:', error)
                    return Promise.reject(error)
                }
            }

            return Promise.resolve(response)
        },
        onRejected: e => {
            return Promise.reject(e)
        },
        options: {},
    }
}

async function decryptDataForDevelopment(response, rndKey, params) {
    const { config = {} } = response || {}
    // 请求参数解密 - 便于开发查看
    if (params.NODE_ENV === 'development') {
        let data = config.data
        if (data && config.method === 'post') {
            data = await new AESCrypto().AESDecrypt(data, rndKey)
            data = JSON.parse(data)
        }
        const requestData = data || config.params // 没有config.data就展示config.params
        console.log(`${config.url} requestData ===> `, requestData, '\n', 'responseData ===>', response.data)
    }
}
