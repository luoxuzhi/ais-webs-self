import { ENCRYPT_TYPES } from '../../config/constant.js'
// 按需引入
import { RNDKEY_TYPE, finalOptions, LOGINEncryptInterceptorParams } from './../../types/index'
import { AESCrypto } from '@fs/utils'
import { getFromLocalStorage, getParamsData } from '../../utils.js'

/**
 * 登录加密(登录之后的加密 - 有普通加密，也有交易加密)
 * @param params 参数对象
 * @returns 拦截器对象 {onFulfilled, onRejected, options}
 */
export default (params: LOGINEncryptInterceptorParams) => ({
    onFulfilled: async (config: finalOptions): Promise<finalOptions> => {
        try {
            const tradeEncFlag: Boolean = [ENCRYPT_TYPES.APP_TRADE_ENC, ENCRYPT_TYPES.APP_TRADE_FORCE_ENC].includes(config.encrypt)

            /*------- 登录加密 -------*/
            // 修改content-type为加密
            config.headers['Content-Type'] = 'text/enc;ver=1'
            if (config.method === 'get') {
                // get请求时，增加config.data为true可以让content-type在请求体中显示为上述'text/enc;ver=1',不然不会显示
                config.data = true
            } else {
                // 涉及输入交易密码需要用rndKey2进行加密
                const configData: string = JSON.stringify(config.data)
                const rndKeyKey: string = tradeEncFlag ? 'rndKey2' : getParamsData(params.rndKeyName, config) || RNDKEY_TYPE.rndKey
                const currentRndKey: string | null = localStorage.getItem(rndKeyKey)
                // options.logger('info', `encrypt ${rndKeyKey} => ${currentRndKey}`)
                config.data = await new AESCrypto().AESEncrypt(configData, currentRndKey || '')
            }
        } catch (e) {
            // options.logger('error', 'LOGIN_Encrypt => error:', e)
        }

        return config
    },
    onRejected: e => Promise.reject(e),
    options: {
        runWhen: function (config) {
            const version: string = /\/(v[0-9])\//.exec(config.url as string)?.[1] ?? ''
            /*------- 当接口版本为v1及以上，默认需要加密（NOTE：行情及登录前接口可能回不需要- 通过config.encrypt来处理） -------*/
            const isSessionKey: Boolean = version >= 'v1'
            /*------- 传给后台session的键，同时加密时x-session格式为session=xxxx  反之为fhsId=xxx -------*/
            const sessionKey = getParamsData(params.sessionKey, config) || (isSessionKey ? 'session' : 'WTtoken')
            const session: string | null = getFromLocalStorage(sessionKey, '')
            const rndKeyName = getParamsData(params.rndKeyName, config) || 'rndKey'
            const rndKey = getFromLocalStorage(rndKeyName, '')

            const isLogin = !!(session && rndKey)

            const isEncryTag = [ENCRYPT_TYPES.LOGIN, ENCRYPT_TYPES.APP_TRADE_ENC, ENCRYPT_TYPES.APP_TRADE_FORCE_ENC].includes(config.encrypt)
            // 未登录不加密
            if (!isLogin) return false
            // 双重自由，通过encrypted + version 来控制是否需要加密
            // 因为可能存在：encrypt - LOGIN | version - v0
            if (isEncryTag && isSessionKey) return true
            return false
        },
    },
})
