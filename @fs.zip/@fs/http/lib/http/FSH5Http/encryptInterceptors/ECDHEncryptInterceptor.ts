import { ENCRYPT_TYPES } from '../../config/constant.js'
// 按需引入
import { ECDHCrypto } from '@fs/utils'
import { finalOptions } from './../../types/index'
import { getParamsData } from '../../utils.js'

interface ECDHEncryptInterceptorParams {
    PUBLIC_KEY: string | ((config?: any) => string)
    SIGN_KEY: string | ((config?: any) => string)
}

/**
 * 非对称加密(一般用在登录)
 * @param params 参数对象 {PUBLIC_KEY: string | (() => string), SIGN_KEY: string | (() => string)}
 * @returns 拦截器对象 {onFulfilled, onRejected, options}
 */
export default (params: ECDHEncryptInterceptorParams) => ({
    onFulfilled: async (config: finalOptions): Promise<finalOptions> => {
        try {
            const server_public_key_base64 = getParamsData(params.PUBLIC_KEY, config)
            const sign_public_key_base64 = getParamsData(params.PUBLIC_KEY, config)
            const cryptoKeys = {
                server_public_key_base64,
                sign_public_key_base64,
            }
            const ECDHCryptoService = new ECDHCrypto(cryptoKeys)
            const { ECDHKey, localKey } = await ECDHCryptoService.GetECDHAndLocalKey()
            const data = await ECDHCryptoService.ECDHEncrypt(config.data, ECDHKey, localKey)
            config.ECDHKey = ECDHKey
            config.clientNonce = data.params.clientNonce
            config.localKey = localKey
            config.data = data
        } catch (e) {
            // options.logger('error', 'ECDH_Encrypt => error:', e)
        }

        return config
    },
    onRejected: res => {
        return Promise.reject(res)
    },
    options: {
        runWhen: function (config) {
            if (config.encrypt === ENCRYPT_TYPES.EDCH) return true
            return false
        },
    },
})
