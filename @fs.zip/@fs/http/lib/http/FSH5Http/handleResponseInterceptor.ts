import { interceptor } from '../types/index'
import { getBooleanProperty } from '../utils'

const defaultResponseHandler = v => v

type responseType = 'rejected' | 'fulfilled'

function getHandleResponse(type: responseType, options?: responseHandlerParams) {
    return function handleResponse(response) {
        const { config, name } = response || {}

        const { responseHandler = defaultResponseHandler } = options || {}

        try {
            // 直接返回完整响应体，报错也如此(兼容之前同事的返回值处理)
            const origin = getBooleanProperty(config, 'origin', true)
            if (origin) {
                if (type === 'rejected') {
                    return Promise.reject(response)
                }
                return Promise.resolve(response)
            }

            if (type === 'rejected') {
                // axios的错误信息，直接抛出去(兼容0.x，1.x版本)
                if (name === 'AxiosError' || name === 'Error') {
                    return Promise.reject(response)
                }
                /*------- 接口请求正常，但是结果存在错误信息则抛出去，通过error interceptor来处理 -------*/
                if (response.data.error) {
                    // 正常错误支持responseHandler处理
                    return Promise.reject(responseHandler(response.data))
                }
            }
            // 正常响应体response.data支持responseHandler处理
            return Promise.resolve(responseHandler(response.data))
        } catch (e) {
            // options.logger('error', `commonErrorInterceptor encounter error ===> `, e, 'so i reject the response')
            return Promise.reject(responseHandler(response.data))
        }
    }
}
type responseHandlerParams = {
    responseHandler: (res: any) => any
}

/**
 * 格式化返回结构响应拦截器
 * @param {Object} options
 * @returns {Object} 拦截器对象 {onFulfilled, onRejected, options}
 */
export default (options: responseHandlerParams): interceptor => {
    return {
        onFulfilled: getHandleResponse('fulfilled', options),
        onRejected: getHandleResponse('rejected', options),
        options: {},
    }
}
