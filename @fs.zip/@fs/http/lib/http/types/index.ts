import { AxiosRequestConfig } from 'axios'

export enum interceptorTypeEnum {
    req = 'request',
    res = 'response',
}
export type interceptorType = 'request' | 'response'
export interface FSHttpOptions extends AxiosRequestConfig {}

export interface interceptorObj {
    onFulfilled: (value: any, cfg?: any) => any
    onRejected: (err: any, cfg?: any) => any
    options?: object
}

export interface DecryptInterceptorParams {
    rndKeyName?: string
    NODE_ENV: string
}

export type interceptor = interceptorObj | ((value: any) => any)

export interface interceptors {
    request: Array<interceptorObj>
    response: Array<interceptorObj>
}

export interface requestConfig {
    type?: string
    method: Method | string
    url: string
    data?: any
    encrypt: number
    params?: any
    jsonRpc?: boolean
}

export interface postData {
    jsonrpc: string
    method: Method | string
    params: any
    id: string
}
export interface finalOptions extends FSHttpOptions {
    ECDHKey?: string
    clientNonce?: string
    localKey?: any
    headers: any
    encrypt: number
}

export interface commonHeaders {
    product: string
    lang: string
    uin?: string
    session?: string
    isSessionKey: boolean
}

export interface HttpOptions {
    adapter?: any
    defaultOptions: defaultOptions
}

export interface defaultOptions {
    baseURL?: string | ''
    timeout?: number | 15000
    withCredentials?: boolean | true
    crossDomain?: boolean | true
    debug?: boolean
}

// 随机数类型
export enum RNDKEY_TYPE {
    rndKey = 'rndKey',
    // rndKey2 = 'rndKey2',
    rndKeyWf = 'rndKeyWf',
}

export interface appConfigParams {
    method: Method | string
    url: string
    type?: string
    encrypt: number
    requestid?: string
    data?: any
    params?: any
    origin?: boolean
}

export interface CommonErrorInterceptorParams {
    MRErrorTip?: any
    Toast?: any
    CMHKLogoutInstance?: any
    systemMaintenance?: boolean
}

export interface LOGINEncryptInterceptorParams {
    VUE_APP_ENV: string
    sessionKey?: string | ((config?: any) => string)
    rndKeyName?: string | ((config?: any) => string)
}

export type Method =
    | 'get'
    | 'GET'
    | 'delete'
    | 'DELETE'
    | 'head'
    | 'HEAD'
    | 'options'
    | 'OPTIONS'
    | 'post'
    | 'POST'
    | 'put'
    | 'PUT'
    | 'patch'
    | 'PATCH'
    | 'purge'
    | 'PURGE'
    | 'link'
    | 'LINK'
    | 'unlink'
    | 'UNLINK'

export type commonErrorType = {
    code: number
    data?: {
        tips: string
        tipsType: number
    }
    message?: string
}
