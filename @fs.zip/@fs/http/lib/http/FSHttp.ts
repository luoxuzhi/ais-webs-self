import { FSH5Http } from './FSH5Http'
import { FSAppHttp } from './FSAppHttp/FSAppHttp'
import { isHLApp } from '@fs/utils'
import { JSBridge } from '@fs/jsbridge'
import axios from 'axios'

export function FSHttp(options) {
    if (isHLApp()) {
        return new FSAppHttp({ defaultOptions: options, adapter: JSBridge.request })
    }
    return new FSH5Http({ defaultOptions: options, adapter: axios })
}
