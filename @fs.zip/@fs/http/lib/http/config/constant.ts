// wiki链接：https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001003613
// IOS请求头值需要是String，不然无法解析
export const X_SOURCES_MAP = {
    HLAPP: '100', // 星财富APP
    HLAPP_WEB: '102', // 星财富H5 web
    HLAPP_MOBILE: '103', // 星财富H5 移动端
    THS_OEM_APP: '110', // 同花顺 APP 同花顺 OEM 版本
    THS_PC: '111', // 同花顺 PC
    WANG_TING: '112', // 网厅
    THS_APP: '113', // 同花顺公版
    PAY_WEB: '122', // 派安盈 Web
    MYLINK_APP: '130', // 中移动香港 APP MyLink
}

/**
 * 运行环境枚举
 */
export const ENV_MAP = {
    HLAPP: 1,
    WT_THS: 2,
    OTHER: 3,
}

/**
 * 加密类型枚举
 */
export const ENCRYPT_TYPES = {
    NO_ENCRYPT: 0, // 不加密
    EDCH: 1, // 临时加密
    LOGIN: 2, // 登录加密
    APP_TRADE_ENC: 3, // APP内部交易加密 - 前置校验登录密码的时候需要采用这种加密方式
    APP_TRADE_FORCE_ENC: 4, // APP内部交易加密 - 强制校验(仅APP内使用)
}

/**
 * APP encTag对应的加密字符串
 */
export const APP_ENCRYPT_TYPES = {
    [ENCRYPT_TYPES.NO_ENCRYPT]: null,
    [ENCRYPT_TYPES.LOGIN]: 'user/enc',
    [ENCRYPT_TYPES.APP_TRADE_ENC]: 'trade/enc',
    [ENCRYPT_TYPES.APP_TRADE_FORCE_ENC]: 'tradeverify/enc',
}

// 错误代码
export const ERROR_COCES = {
    SYSTEM_MAINTENANCE: 100029, // 系统维护错误码
    MYLINK_REJECT: 100034, //互踢
    MYLINK_TOKEN_EXPIRED: 100033, // token过期
}

// 后端错误码归总
export const ERROR_CODE_MAP = {
    ERROR_UIN: 100033, // ErrUin             100033
    ERROR_SESSION: 100008, // ErrSession         100008
    ERROR_SESSION_EXPIRE: 100031, // ErrSessionExpire   100031
    ERR_SESSION_REJECTED: 100034, // ErrSessionRejected 100034（互踢）
    IASIA_UNVALID_SESSION: 201004, // 柜台登录session无效 201004
    MR: 100029, // mr测试会统一返回的错误码
    ACCOUNT_SUSPENDED: 201020, // 账户被冻结
    ERROR_TOKEN: 100200, // token错误
    ERR_SESSION_WF: 100040, // wf session 错误
    ERR_SESSION_WF_EXPIRE: 100041, // wf session 过期
    ERR_SESSION_WF_REJECTED: 100042, // wf session 被踢
    ERROR_TRADE_SESSION_EXPIRE: 100032, // 交易密码过期
}

/*------- 登出code合集 -------*/
export const LOGOUT_ERROR_CODE = [
    ERROR_CODE_MAP.IASIA_UNVALID_SESSION,
    ERROR_CODE_MAP.ERROR_SESSION,
    ERROR_CODE_MAP.ERROR_SESSION_EXPIRE,
    ERROR_CODE_MAP.ERROR_UIN,
    ERROR_CODE_MAP.ERR_SESSION_REJECTED,
]
