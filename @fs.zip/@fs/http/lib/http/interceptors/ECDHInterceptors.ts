import { isHLApp } from '@fs/utils'

// 加密
import H5ECDHEncryptInterceptor from '@fs/http/lib/http/FSH5Http/encryptInterceptors/ECDHEncryptInterceptor'
// 解密
import H5ECDHDecryptInterceptor from '@fs/http/lib/http/FSH5Http/decryptInterceptors/ECDHDecryptInterceptor'

import { emptyInterceptor } from '@fs/http/lib/http/utils'

// 设置默认interceptor
let ECDHEncryptInterceptor: typeof emptyInterceptor | typeof H5ECDHEncryptInterceptor = emptyInterceptor,
    ECDHDecryptInterceptor: typeof emptyInterceptor | typeof H5ECDHDecryptInterceptor = emptyInterceptor

// 根据环境设置interceptor
if (!isHLApp()) {
    ECDHEncryptInterceptor = H5ECDHEncryptInterceptor
    ECDHDecryptInterceptor = H5ECDHDecryptInterceptor
}

export {
    ECDHEncryptInterceptor,
    ECDHDecryptInterceptor,
}
