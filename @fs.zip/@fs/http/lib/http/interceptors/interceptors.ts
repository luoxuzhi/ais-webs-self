import { isHLApp } from '@fs/utils'

import H5CommonHeaderIntercepotr from '../FSH5Http/commonHeaders'
import H5CommonErrorInterceptor from '../FSH5Http/commonErrorInterceptor'
// // 加密
// import H5LOGINEncryptInterceptor from './FSH5Http/encryptInterceptors/LOGINEncryptInterceptor'
// import H5ECDHEncryptInterceptor from './FSH5Http/encryptInterceptors/ECDHEncryptInterceptor'
// // 解密
// import H5ECDHDecryptInterceptor from './FSH5Http/decryptInterceptors/ECDHDecryptInterceptor'
// import H5LOGINDecryptInterceptor from './FSH5Http/decryptInterceptors/LOGINDecryptInterceptor'

// app 通用interceptor
import AppCommonErrortInterceptor from '../FSAppHttp/commonErrortInterceptor'
import vconsoleInterceptor from '../FSAppHttp/vconsoleInterceptor'

// arms interceptor
import ArmsInterceptor from '../arms'
// 通用数据结构组装
import handleCommnResponseInterceptor from '../common/handleCommnResponseInterceptor'
import { emptyInterceptor } from '../utils'

const arms = new ArmsInterceptor()

// 设置默认interceptor
let CommonHeaderIntercepotr: typeof emptyInterceptor | typeof H5CommonHeaderIntercepotr = emptyInterceptor,
    CommonErrorInterceptor: typeof emptyInterceptor | typeof H5CommonErrorInterceptor | typeof AppCommonErrortInterceptor = emptyInterceptor,
    // LOGINEncryptInterceptor: typeof emptyInterceptor | typeof H5LOGINEncryptInterceptor = emptyInterceptor,
    // ECDHEncryptInterceptor: typeof emptyInterceptor | typeof H5ECDHEncryptInterceptor = emptyInterceptor,
    // ECDHDecryptInterceptor: typeof emptyInterceptor | typeof H5ECDHDecryptInterceptor = emptyInterceptor,
    // LOGINDecryptInterceptor: typeof emptyInterceptor | typeof H5LOGINDecryptInterceptor = emptyInterceptor,
    VconsoleRequestInterceptor: typeof emptyInterceptor = emptyInterceptor,
    VconsoleResponseInterceptor: typeof emptyInterceptor = emptyInterceptor

const ArmsRquestInterceptor = arms.getArmsRequestInterceptor.bind(arms)
const ArmsResponseInterceptor = arms.getArmsResponseInterceptor.bind(arms)

// 根据环境设置interceptor
if (isHLApp()) {
    CommonErrorInterceptor = AppCommonErrortInterceptor
    const vconsoleItp = vconsoleInterceptor()
    VconsoleRequestInterceptor = vconsoleItp.requestInterceptor
    VconsoleResponseInterceptor = vconsoleItp.responseInterceptor
} else {
    CommonHeaderIntercepotr = H5CommonHeaderIntercepotr
    CommonErrorInterceptor = H5CommonErrorInterceptor
    // LOGINEncryptInterceptor = H5LOGINEncryptInterceptor
    // ECDHEncryptInterceptor = H5ECDHEncryptInterceptor
    // ECDHDecryptInterceptor = H5ECDHDecryptInterceptor
    // LOGINDecryptInterceptor = H5LOGINDecryptInterceptor
}

export {
    CommonHeaderIntercepotr,
    CommonErrorInterceptor,
    // LOGINEncryptInterceptor,
    // ECDHEncryptInterceptor,
    // ECDHDecryptInterceptor,
    // LOGINDecryptInterceptor,
    VconsoleRequestInterceptor,
    VconsoleResponseInterceptor,
    ArmsRquestInterceptor,
    ArmsResponseInterceptor,
    handleCommnResponseInterceptor,
}
