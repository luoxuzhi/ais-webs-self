import { isHLApp } from '@fs/utils'
// 加密
import H5LOGINEncryptInterceptor from '../FSH5Http/encryptInterceptors/LOGINEncryptInterceptor'
// 解密
import H5LOGINDecryptInterceptor from '../FSH5Http/decryptInterceptors/LOGINDecryptInterceptor'

import { emptyInterceptor } from '../utils'

// 设置默认interceptor
let LOGINEncryptInterceptor: typeof emptyInterceptor | typeof H5LOGINEncryptInterceptor = emptyInterceptor,
    LOGINDecryptInterceptor: typeof emptyInterceptor | typeof H5LOGINDecryptInterceptor = emptyInterceptor

// 根据环境设置interceptor
if (!isHLApp()) {
    LOGINEncryptInterceptor = H5LOGINEncryptInterceptor
    LOGINDecryptInterceptor = H5LOGINDecryptInterceptor
}

export {
    LOGINEncryptInterceptor,
    LOGINDecryptInterceptor,
}
