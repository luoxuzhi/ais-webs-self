import { createUUID, getFromLocalStorage } from '../utils.js'
import { APP_ENCRYPT_TYPES, ENCRYPT_TYPES } from '../config/constant.js'
import { postData, appConfigParams } from './../types/index.js'

/**
 * 标准化配置
 * @param config 配置参数
 * @returns
 */
export function normalizeConfig(config: appConfigParams) {
    const requestid = config.requestid || createUUID()
    let data: postData | any = {}
    // 设置 josnRpc 2.0
    if (config.type !== 'from') {
        // type = from 则不做 jsonRpc 处理，直接提交 from 格式
        data = {
            jsonrpc: '2.0',
            method: config.url,
            params: config.data,
            id: requestid,
        }
    }
    // 区分upload和非upload接口
    const requestBody = JSON.stringify(config.method === 'OSS_UPLOAD_FILE' ? config.data || '' : data || {})
    let queryMap = {}
    // get等请求数据放入params中
    if (!['PUT', 'POST', 'PATCH'].includes(config.method.toUpperCase())) {
        queryMap = config.params || config.data
    }

    // app是否进行接口加密标识
    // 没有读取到接口的encrypt配置时，使用rndKey来判断是否需要加密
    const defaultEncrypt = getFromLocalStorage('rndKey', '') ? ENCRYPT_TYPES.LOGIN : ENCRYPT_TYPES.NO_ENCRYPT
    const encrypt = config.encrypt ?? defaultEncrypt
    const encTag = APP_ENCRYPT_TYPES[encrypt] // app内对应的加密字符串类型

    const appParams = {
        method: config.method.toUpperCase(),
        url: config.url,
        queryMap, // get 的参数
        headerMap: {
            'X-request-id': requestid,
            'X-url': location.href,
        },
        body: requestBody,
        encTag,
    }

    const resOption = {
        ...appParams,
        ...config,
        requestid,
        getAppparams: () => {
            const keys = ['method', 'url', 'queryMap', 'headerMap', 'body', 'encTag']
            return keys.reduce((o, k) => {
                o[k] = resOption[k] // 因为外层改的都是resOption这个引用对象的数据
                return o
            }, {})
        },
    }
    return { config: resOption }
}
