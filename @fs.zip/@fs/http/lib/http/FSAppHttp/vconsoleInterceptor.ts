const requestInterceptor = {
    onFulfilled: config => {
        // @ts-ignore
        const { id } = customRequestToVconsole(config, { type: 'add', vConsole: window.vConsole }) || {}
        config.vconsoleId = id
        return config
    },
    onRejected: e => {
        return Promise.reject(e)
    },
    options: {},
}

const responseInterceptor = {
    onFulfilled: respose => {
        const startTime: number | undefined = respose.config.headerMap['X-timestamp']
        const endTime: number = new Date().getTime()
        customRequestToVconsole(respose, {
            type: 'update',
            id: respose.config.vconsoleId,
            // @ts-ignore
            vConsole: window.vConsole,
            startTime,
            endTime,
        })
        return respose
    },
    onRejected: e => {
        const startTime: number | undefined = e.config.headerMap['X-timestamp']
        const endTime: number = new Date().getTime()
        customRequestToVconsole(e, {
            type: 'update',
            id: e.config.vconsoleId,
            // @ts-ignore
            vConsole: window.vConsole,
            startTime,
            endTime,
        })
        return Promise.reject(e)
    },
    options: {},
}

// 在APP内部模拟http请求，展示到vconsole内部，方便开发
function customRequestToVconsole(res, { type = 'add', id = '', vConsole = null, startTime = 0, endTime = 0 } = {}) {
    try {
        // request的情况取得就是res作为config，response的情况取得就是res.config
        const config = res.config || res || {}
        // 必须要注册了vConsole
        if (!vConsole) return
        const method = config.method?.toUpperCase()
        const headers = Object.assign({}, config.headerMap || {}, { 'x-encTag': config.encTag })
        const options = {
            // HTTP method
            method,
            // 完整的 URL，如： https://www.abc.com/foo?a=b
            url: config.url,
            // HTTP 状态码，如： 200
            status: 200,
            // XMLHttpRequest.readyState
            readyState: () => {},
            // Response header， KV 键值对
            header: headers,
            // XMLHttpRequest.responseType
            responseType: 'json',
            // 'xhr': XMLHttpRequest, 'custom': 自定义请求
            requestType: 'custom',
            // 对应 `XMLHttpRequest.setRequestHeader()` 或 fetch 的 headers
            requestHeader: headers,
            // 回包的内容
            response: res.data,
            // 时间戳
            startTime,
            // 时间戳
            endTime,
            // Query string parameters，KV 键值对或 JSON 字符串
            getData: config.params || {},
            // Request payload，KV 键值对或 JSON 字符串
            postData: config.data || {},
        }
        if (type === 'add') {
            // @ts-ignore
            return vConsole.network[type](options)
        }
        if (type === 'update' && id) {
            // @ts-ignore
            return vConsole.network[type](id, options)
        }
        return
    } catch (error) {
        console.error(error)
    }
}

/**
 * vconsole注册拦截器
 */
export default () => {
    return {
        requestInterceptor: () => requestInterceptor,
        responseInterceptor: () => responseInterceptor,
    }
}
