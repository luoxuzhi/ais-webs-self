import { ERROR_COCES } from '../config/constant'

type CommonErrorInterceptorParams = {
    MRErrorTip?: () => any
}

/**
 * 通用错误拦截器
 */
export default (params: CommonErrorInterceptorParams) => ({
    onFulfilled: res => {
        // MR 系统维护错误提醒
        if (res?.data?.error?.code === ERROR_COCES.SYSTEM_MAINTENANCE) {
            params?.MRErrorTip?.()
            delete res.data.error.data
            return Promise.reject(res)
        }
        return Promise.resolve(res)
    },
    onRejected: res => {
        return Promise.reject(res)
    },
    options: {
        runWhen: function (config) {
            // 通过参数控制是否跳过通用错误拦截器
            if (config.skipCommonErrorInterceptor) return false
            return true
        },
    },
})
