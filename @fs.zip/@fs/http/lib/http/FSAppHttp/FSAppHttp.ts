import { appConfigParams, HttpOptions, interceptorObj, interceptors, interceptorType, interceptorTypeEnum } from './../types/index'
import { emptyOnFullfilled, emptyOnReject } from '../utils'
import { normalizeConfig } from './commonAppConfig.js'
import { JSBridge } from '@fs/jsbridge'

export class FSAppHttp {
    options: any
    interceptors: interceptors
    _instance: any
    constructor(options?: HttpOptions) {
        const { adapter = JSBridge.request, defaultOptions = {} } = options || {}

        const baseOptions = {}
        this.options = Object.assign(baseOptions, defaultOptions)

        this.interceptors = {
            request: [],
            response: [],
        }

        this._instance = adapter
    }

    get axiosInstance() {
        return this._instance
    }

    /**
     * 注册单个拦截器
     * @param {Array|Object} interceptor 拦截器
     * @param {String} type 拦截器的类型 request | response
     * @returns {Number|undefined} 拦截器对应的ID
     */
    registerInterceptor(type: interceptorType, interceptor: interceptorObj) {
        // interceptor 如果是函数则作为onFulfilled处理, 默认onRejected为空函数，并logger打印
        if (typeof interceptor === 'function') {
            // this._logger('warn', 'registerInterceptor => interceptor is function, so i will use it as onFulfilled')
            interceptor = {
                onFulfilled: interceptor,
                onRejected: emptyOnReject,
                options: {},
            }
        } else if (typeof interceptor === 'object') {
            // 会补齐用户没传的参数
            interceptor = {
                onFulfilled: interceptor.onFulfilled || emptyOnFullfilled,
                onRejected: interceptor.onRejected || emptyOnReject,
                options: interceptor.options || {},
            }
        }
        if (type === interceptorTypeEnum.req) {
            this.interceptors.request.unshift(interceptor)
        } else if (type === interceptorTypeEnum.res) {
            this.interceptors.response.push(interceptor)
        }
    }
    /**
     * 请求
     * @param options {Object} 请求参数
     * @returns {Promise} 请求结果
     */
    request(options: appConfigParams) {
        return new Promise((resolve, reject) => {
            const { config } = normalizeConfig(options)
            // this._logger('info', `FSAppHttp request config ===> `, config)
            // 可以支持对参数做一些操作
            const requestChain: Array<any> = []
            const responseChain: Array<any> = []
            const requestInterceptor: interceptorObj[] = [...this.interceptors.request]
            const responseInterceptor: interceptorObj[] = [...this.interceptors.response]

            const getOnFulfilled = onFulfilled => {
                return async response => {
                    try {
                        const res = await onFulfilled(response)
                        return Promise.resolve(res)
                    } catch (error) {
                        // this._logger('error', `interceptor newOnFulfilled error ===> `, error)
                        if (error instanceof Error) {
                            return Promise.reject(response)
                        }
                        return Promise.reject(error)
                    }
                }
            }
            const getOnRejected = onRejected => {
                return async error => {
                    try {
                        const rej = await onRejected(error)
                        return Promise.reject(rej)
                    } catch (e) {
                        if (e instanceof Error) {
                            return Promise.reject(error)
                        }
                        // this._logger('error', `interceptor newOnRejected error ===> `, e, error)
                        return Promise.reject(e)
                    }
                }
            }
            requestInterceptor.forEach(o => {
                const runWhen = (o.options as any)?.runWhen
                if (typeof runWhen === 'function' && !runWhen(config)) return
                requestChain.push(getOnFulfilled(o.onFulfilled), getOnRejected(o.onRejected))
            })
            responseInterceptor.forEach(o => {
                const runWhen = (o.options as any)?.runWhen
                if (typeof runWhen === 'function' && !runWhen(config)) return
                responseChain.push(getOnFulfilled(o.onFulfilled), getOnRejected(o.onRejected))
            })

            const execChain = [...requestChain, this.dispatchRequest(), e => Promise.reject(e), ...responseChain]

            const len = execChain.length
            let i = 0

            let requestResult = Promise.resolve(config)

            while (i < len) {
                requestResult = requestResult.then(execChain[i++], execChain[i++])
            }

            requestResult.then(resolve).catch(reject)
        })
    }

    /**
     * app内部发送请求
     * @returns {Function} 请求发送函数
     */
    dispatchRequest() {
        return c =>
            this._instance(c.requestid, c.getAppparams())
                .then(res => {
                    const newRes = {
                        config: c,
                        ...res,
                    }
                    // this._logger('warn', `FSAppHttp dispatchRequest ===> `, res, newRes)

                    return Promise.resolve(newRes)
                })
                .catch(e => {
                    const newRes = {
                        config: c,
                        ...e,
                    }
                    // this._logger('error', `FSAppHttp dispatchRequest error ===> `, e, newRes)
                    return Promise.reject(newRes)
                })
    }
    // 实现与H5 APP相同的api防止外层调用失败
    registerDecryptFunction() {}
}
