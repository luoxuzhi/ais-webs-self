import { getBooleanProperty } from '../utils'
const defaultResponseHandler = (v: any) => v

enum responseType {
    onFulfilled = 'onFulfilled',
    onRejected = 'onRejected',
}

interface HandleResponseInterceptorParams {
    responseHandler: (res: any) => any
}

const handleResponse = (type: responseType, options: HandleResponseInterceptorParams) => {
    return response => {
        const { responseHandler = defaultResponseHandler } = options || {}
        try {
            // 用于展示
            if (response.config) {
                const origin = getBooleanProperty(response.config, 'origin', true)
                if (origin) {
                    if (type === responseType.onRejected) {
                        return Promise.reject(response)
                    }
                    return Promise.resolve(response)
                }
                return response?.data?.result ? Promise.resolve(responseHandler(response.data)) : Promise.reject(responseHandler(response.data))
            }
        } catch (e) {
            return Promise.reject(responseHandler(response.data))
        }
    }
}

/**
 * 格式化返回结构响应拦截器(废弃)
 */
export default (options: HandleResponseInterceptorParams) => {
    return {
        onFulfilled: handleResponse(responseType.onFulfilled, options),
        onRejected: handleResponse(responseType.onRejected, options),
        options: {},
    }
}
