import { X_SOURCES_MAP } from './config/constant.js'
import { createUUID as _createUUID } from '@fs/utils'

export const isDeviceMobile = () => {
    const ua = navigator.userAgent.toLowerCase()
    return /android|webos|iphone|ipod|balckberry|windows phone|ipad/i.test(ua)
}

// 根据环境来区分x-source值
export function getXSource({ runenv = 1, isInMylink = false, isInThsApp = false } = {}) {
    let ret = isDeviceMobile() ? X_SOURCES_MAP.HLAPP_MOBILE : X_SOURCES_MAP.HLAPP_WEB
    //   const runenv = getRunEnv()
    if (isInMylink) {
        ret = X_SOURCES_MAP.MYLINK_APP
    } else if (runenv === 1) {
        ret = X_SOURCES_MAP.HLAPP
    } else if (isInThsApp) {
        ret = X_SOURCES_MAP.THS_APP
    } else if (runenv === 2) {
        ret = X_SOURCES_MAP.WANG_TING
    }
    return ret
}

//创建 uuid
export const createUUID = _createUUID

export const isObj = o => {
    return Object.prototype.toString.call(o).slice(8, -1) === 'Object'
}

export const emptyFnc = (o?: any) => {
    return o
}

export const getBooleanProperty = (obj, property, defaultValue) => {
    if (typeof obj[property] === 'boolean') {
        return obj[property]
    }
    return defaultValue
}

/**
 * 从localStorage中获取值，如果没有则返回默认值
 * @param {string} key 键
 * @param {*} defaultValue 默认值
 * @returns 从localStorage中获取值，如果没有则返回默认值
 */
export const getFromLocalStorage = (key, defaultValue) => {
    const value = localStorage.getItem(key)
    if (value === null || value === undefined || value === '') {
        return defaultValue
    }
    try {
        return JSON.parse(value)
    } catch (error) {
        return value
    }
}
/**
 * 代理console.log、console.error、console.warn、console.info等方法
 */
export const getLogger = function (debug = false) {
    return function (type, ...rest) {
        if (debug) {
            console[type]?.(...rest)
        }
    }
}

// 空的onFullfilled和onReject
export const emptyOnFullfilled = res => Promise.resolve(res)
export const emptyOnReject = err => Promise.reject(err)
/**
 * 空的拦截器（不做任何逻辑，仅仅是返回原始值）
 * @param options
 * @returns {Object} 拦截器对象 {onFulfilled, onRejected, options}
 */
export const emptyInterceptor = (): any | Promise<any> => ({
    onFulfilled: function (res) {
        return Promise.resolve(res)
    },
    onRejected: function (err) {
        return Promise.reject(err)
    },
    options: {},
})

export function getParamsData(dataSource, config) {
    return typeof dataSource === 'function' ? dataSource(config) : dataSource
}
