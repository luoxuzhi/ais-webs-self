import { getQueryString, isTHSI18NApp } from '@fs/utils'
import { ERROR_CODE_MAP } from '../config/constant'
import { interceptor } from '../types'
import { logoutTipForThsI18App } from './logoutError'

type optionsType = {
    Toast: any
}
/**
 * 同花顺国际版对于特殊错误码100032的处理
 */
export default (options: optionsType): interceptor => {
    return {
        onFulfilled: function (response) {
            const isInThsInternationalApp: boolean = isTHSI18NApp() && !!(getQueryString('ticket') || localStorage.getItem('thsI18NTicket'))
            if (isInThsInternationalApp) {
                if (response?.data?.error?.code === ERROR_CODE_MAP.ERROR_TRADE_SESSION_EXPIRE) {
                    logoutTipForThsI18App(options)
                    return Promise.reject(response)
                }
            }
            return response
        },
        onRejected: function (error) {
            return Promise.reject(error)
        },
        options: {},
    }
}
