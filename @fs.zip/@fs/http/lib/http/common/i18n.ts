import { getLangType } from '@fs/utils'

const map = {
    zhCn: {
        serviceTimeout: '请求超时，请稍后重试',
        requestCode: {
            dlsxqcxdl: '登录失效，请重新登录',
        },
    },
    zhTc: {
        serviceTimeout: '請求超時，請稍後重試',
        requestCode: {
            dlsxqcxdl: '登錄失效，請重新登錄',
        },
    },
}

export default {
    lang: getLangType('langType') || 'zhCn',
    fallback: 'zhCn',
    t: function (key) {
        return getProp(map[this.lang], key, key) || getProp(map[this.fallback], key, key)
    },
}

function getProp(object: {}, keys: Array<string> | string, defaultVal?: string): any {
    keys = Array.isArray(keys) ? keys : keys.split('.')
    object = object[keys[0]]
    if (object && keys.length > 1) {
        return getProp(object, keys.slice(1))
    }
    return object === undefined ? defaultVal : object
}
