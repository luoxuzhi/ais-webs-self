import { getQueryString, isTHSApp, isTHSI18NApp } from '@fs/utils'
import { mylinkJSBridge, thsI18NJsBridge } from '@fs/jsbridge'
import i18n from './i18n.js'
import { ERROR_CODE_MAP } from '../config/constant.js'
import { CommonErrorInterceptorParams, commonErrorType } from '../types/index.js'

type errorType = commonErrorType

/**
 * 登出后的数据清除逻辑
 * @param options commonErrorInterceptor函数的参数
 * @param error 后端返回的错误对象
 * @returns void
 */
export function afterLogout(options, error: errorType): void {
    clearLoginInfo()
    // mylink渠道登出特殊处理逻辑
    if (mylinkJSBridge.isInMylink()) {
        return logoutTipForMyLink(options, error)
    }
    // 同花顺登出特殊处理
    if (isTHSApp()) {
        return logoutTipForThs()
    }
    // 同花顺国际版登出特殊处理
    if (isTHSI18NApp() && (getQueryString('ticket') || localStorage.getItem('thsI18NTicket'))) {
        return logoutTipForThsI18App(options)
    }
}

/**
 * 清除通用的登录信息
 */
function clearLoginInfo() {
    const localStorageKeys: string[] = ['uin', 'session', 'rndkey', 'userInfo', 'WTtoken', 'WTuserName', 'sub', 'accts', 'rndKey2', 'session2']
    localStorageKeys.forEach(k => localStorage.removeItem(k))
}

/**
 * mylink对于登出的操作
 * @param {*} options
 * @param {*} error
 */
const logoutTipForMyLink = (options: CommonErrorInterceptorParams, error: errorType) => {
    // 兼容一些页面不需要登录态的情况
    const isChinaMobileHK: string | boolean = getQueryString('isChinaMobileHK') || getQueryString('isChinaMobileHK', true)
    const FROM_CHINA_MOBILE_HK: string = '1'
    const isComeFromActivityPage: boolean = isChinaMobileHK === FROM_CHINA_MOBILE_HK
    if (isComeFromActivityPage) {
        return
    }
    if (error?.code === ERROR_CODE_MAP.ERROR_UIN) {
        // token过期
        options?.Toast({
            forbidClick: true,
            message: i18n.t('requestCode.dlsxqcxdl'),
            onClose: () => {
                mylinkJSBridge.backToHomePage()
            },
        })
        return
    }
    if (error?.code === ERROR_CODE_MAP.ERR_SESSION_REJECTED) {
        // 互踢
        options?.CMHKLogoutInstance?.open()
        return
    }
}

/**
 * 同花顺国内版对于登出的操作
 */
function logoutTipForThs(): void {
    // @ts-ignore
    // eslint-disable-next-line no-undef
    callNativeHandler('goback', { type: 'component' }, function () {})
}

/**
 * 同花顺国际版对于登出的通用处理
 */
export function logoutTipForThsI18App(options: CommonErrorInterceptorParams): void {
    options?.Toast(i18n.t('requestCode.dlsxqcxdl'))
    localStorage.clear()
    thsI18NJsBridge.closeWebPage()
}
