import { interceptor } from '../types/index'
import { getBooleanProperty } from '../utils'

type responseType = 'rejected' | 'fulfilled'

function getHandleResponse(type: responseType) {
    return function handleResponse(response) {
        const origin = getBooleanProperty(response?.config || {}, 'origin', false)
        if (origin) {
            return response
        }
        //组合返回数据结构
        const resData = {
            error: response?.data?.error,
            result: response?.data?.result,
        }
        return type === 'fulfilled' ? Promise.resolve(resData) : Promise.reject(response.data)
    }
}

/**
 * 通用响应结果拦截器
 */
export default (): interceptor => {
    return {
        onFulfilled: getHandleResponse('fulfilled'),
        onRejected: getHandleResponse('rejected'),
        options: {},
    }
}
