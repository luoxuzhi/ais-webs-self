import { armsInit, armsSetHeader, sendArms, ArmsOption } from '@fs/utils'

export default class ArmsInterceptor {
    static armsInstance: any
    // arms: any
    static armsOptions: ArmsOption
    // _logger: any
    constructor() {}

    get arms() {
        if (!ArmsInterceptor.armsInstance) {
            ArmsInterceptor.armsInstance = armsInit({ options: ArmsInterceptor.armsOptions })
        }
        return ArmsInterceptor.armsInstance
    }

    /*------- request interceptor for arms  -------*/
    getArmsRequestInterceptor(options: ArmsOption) {
        ArmsInterceptor.armsOptions = options || ArmsInterceptor.armsOptions
        const self = this
        return {
            onFulfilled: function (config) {
                armsSetHeader({ headers: config.headers || config.headerMap, arms: self.arms })
                return config
            },
            onRejected: function (e) {
                // this._logger('error', 'getArmsRequestIntercepotr e ===>', e)
                return Promise.reject(e)
            },
            options: {},
        }
    }
    /*------- response interceptor for arms  -------*/
    getArmsResponseInterceptor(options: ArmsOption) {
        ArmsInterceptor.armsOptions = options || ArmsInterceptor.armsOptions
        const self = this
        return {
            onFulfilled: function (response) {
                // this._logger('info', 'getArmsResponseIntercepotr response ===>', response)
                const sArms = (options as any)?.sendArms || sendArms
                sArms({ response, arms: self.arms })
                return response
            },
            onRejected: error => {
                // this._logger('error', 'getArmsResponseIntercepotr error ===>', error)
                const sArms = (options as any)?.sendArms || sendArms
                sArms({ error, arms: this.arms })
                return Promise.reject(error)
            },
            options: {},
        }
    }
}
