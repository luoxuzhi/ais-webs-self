### 使用方式

```javascript
import { FSHttp } from '@fs/http'
// 内部导出的拦截器是作为一个方法，是因为可能需要一些外部传入的参数
import { CommonHeader, CommonError } from '@fs/http/dist/interceptors'

// 初始化http
const baseOptions = {
    baseURL: 'https://sit.mfosunhani.com',
    timeout: 15000
} // 基础的http请求参数，支持axios的所有基础参数
const http = new FSHttp(baseOptions)

// 用户自己参数
// http实例 参数
// request 参数 - config | response

// 新增http request interceptor - 第二个参数是拦截器对象，
// NOTE: http内部导出的拦截器是作为一个方法，因为需要一些外部传入的参数
/*
{
  onFulfilled: (value: any) => any
  onRejected: (error: any) => error
  options: any
}
*/
// NOTE: request interceptor的执行顺序跟随axios，先注册的后执行。
http.registerInterceptor(type: 'request' | 'response', CommonHeader(config))

//  新增http response interceptor
http.registerInterceptor(type: 'request' | 'response', CommonError(config))


// 发起请求
// config 包含 params｜data 、 origin、encrypt、
http.request({ url, method, ...config })

```

### 内部支持的拦截器（内部会区分app和H5）

    - CommonHeaderIntercepotr: 请求头拦截器
    - CommonErrorInterceptor: 通用错误拦截器
    - LOGINEncryptInterceptor: 对称加密拦截器（登录后是用的加密方式）
    - ECDHEncryptInterceptor: 非对称加密拦截器（主要用于登录前的加密方式）
    - HandleResponseInterceptor: 响应结果处理
    - ECDHDecryptInterceptor: 非对称加密拦截器（主要用于登录前的解密方式）
    - LOGINDecryptInterceptor: 对称加密拦截器（登录后是用的解密方式）
    - VconsoleRequestInterceptor: app内部vconsole network展示请求数据
    - VconsoleResponseInterceptor: app内部vconsole network展示请求数据
    - ArmsRquestInterceptor: arms上报请求拦截器
    - ArmsResponseInterceptor: arms上报响应拦截器

### NOTE: 用户注册的拦截器会执行在内部拦截器（加密、解密、arms上报、通用错误处理）中间，如下图所示

![拦截器执行流程图](https://www.tapd.cn/tfl/pictures/202402/tapd_60236733_1708483255_473.png)

### NOTE：vconsoleInterceptor使用时需要额外注意的内容

![lQDPKcfDp4OTm0PNBQDNAk-w4Nnoc_ZN0a0FnaZfD8NyAA_591_1280.jpg](/tfl/pictures/202401/tapd_60236733_1705909474_596.jpg)

-   需要在 package.json 文件中增加 vconsole-webpack-plugin，并在 vue.config.js 中引入并注册。动态插入 vconsole 插件,主要代码为以下几步

```json
"devDependencies": {
        "vconsole-webpack-plugin": "^1.7.3",
    }
```

```javascript
const vConsolePlugin = require('vconsole-webpack-plugin');  // 动态插入vconsole

//注册
plugins: [
	new vConsolePlugin({ enable: process.env.VUE_APP_ENV !== 'prod' }) // 生产不注册该插件
],
```
