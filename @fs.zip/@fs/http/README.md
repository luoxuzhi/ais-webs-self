# @fs/http

@fs/http 是一个包含H5和Fosun APP请求的通用库

---

## 快速开始

### 主页

http://gl.fotechwealth.com.local/H5/common/tree/release/projects/@fs-http

### 安装

```bash
yarn add @fs/http

```

### API

[API 文档](http://gl.fotechwealth.com.local/H5/common/tree/release/projects/@fs-http/doc)
