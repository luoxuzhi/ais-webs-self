module.exports = {
    printWidth: 150, //行宽
    semi: false, //分号
    singleQuote: true, // 使用单引号
    useTabs: false, //使用 tab 缩进
    tabWidth: 4, //缩进
    trailingComma: 'es5', //后置逗号，多行对象、数组在最后一行增加逗号
    arrowParens: 'avoid', //箭头函数只有一个参数的时候可以忽略括号
    bracketSpacing: true, //括号内部不要出现空格
    proseWrap: 'preserve', //换行方式 默认值。因为使用了一些折行敏感型的渲染器（如GitHub comment）而按照markdown文本样式进行折行
    endOfLine: 'auto', // 结尾是 \n \r \n\r auto
    jsxSingleQuote: false, // 在jsx中使用单引号代替双引号
    jsxBracketSameLine: false, //在jsx中把'>' 是否单独放一行
    htmlWhitespaceSensitivity: 'ignore',
}
