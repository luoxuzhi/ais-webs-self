## 安装

```
yarn add @fs/prettier-config -D
```

## 使用

在项目 `package.json` 文件中写入

```
{
  "prettier": "@fs/prettier-config"
}
```
