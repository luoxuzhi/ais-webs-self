## 说明

该项目基于`stylelint-config-recommended-vue` v1.5 分支改造, 并移除了测试代码、代码风格

https://www.npmjs.com/package/stylelint-config-recommended-vue/v/1.5.0
