module.exports = {
    extends: ['@fs/stylelint-config-recommended-vue', 'stylelint-config-prettier', 'stylelint-config-rational-order', 'stylelint-config-standard'],
    rules: {
        // 'at-rule-no-unknown': [
        //     true,
        //     {
        //         ignoreAtRules: ['mixin', 'include', 'extend'],
        //     },
        // ],
        'at-rule-no-unknown': null,
        'function-no-unknown': null,
        'keyframes-name-pattern': [
            '^([a-z][a-z0-9]*)(-[a-z0-9]+)*$',
            {
                message: name => `Expected keyframe name "${name}" to be kebab-case`,
                severity: 'warning',
            },
        ],
        'no-empty-source': null,
        'selector-pseudo-class-no-unknown': [true, { ignorePseudoClasses: ['deep', 'placeholder', 'input-placeholder'] }],
        'selector-pseudo-element-no-unknown': [
            true,
            {
                ignorePseudoElements: ['v-deep', '/deep/', 'input-placeholder'],
            },
        ],

        // // vue3 css支持v-bind
        // 'function-no-unknown': [true, { ignoreFunctions: ['v-bind', 'constant'] }],

        // class BEM命名规则
        'selector-class-pattern': [
            '^[a-z]([-]?[a-z0-9]+)*(__[a-z0-9]([-]?[a-z0-9]+)*)?(--[a-z0-9]([-]?[a-z0-9]+)*)?$',
            {
                resolveNestedSelectors: true,
                message: function expected(selectorValue) {
                    return `Expected class selector "${selectorValue}" to match BEM CSS pattern`
                },
                severity: 'warning',
            },
        ],

        // id BEM命名规则
        'selector-id-pattern': [
            '^[a-z]([-]?[a-z0-9]+)*(__[a-z0-9]([-]?[a-z0-9]+)*)?(--[a-z0-9]([-]?[a-z0-9]+)*)?$',
            {
                resolveNestedSelectors: true,
                message: function expected(selectorValue) {
                    return `Expected id selector "${selectorValue}" to match BEM CSS pattern`
                },
                severity: 'warning',
            },
        ],

        // 媒体查询
        'media-feature-name-no-unknown': [
            true,
            {
                ignoreMediaFeatureNames: ['min-device-pixel-ratio'],
            },
        ],

        'no-descending-specificity': null,
        'font-family-no-missing-generic-family-keyword': null,
        'import-notation': null,
        'color-function-notation': null,
        'media-feature-range-notation': null,
        'alpha-value-notation': null,
        'number-max-precision': null,
        'declaration-block-no-redundant-longhand-properties': null, // 样式缩写
        'selector-no-vendor-prefix': null,
        'media-feature-name-no-vendor-prefix': null, // 媒体查询前缀
    },
}
