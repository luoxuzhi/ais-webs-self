module.exports = {
    extends: ['stylelint-config-standard-scss', './index'],
    rules: {
        'scss/no-global-function-names': null,
        'scss/dollar-variable-pattern': [
            '^(-?[a-z][a-z0-9]*)(-[a-z0-9]+)*$',
            {
                message: 'Expected variable to be kebab-case',
                severity: 'warning',
            },
        ],

        'scss/at-function-pattern': [
            '^(-?[a-z][a-z0-9]*)(-[a-z0-9]+)*$',
            {
                message: 'Expected function name to be kebab-case',
                severity: 'warning',
            },
        ],

        'scss/at-mixin-pattern': [
            '^(-?[a-z][a-z0-9]*)(-[a-z0-9]+)*$',
            {
                message: 'Expected mixin name to be kebab-case',
                severity: 'warning',
            },
        ],
    },
}
