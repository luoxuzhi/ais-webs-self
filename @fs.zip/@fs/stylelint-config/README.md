## 安装

```
yarn add stylelint @fs/stylelint-config -D
```

## 使用

创建文件 `.stylelintrc.js`

```
// less project
{
     extends: ['@fs/stylelint-config/less'],
}

// scss project
{
     extends: ['@fs/stylelint-config/scss'],
}
```

## IDE 调整

vscode 配置

```
{
  "stylelint.enable": true,
  "stylelint.validate": [
    "css",
    "scss",
    "less",
    "vue"
  ],
  "css.validate": false,
  "less.validate": false,
  "scss.validate": false,
  "editor.codeActionsOnSave": {
    "source.fixAll.stylelint": true, // 开启stylelint自动修复
  },
}
```
