module.exports = {
    extends: ['stylelint-config-standard-less', './index'],
}
