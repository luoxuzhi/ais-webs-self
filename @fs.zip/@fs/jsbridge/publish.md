## 配置 package.json

-   name: 包名
    如 @demo/tools, 其中`@demo` 模块名，`/` 分隔符， `tools` 包名；

-   version: 版本号
    如 1.2.3， 其中 `1` 主版本号，重大更新，`2` 次版本号, 新功能 `3` 修订号，修复 bug；

-   详情配置
    参考链接：https://juejin.cn/post/7145759868010364959

## 发布

```bash
yarn npm login
```

```
yarn publish
```
