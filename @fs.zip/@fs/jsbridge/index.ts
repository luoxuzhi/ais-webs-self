// 自研app jsbridge
// import JSBridge from 'jsbridge'
import JSBridge from './lib/jsBridge'

// mylink jsbridge
// import mylinkJSBridge from 'jsbridge/mylinkJsbridge'
import mylinkJSBridge from './lib/mylinkJsBridge'

// 渠道app jsbridge
// import channelJSBridge from 'jsbridge/channelJsBridge'
import channelJSBridge from './lib/channelJsBridge'

// 同花顺 jsbridge
import thsJsBridge from './lib/thsJsBridge'
// 同花顺国际版 jsbridge
import thsI18NJsBridge from './lib/thsI18NJsBridge'

export { JSBridge, mylinkJSBridge, channelJSBridge, thsJsBridge, thsI18NJsBridge }
