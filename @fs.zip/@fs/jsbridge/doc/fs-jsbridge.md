## fs-jsbridge

jsbridge 库

### 自研 app jsbridge、mylink jsbridge、渠道 app jsbridge 的调用方式

```javascript
import { JSBridge, mylinkJSBridge, channelJSBridge } from '@fs/jsbridge'

// 调用相关方法
// 自研app
JSBridge.close()
// mylink
mylinkJSBridge.close()
// 渠道app
channelJSBridge.close()
```

### 同花顺 jsbridge 的调用方式

```javascript
import { thsJsBridge } from '@fs/jsbridge'

// 初始化配置
thsJsBridge()
```

### 按需引入 jsbridge 的调用方式

```javascript
import thsJsBridge from '@fs/jsbridge/dist/lib/thsJsBridge.js'
import JSBridge from '@fs/jsbridge/dist/lib/jsBridge.js'
import channelJSBridge from '@fs/jsbridge/dist/lib/channelJsBridge.js'
import mylinkJSBridge from '@fs/jsbridge/dist/lib/mylinkJsBridge.js'

// 同花顺初始化配置
thsJsBridge()
// 自研app
JSBridge.close()
// mylink
mylinkJSBridge.close()
// 渠道app
channelJSBridge.close()
```
