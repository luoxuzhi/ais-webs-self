// MYLINK的JSBridge

function system() {
    const name = window.navigator.userAgent.match(/hshhk\/([^/]+)\//)?.[1]
    if (!name) throw new Error('system name is undefined')
    return name
}

function callAndroidJsbridge(event?: any, obj?: any) {
    !event && (event = obj.event)
    obj && typeof obj === 'object' && (obj = JSON.stringify(obj))
    return [undefined, null].includes(obj) ? window?.HkAndroid?.[event]() : window?.HkAndroid?.[event](obj)
}
function callIosJsbridge(event, obj) {
    !event && (event = obj.event)
    obj && typeof obj === 'object' && (obj = JSON.stringify(obj))
    return [undefined, null].includes(obj)
        ? window?.webkit?.messageHandlers?.[event]?.postMessage()
        : window?.webkit?.messageHandlers?.[event]?.postMessage(obj)
}
// jsbridge 函数抽象定义，不包含实现
const ABSOULTE_JSBRIDGE = {
    backToHomePage: function () {},
    changeThemeColor: function () {},
    closeWebview: function () {},
    createDotsWithCustomActions: function () {},
    enterLiveRoom: function () {},
    fetchContacts: function () {},
    fetchCurrentUserRandkingData: function () {},
    fetchRandkingDatas: function () {},
    getAdAuthJsonWithCallback: function () {},
    getAppMode: function () {},
    getBossInfoWithCallback: function () {},
    getCurrentThemeColor: function () {},
    getDeviceInfoWithCallback: function () {},
    getH5Cache: function () {},
    getIDCamera: function () {},
    getRoamingSubAccount: function () {},
    getVersionInfoWithCallback: function () {},
    getWeatherIcon: function () {},
    h5Cache: function () {},
    initShare: function () {},
    logEventStatistics: function () {},
    onNativeBackClick: function () {},
    openThirdPartyApp: function () {},
    pageViewStatistics: function () {},
    registerAsMyLinkMember: function () {},
    requestContactPermission: function () {},
    saveInviteUserPosterToAlbum: function () {},
    savePhotoToAlbum: function () {},
    sendMessages: function () {},
    setEmergencyButton: function () {},
    setNavibarAlpha: function () {},
    setNavibarTintColor: function () {},
    setNavigationButtons: function () {},
    setPandaCamera: function () {},
    shakeEnd: function () {},
    shakeStart: function () {},
    sharePicTo: function () {},
    shareTo: function () {},
    stepCountStatusCallBack: function () {},
    tokenInvalidAction: function () {},
    updateUserInfo: function () {},
}

// 已经得到实现的JSBRIDGE，也包含了一些新定义函数（不是jsBridge）
const MYLINK_JSBRIDGE = {
    /**
     * 是否为mylink内
     * @returns {Boolean}
     */
    isInMylink: function () {
        return /hshhk/.test(window.navigator.userAgent)
    },
    registerCallback: function (callback: string = '', success: Function = () => {}, failure: Function = () => {}) {
        if (!callback) {
            const EXPAND_TIMES = 10000
            callback = `mylink_${Date.now()}${Math.floor(Math.random() * EXPAND_TIMES)}`
        }
        console.log(`Feng.chen:: 11:03:55 callback ===> `, callback)
        window[callback] = (data: any, err: any) => {
            console.log(`Feng.chen:: 10:58:30 data ===> `, data)
            success(data)
            if (err) {
                return failure(err)
            }
        }
        return callback
    },
    /**
     * 调用app的事件
     * @param {String} event 调用的jsbridge的事件名
     * @param {Object} obj 参数对象
     * @returns { Promise }
     */
    callApp: function (event?: any, options?: any) {
        let resolve: any = null
        let reject: any = null
        const retPromise = new Promise((res, rej) => {
            resolve = res
            reject = rej
        })
        try {
            const name = system()
            const isAndroid = name === 'android' // android终端
            const isiOS = name === 'ios' // ios终端
            // 由于安卓和IOS存在差异性 - 仅需要的jsBridge会传入callbackName
            if (options?.needCallback) {
                delete options.needCallback // 删除多余的参数
                // 注册回调
                options.callbackName = this.registerCallback(options.callbackName, resolve, reject)
            } else {
                // 不需要回调的事件，直接完成promise
                resolve()
            }
            let ret: any = null
            if (isAndroid) {
                ret = callAndroidJsbridge(event, options)
            }
            if (isiOS) {
                ret = callIosJsbridge(event, options)
            }
            console.log(event, ' ====> ', ret)
            ret?.then(d => {
                console.log(d)
            })
        } catch (error) {
            reject(error)
        }
        return retPromise
    },
    getLocationHandlerName: function () {
        return this.callApp('getLocationHandlerName')
    },
    /**
     * mylink APP是否为IOS
     * @returns {Boolean}
     */
    isIos() {
        return system() === 'ios'
    },
    /**
     * 设置右上角按钮 type 1-分享，2-拨号 目前只支持了分享
     * obj:{type:number, url: string, title: string, content: string }
     * @param {*} obj
     */
    share(obj) {
        obj.img = obj.img || `https://mylink.oss-accelerate.aliyuncs.com/mylinkH5/shareLogo/shareLogo`
        const name = system()
        const isAndroid = name === 'android' // android终端
        const isiOS = name === 'ios' // ios终端
        let fun = ''
        // 分享
        if (obj.type === 1) {
            if (isAndroid) {
                fun = 'initShare'
            }
            if (isiOS) {
                fun = 'setShareButton'
            }
        }
        // 紧急电话
        // if (obj.type === 2) {
        //     fun = 'setEmergencyButton'
        // }
        obj = JSON.stringify(obj)
        if (isAndroid) {
            // 调用原生的分享功能
            window.HkAndroid && window.HkAndroid[fun](obj)
        }
        if (isiOS) {
            // 调用原生的分享功能
            window.webkit &&
                window.webkit.messageHandlers &&
                window.webkit.messageHandlers[fun] &&
                window.webkit.messageHandlers[fun].postMessage(obj)
        }
    },
    /**
     * imgUrl: 保存图片的url
     * @param {*} obj:{imgUrl: string}
     */
    //客户端保存图片到相册
    savePhoto(obj) {
        const name = system()
        const isAndroid = name === 'android' // android终端
        const isiOS = name === 'ios' // ios终端
        obj = JSON.stringify(obj)
        if (isAndroid) {
            // 调用原生的分享功能
            window.HkAndroid && window.HkAndroid.savePhotoToAlbum(obj)
        }
        if (isiOS) {
            // 调用原生的分享功能
            window.webkit &&
                window.webkit.messageHandlers &&
                window.webkit.messageHandlers.savePhotoToAlbum &&
                window.webkit.messageHandlers.savePhotoToAlbum.postMessage(obj)
        }
    },
    /**
     * mylink APP是否为Android
     * @returns {Boolean}
     */
    isAndroid() {
        return system() === 'android'
    },
    /**
     * 返回到mylink APP页面
     * NOTE：安卓和IOS的表现形式不一致，需要进行测试后看是否符合需求
     * @returns {Promise} promise
     */
    backToHomePage: function () {
        let ops: any = ''
        if (this.isAndroid()) {
            ops = undefined
        } else if (this.isIos()) {
            ops = {}
        }
        return this.callApp('backToHomePage', ops)
    },
    /**
     * 关闭所有Webview
     * NOTE：IOS正常，安卓9.2.0之前版本是只能关一个webview，之后的版本会在调用的时间增加一个“closeAll”参数可正常支持。
     * @returns {Promise}
     */
    closeWebview: async function () {
        let opt = ''
        if (this.isAndroid()) {
            // TODO 需要mylink 在五月上旬的版本才支持，因此需要此功能的安卓需暂时采用backToHomePage
            const [, , appVersion] = window.navigator.userAgent.split(/\//)
            const SUPPORT_VERSION = '9.3.0'
            const compareVersion = function (a = '', b = '') {
                let ret = 0
                const aR = a.split('.')
                const bR = b.split('.')
                const maxLen = Math.max(aR.length, bR.length)
                for (let i = 0, aV = 0, bV = 0; i < maxLen; i++) {
                    aV = +aR[i]
                    bV = +bR[i]
                    if (aV < bV) {
                        ret = -1
                        break
                    }
                    if (aV > bV) {
                        ret = 1
                        continue
                    }
                }
                return ret
            }
            if (compareVersion(appVersion, SUPPORT_VERSION) === -1) {
                return this.backToHomePage()
            }
            opt = 'closeAll'
        } else if (this.isIos()) {
            opt = ''
        }
        return this.callApp('closeWebview', opt)
    },
    /**
     * 关闭當前Webview
     * NOTE：因為IOS和安卓沒有統一的jsBridge支持，因此单独封装
     * @returns {undefined}
     */
    closeCurrentWebview: function () {
        if (this.isAndroid()) {
            location.href = 'cmcchkh5action://close'
            return
        } else if (this.isIos()) {
            this.onNativeBackClick()
            return
        }
    },
    getAppMode: function () {
        return this.callApp('getAppMode')
    },
    /**
     * 获取mylink的osVersion对应的具体安卓系统版本
     * @returns {Promise}
     */
    getAndroidApiVersionMap() {
        return {
            33: '13',
            32: '12',
            31: '12',
            30: '11',
            29: '10',
            28: '9',
            27: '8',
            26: '7',
        }
    },
    /**
     * 获取用户设备的设备信息
     * @returns {Promise} { osVersion, appVersion, device, deviceId, network, os, phone, platform, resolution, userType }
     */
    getDeviceInfoWithCallback: function () {
        return this.callApp('getDeviceInfoWithCallback', {
            needCallback: true,
        }).then((res: any) => {
            let osVersion = res.osVersion

            const name = system()
            const isAndroid = name === 'android' // android终端

            osVersion = res.os?.toLowerCase().split(name)[1]?.replace(/\s/g, '')

            if (isAndroid) {
                const AndroidApiVersionMap = this.getAndroidApiVersionMap()
                osVersion = AndroidApiVersionMap[osVersion]
            }

            return {
                osVersion: osVersion ?? '',
                ...res,
            }
        })
    },
    /**
     * 关闭当前Webview
     * NOTE（调用后效果不一致）:
     *  安卓：后退为上一个路由
     *  IOS：关闭当前webview
     * @param {*} opt
     * @returns
     */
    onNativeBackClick: function (opt?: any) {
        if (!opt) {
            if (this.isAndroid()) {
                opt = undefined
            } else if (this.isIos()) {
                opt = ''
            }
        }
        return this.callApp('onNativeBackClick', opt)
    },
    /**
     *
     * @param {Object} obj 参数对象
     * @param {Boolean} obj.backVisible 是否展示返回按钮
     * @param {String} obj.right1icon 右上角第一个按钮类型 已知：btn_ol_close - 关闭
     * @param {String} obj.right1link 右上角第一个按钮操作 已知：closeAll -> 1、cmcchkh5action://close - 关闭所有webview close -> 2、cmcchkh5action://callJSfunction?function=onNativeBackClick()
     * @param {String} obj.right2icon 右上角第二个按钮类型 已知：btn_ol_close - 关闭
     * @param {String} obj.right2link 右上角第二个按钮操作 已知：cmcchkh5action://close - 关闭所有webview
     * @returns
     */
    setNavigationButtons: function (obj: any = {}) {
        const { right1link = '', right2link = '' }: any = obj
        // 注册全局onNativeBackClick函数
        const registerCloseCurrentWebview = context => {
            window.closeCurrentWebview = () => {
                context.closeCurrentWebview()
            }
        }
        // Android关闭全部webvie需要注册全局closeWebview函数
        const registerCloseAllWebview = context => {
            window.closeWebview = () => {
                context.closeWebview()
            }
        }
        // 格式化key
        const normarlizeKey = (key: string = 'close') => {
            let ret = ''
            // 'cmcchkh5action://close'
            // 安卓：关闭当前webview
            // IOS: 关闭全部webview
            switch (key) {
                case 'closeAll':
                    ret = 'cmcchkh5action://callJSfunction?function=closeWebview()'
                    break
                case 'close':
                    ret = 'cmcchkh5action://callJSfunction?function=closeCurrentWebview()'
                    break
                default:
                    break
            }
            return ret
        }
        // close 的情况下需要注册全局函数来处理事件
        if (right1link === 'close' || right2link === 'close') {
            registerCloseCurrentWebview(this)
        }
        // closeALL && system为Android 的情况下需要注册全局函数来处理事件
        if (right1link === 'closeAll' || right2link === 'closeAll') {
            registerCloseAllWebview(this)
        }
        // 格式化right1|2link
        const needNormalizeKeys = ['right1link', 'right2link']
        needNormalizeKeys.forEach(k => {
            if (k in obj) {
                obj[k] = normarlizeKey(obj[k])
            }
        })

        return this.callApp('setNavigationButtons', obj)
    },
    /**
     * 打开新的webview
     * @param {String} link 网站链接包含完整的协议
     * @returns
     */
    openH5InWebview: function (link?: string) {
        return (location.href = `openurl-modal://${link}`)
    },
    /**
     * 打开站外浏览器
     * @param {String} link 网站链接包含完整的协议
     * @returns
     */
    openH5InBrowser: function (link: string = '') {
        return (location.href = `openurl-extern-silent://${link}`)
    },
    /**
     * 调起登录页面
     * @param {String} link 登录完成之后跳转的页面地址，如果需要回到登陆之前的页面可以`不传`或者`之前页面的地址`
     * @returns
     */
    login: function (link: string = '') {
        return (location.href = `openhkhshlogin://${link}`)
    },
}

Object.setPrototypeOf(MYLINK_JSBRIDGE, ABSOULTE_JSBRIDGE)

export default MYLINK_JSBRIDGE
