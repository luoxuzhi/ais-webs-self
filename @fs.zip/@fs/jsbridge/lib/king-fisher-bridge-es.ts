/* eslint-disable prefer-rest-params */
/* eslint-disable no-var */
/* eslint-disable no-empty */
/* eslint-disable max-params */
/* eslint-disable vars-on-top */
// @ts-nocheck

var n = function () {
        return (
            (n =
                Object.assign ||
                function (n) {
                    for (var e, a = 1, i = arguments.length; a < i; a++)
                        for (var o in (e = arguments[a])) Object.prototype.hasOwnProperty.call(e, o) && (n[o] = e[o])
                    return n
                }),
            n.apply(this, arguments)
        )
    },
    e = function () {
        return String(Math.random()).slice(-6) + String(+new Date()).slice(-6)
    },
    a = function (n) {
        if ('string' === typeof n && '{' === n[0])
            try {
                return JSON.parse(n)
            } catch (e) {
                return n
            }
        return n
    },
    i =
        void 0 !== window._falcon
            ? function (n) {
                  var e = n.actionName,
                      i = n.componentName,
                      o = n.objectId,
                      t = n.syncFuncName,
                      c = n.params,
                      r = n.callbackId,
                      d = r ? window.prompt(e, JSON.stringify([i, o, t, c, r])) : window.prompt(e, JSON.stringify([i, o, t, c]))
                  return a(d)
              }
            : void 0 !== window.FalconJavaInterface
            ? function (n) {
                  var e = n.actionName,
                      i = n.componentName,
                      o = n.objectId,
                      t = n.syncFuncName,
                      c = n.params,
                      r = n.callbackId,
                      d = r ? window.FalconJavaInterface[e](i, o, t, JSON.stringify(c), r) : window.FalconJavaInterface[e](i, o, t, JSON.stringify(c))
                  return a(d)
              }
            : function (n) {},
    o = {
        initCallFalconNative: function () {
            return (
                window.Falcon ||
                    (window.Falcon = {
                        _callbackMap: {},
                        _addCallback: function (n, a) {
                            var i = (a || '') + '-' + e()
                            return (window.Falcon._callbackMap[i] = n), i
                        },
                        _callbackMapOn: {},
                        _addCallbackOn: function (n, a) {
                            var i = (a || '') + '-' + e()
                            return (window.Falcon._callbackMapOn[i] = n), i
                        },
                        _addEventCallback: function (n, e) {
                            var a = window.Falcon._callbackMap[n]
                            a || ((a = new Set()), (window.Falcon._callbackMap[n] = a)), a.add(e)
                        },
                        _removeEventCallback: function (n, e) {
                            if (e) {
                                var a = window.Falcon._callbackMap[n]
                                a && (a.delete(e), 0 === a.size && delete window.Falcon._callbackMap[n])
                            } else delete window.Falcon._callbackMap[n]
                        },
                        callback: function (n, e) {
                            var i = window.Falcon._callbackMap[e]
                            if (i) return i(a(n)), void delete window.Falcon._callbackMap[e]
                            var o = window.Falcon._callbackMapOn[e]
                            o && o(a(n))
                        },
                        call: function (n, e) {
                            var i,
                                o = window.Falcon._callbackMap[n]
                            if (o)
                                return (
                                    o.forEach(function (n) {
                                        i = n(a(e))
                                    }),
                                    i
                                )
                        },
                        sendCustomEvent: function (n, e) {
                            var i,
                                o = window.Falcon._callbackMap[n]
                            if (o)
                                return (
                                    o.forEach(function (n) {
                                        i = n(a(e))
                                    }),
                                    i
                                )
                        },
                    }),
                (window.falconCallback = window.Falcon.callback),
                (window.falconCall = window.Falcon.call),
                (window.falconSendCustomEvent = window.Falcon.sendCustomEvent),
                window.Falcon
            )
        },
        callNativeHandlerSync: function (n, e) {
            return i({ actionName: 'invokeSync', componentName: 'fl', objectId: '', syncFuncName: n, params: e })
        },
        callNativeHandlerAsync: function (n, e, a, o) {
            var t,
                c = null === (t = window.Falcon) || void 0 === t ? void 0 : t._addCallback(a, n)
            i({ actionName: 'invokeAsync', componentName: o ? n : 'fl', objectId: o || '', syncFuncName: n, params: e, callbackId: c })
        },
        callNativeHandlerObj: function (n, e, a, o, t, c) {
            var r, d
            void 0 === c && (c = !1)
            var w = c
                ? null === (r = window.Falcon) || void 0 === r
                    ? void 0
                    : r._addCallbackOn(o, e)
                : null === (d = window.Falcon) || void 0 === d
                ? void 0
                : d._addCallback(o, e)
            return i({ actionName: 'invokeAsync', componentName: n, objectId: t || '', syncFuncName: e, params: a, callbackId: w }), w
        },
        callNativeHandlerObjSync: function (n, e, a, o) {
            return i({ actionName: 'invokeSync', componentName: n, objectId: o || '', syncFuncName: e, params: a })
        },
        registerEventHandler: function (n, e, a) {
            var i
            null === (i = window.Falcon) || void 0 === i || i._addEventCallback(n, a)
        },
        unregisterEventHandler: function (n, e, a) {
            var i
            null === (i = window.Falcon) || void 0 === i || i._removeEventCallback(n, a)
        },
        removeComponent: function (n, e) {
            void 0 !== window._falcon
                ? window.prompt('removeComponent', JSON.stringify([n, e]))
                : void 0 !== window.FalconJavaInterface && window.FalconJavaInterface.removeComponent(n, e)
        },
        removeComponents: function (n) {
            void 0 !== window._falcon
                ? window.prompt('removeComponents', JSON.stringify([n]))
                : void 0 !== window.FalconJavaInterface && window.FalconJavaInterface.removeComponents(n)
        },
        removeCallback: function (n) {
            var e
            null === (e = window.Falcon) || void 0 === e || delete e._callbackMapOn[n]
        },
    }
function t(n) {
    return void 0 === n
}
var c = function (n) {
    return (
        'Array' ===
        (function (n) {
            return Object.prototype.toString.call(n).replace(/\[object\s|\]/g, '')
        })(n)
    )
}
function r(n, e, a) {
    window.WebViewJavascriptBridge
        ? t(a)
            ? window.WebViewJavascriptBridge.callHandler(n, e)
            : window.WebViewJavascriptBridge.callHandler(n, e, a)
        : document.addEventListener(
              'WebViewJavascriptBridgeReady',
              function () {
                  t(a) ? window.WebViewJavascriptBridge.callHandler(n, e) : window.WebViewJavascriptBridge.callHandler(n, e, a)
              },
              !1
          )
}
'function' === typeof window.initWebViewJavascriptBridge && (window.initWebViewJavascriptBridge = function (n, e) {}),
    (function () {
        try {
            if (void 0 !== window._falcon || void 0 !== window.FalconJavaInterface) return
            if (window.WebViewJavascriptBridge) window.WebViewJavascriptBridge.init(window.initWebViewJavascriptBridge)
            else {
                document.addEventListener(
                    'WebViewJavascriptBridgeReady',
                    function () {
                        window.WebViewJavascriptBridge.init(window.initWebViewJavascriptBridge)
                    },
                    !1
                )
                var n = navigator.userAgent
                if ('iphone' === (n.indexOf('iPhone') > -1 || n.indexOf('Mac') > -1 || n.indexOf('iPad') > -1 ? 'iphone' : 'gphone')) {
                    var e = document.createElement('iframe')
                    ;(e.style.display = 'none'),
                        (e.src = 'wvjbscheme://__BRIDGE_LOADED__'),
                        document.documentElement.appendChild(e),
                        setTimeout(function () {
                            document.documentElement.removeChild(e)
                        }, 0)
                }
            }
        } catch (n) {}
    })(),
    window.callNativeHandler || (window.callNativeHandler = r),
    window.registerWebHandler ||
        (window.registerWebHandler = function (n, e) {
            window.WebViewJavascriptBridge
                ? window.WebViewJavascriptBridge.registerHandler(n, e)
                : document.addEventListener(
                      'WebViewJavascriptBridgeReady',
                      function () {
                          window.WebViewJavascriptBridge.registerHandler(n, e)
                      },
                      !1
                  )
        }),
    window.registerWebListener ||
        (window.registerWebListener = function (n, e) {
            try {
                window.WebViewJavascriptBridge
                    ? window.WebViewJavascriptBridge.registerListener(n, e)
                    : document.addEventListener(
                          'WebViewJavascriptBridgeReady',
                          function () {
                              window.WebViewJavascriptBridge.registerListener(n, e)
                          },
                          !1
                      )
            } catch (n) {}
        }),
    window.registerWebHandlerRepeated ||
        (window.registerWebHandlerRepeated = function (n, e, a) {
            try {
                if ((window.nativeRepeated || (window.nativeRepeated = {}), window.nativeRepeated[n]))
                    return window.nativeRepeated[n][e] ? window.nativeRepeated[n][e].push(a) : (window.nativeRepeated[n][e] = [a]), !1
                ;(window.nativeRepeated[n] = {}),
                    (window.nativeRepeated[n][e] = [a]),
                    window.WebViewJavascriptBridge
                        ? window.WebViewJavascriptBridge.registerHandler(n, function (e) {
                              var a = e.method || e.key
                              if (a && window.nativeRepeated[n][a] && c(window.nativeRepeated[n][a]))
                                  for (var i = 0; i < window.nativeRepeated[n][a].length; i++) window.nativeRepeated[n][a][i](e)
                          })
                        : document.addEventListener(
                              'WebViewJavascriptBridgeReady',
                              function () {
                                  window.WebViewJavascriptBridge.registerHandler(n, function (e) {
                                      var a = e.method || e.key
                                      if (a && window.nativeRepeated[n][a] && c(window.nativeRepeated[n][a]))
                                          for (var i = 0; i < window.nativeRepeated[n][a].length; i++) window.nativeRepeated[n][a][i](e)
                                  })
                              },
                              !1
                          )
            } catch (n) {}
        })
var d = {
    callNativePromise: function (n, e) {
        return new Promise(function (a) {
            r(n, e, function (n) {
                a('string' === typeof n ? JSON.parse(n) : n)
            })
        })
    },
}
;(void 0 === window._falcon && void 0 === window.FalconJavaInterface) || o.initCallFalconNative()
var w = n(n({}, o), d)
export { w as default }
