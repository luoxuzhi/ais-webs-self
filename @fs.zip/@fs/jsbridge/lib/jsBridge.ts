/* 复星恒利自研App JSBridge 2021/12/21 */
let JSBridge
;(function () {
    //获取客户端类型
    const isAndroid = navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Linux') > -1
    const ua = navigator.userAgent
    const isiOS =
        !!ua.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) || ua.indexOf('iPhone') > -1 || ua.indexOf('iPad') > -1 || ua.indexOf('fosunhani-iOS') > -1 // 星财富APP中 IOS手机存在丢失ua原生前缀问题，因此需要增加多种情况判断逻辑
    const JSEventBridge = isAndroid
        ? window['JSEventBridge']
        : isiOS
          ? window['webkit'] && window['webkit']['messageHandlers'] && window['webkit']['messageHandlers']['JSEventBridge']
          : undefined
    // 监听页面显示状态
    const visibleCallback: Function[] = []
    const invisibleCallback: Function[] = []
    const watchFnc = data => {
        if (data.status === 'visible') {
            visibleCallback.forEach((fnc: Function) => fnc(data))
        } else {
            invisibleCallback.forEach((fnc: Function) => fnc(data))
        }
    }
    if (!JSEventBridge) return
    /**
     * 调用app方法
     * @param event：事件名称
     * @param data：json数据
     * @returns {Promise<object>}
     */
    // eslint-disable-next-line max-params
    const callApp = function (event: string, data: any | null = {}, successFnc?: any, failFnc?: any) {
        // 设置回调方法
        const callbackKey = 's' + Date.now() + '' + Math.floor(Math.random() * 100000) + event
        const registerCallback = (success, fail, callbackKey: string) => {
            window[callbackKey] = function (data) {
                typeof data === 'string' && (data = JSON.parse(data))
                console.log(event, data)
                if (data.code == 0) {
                    success(data.data)
                } else {
                    fail(data)
                }
                // window[callbackKey] = null // 释放内存
            }
        }
        const triggerNativeEvent = (event, data, callbackKey) => {
            // Android
            if (isAndroid) {
                data = JSON.stringify(data)
                JSEventBridge.dispatchEvent(event, data, callbackKey)
            }

            // ios
            if (isiOS) {
                JSEventBridge.postMessage({
                    method: 'dispatchEvent',
                    data: {
                        actionEvent: event,
                        paramsJsonValue: JSON.parse(JSON.stringify(data)),
                        callback: callbackKey,
                    },
                })
            }
        }
        if (typeof successFnc === 'function') {
            registerCallback(successFnc, failFnc, callbackKey)
            triggerNativeEvent(event, data, callbackKey)
        } else {
            return new Promise((resolve, reject) => {
                registerCallback(resolve, reject, callbackKey)
                triggerNativeEvent(event, data, callbackKey)
            })
        }
    }

    JSBridge = {
        /**
         * 跳转Native页面
         * @param {string} path 页面主路径
         * @param {boolean} isBlocking 是否跳转后页面执行完毕后再回调通知web端调用结果
         */
        goPage: function (path = '', isBlocking = false) {
            return callApp('goto_page', {
                url: 'fosunhani://stock.goto/' + path,
                isBlocking,
            })
        },
        /**
         * 获取网络状态
         */
        getNetwork: function () {
            return (callApp('monitor_network', null) as Promise<unknown>)
                .then(function (rst: any) {
                    return Promise.resolve(rst.networkType)
                })
                .catch(function (rst) {
                    return Promise.reject(rst)
                })
        },
        /**
         * 监听页面可见状态
         */
        getPageVisible: function () {
            return (callApp('monitor_page_status', null) as Promise<unknown>)
                .then(function (rst: any) {
                    // console.log(`Feng.chen:: 10:02:02 ===> `, rst)
                    return Promise.resolve(rst.status == 'visible')
                })
                .catch(function (rst) {
                    return Promise.reject(rst)
                })
        },
        watchPageVisible(onVisible, onInVisible) {
            if (!(visibleCallback.length || invisibleCallback.length)) {
                callApp('monitor_page_status', {}, watchFnc)
            }
            if (typeof onVisible === 'function') {
                visibleCallback.push(onVisible)
            }
            if (typeof onInVisible === 'function') {
                invisibleCallback.push(onInVisible)
            }
        },
        /**
         * 自研App代理请求
         * @param {string} id 请求唯一id
         * @param {object} params 请求参数  { method: 'GET/POST/OSS_GET_FILE', url:'https://x.xx.xxx/path', queryMap:{k1:v1,k2:v2,k3:v3...}, headerMap:{k1:v1,k2:v2,k3:v3...}, body: 'JSONString' }
         * @returns {data, origin} data 为返回body内容； origin 带请求状态的返回对象
         */
        request: function (id, params) {
            //简单判断请求路径是否为oss文件下载，启用单独的'OSS_GET_FILE'方法
            const re = /\/oss\/v\d\/Download/i
            re.test(params.url) && (params.method = 'OSS_GET_FILE')
            return (callApp('http_request_' + id, params) as Promise<unknown>)
                .then(function (rst: any) {
                    try {
                        typeof rst.body === 'string' && (rst.body = JSON.parse(rst.body))
                    } catch (error) {
                        console.log(error)
                    }
                    return Promise.resolve({ data: rst.body, origin: rst })
                })
                .catch(function (rst) {
                    return Promise.reject(rst)
                })
        },
        /**
         * 调用App登录
         */
        login: function () {
            return callApp('command_user_login', null)
        },
        /**
         * 调用App退出
         */
        logout: function () {
            return callApp('command_user_logout', null)
        },
        /**
         * 交易登录
         */
        tradeLogin: function (options = {}) {
            return callApp('command_trade_login', options)
        },
        /**
         * 获取用户信息
         */
        getUserinfo: function (options: any = {}) {
            const params = { refresh: false, ...options }
            return (callApp('get_user_info', params) as Promise<unknown>)
                .then(function (rst: any) {
                    return Promise.resolve(rst.userInfo || rst)
                })
                .catch(function (rst) {
                    return Promise.reject(rst)
                })
        },
        /**
         * 调起微信小程序
         * @param {*} userName 拉起的小程序的username
         * @param {*} path  path 可以不传 /拉起小程序页面的可带参路径，不填默认拉起小程序首页，对于小游戏，可以只传入 query 部分，来实现传参效果，如：传入 "?foo=bar"。
         * @param {*} miniProgramType   "miniProgramType" : 1 miniProgramType 只在非生产环境有效, 1 开发版  2 体验版
         * @returns
         */
        openWxMiniProgram: function (options: any = {}) {
            const defaultParams = { userName: '', path: '', miniProgramType: 1 }
            const params = { ...defaultParams, ...options }
            return callApp('command_open_wxMiniProgram', params)
        },
        /**
         *
         * @param {*} mode 0：白色状态栏，用于深色页面; 1：黑色状态栏，用于浅色页面
         * @returns
         */
        setStatusbarColor: function (mode: number = 0) {
            return callApp('command_set_statusbar_color', { mode })
        },
        /**
         * 设置webview title
         */
        setTitle: function (title: string = '') {
            return callApp('command_set_title', { title })
        },
        /**
         * 调用联系客服
         */
        contactUs: function () {
            return callApp('command_contact_us', null)
        },
        /**
         * 打开新的App webview页面或调用系统浏览器打开页面
         * @param {url} 必选参数，内容需要url encode
         * @param {title}  可选参数，默认是null，内容需要url encode 仅mode=webview时该参数有意义
         * @param {navbar} 是否显示导航，可选参数，默认是true
         * @param {inapp} 是否App内打开，否则调用手机默认浏览器必选参数，内容需要url encode
         * @param {type} 0: pdf 文件url ,   1: oss 下载文件的URL
         * @param {mode} 可选参数，webview: App内H5页面， immersive：App内沉浸式H5页面(1.6开始支持）， browser：手机浏览器
         */
        open: function ({ url = '', title = null, type = 0, navbar = true, inapp = true, mode = '' } = {}) {
            return this.goPage(
                `web?mode=${inapp ? (mode ? mode : 'webview') : 'browser'}&url=${url}&title=${title}&titlebarVisible=${navbar}&type=${type}`
            )
        },
        /**
         * 打开PDF
         *  * @param {type} 0: pdf 文件url ,   1: oss 下载文件的URL
         */
        openPDF: function ({ url = '', type = 0, title = '' }) {
            return this.goPage(`pdf?url=${url}&title=${title}&type=${type}`)
        },
        /**
         * 设置点击App导航的 “X” 按钮是否可关闭webview
         * @param {key} 可选参数， true 可关闭， false 不可关闭
         */
        canClose: function (key = true) {
            window['WebViewClose'] = function () {
                return !key
            }
        },
        /**
         * 设置点击App导航的 “<” 按钮是否可后退历史记录
         * @param {key} 可选参数， true 可后退， false 不可后退
         */
        canBack: function (key = true) {
            window['WebViewBack'] = function () {
                return !key
            }
        },
        /**
         * 点击APP的关闭按钮回调H5页面的方法，但是  callback 必须返回 false 可后退， true 不可后退 否则页面会卡死
         * APP会等待H5的JS执行完成的返回值
         * @param {*} callback Function
         */
        callbackClose: function (callback) {
            if (callback) {
                window['WebViewClose'] = callback
            } else {
                return false
            }
        },
        /**
         * 点击APP的返回按钮回调H5页面的方法，但是  callback 必须返回 false 可后退， true 不可后退 否则页面会卡死
         * APP会等待H5的JS执行完成的返回值
         * @param {*} callback Function
         */
        callbackBack: function (callback) {
            if (callback) {
                window['WebViewBack'] = callback
            } else {
                return false
            }
        },

        /**
         * 关闭当前webview
         */
        close: function () {
            this.canClose(true)
            return callApp('command_close_webview', null)
        },
        /**
         * 返回上一页
         */
        back: function () {
            const _temp = window['WebViewBack']
            this.canBack(true)
            return (callApp('command_go_back', null) as Promise<unknown>).finally(() => {
                setTimeout(() => {
                    window['WebViewBack'] = _temp
                    return Promise.resolve()
                }, 1000)
            })
        },
        /**
         * 获取图片文件(从相册或者照相机)
         * @param   {title} string 底部弹窗（相机或相册）的title
         * @param   {category} string oss的category 具体取值参考oss接口文档（https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001000651）
         */
        upload: function (title, category = null) {
            return callApp('get_image_from_camera_or_album', {
                title,
                category,
            })
        },
        /**
         * 获取PDF文件夹或者图片（从相册、相机或者文件浏览器）
         * @param   {title} string 底部弹窗（相机或相册）的title
         * @param   {category} string oss的category 具体取值参考oss接口文档（https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001000651）
         */
        uploadPdfOrImage: function (title, category = null) {
            return callApp('get_pdf_or_image', {
                title,
                category,
            })
        },
        /**
         * 设置关闭按钮
         * @param {visible} boolean 是否显示关闭按钮
         */
        setClose: function (visible = true) {
            return callApp('command_set_title_button', {
                type: 'close',
                visible,
            })
        },
        /**
         * 设置导航栏左右按钮
         * @param {type} string button类型,可取值 right1 - 右1， right2 - 右2
         * @param {buttonText} object {
            "text":"xxx",
            "textColor":"0xFFFFFFFF",
            "textSize": "normal"/"small"/"large"
            "textStyle":"normal"/"bold"
            "icon":"search"/"message"/"setting"/"contactUs"/"share"/"more"
            "customIcon": "base64的图片链接" // 自定义图片，只支持正方形图片
            }
            buttonText 按钮样式如上，如果text不为空，则icon没意义，  如果text为空，则取icon赋值给对应的button
         * @param {callback} function 点击回调函数
         */
        setButton: function (type: string = 'right1', buttonText: any = {}, callback?: Function) {
            const clickCallback = 's' + Date.now() + '' + Math.floor(Math.random() * 100000)
            callback =
                callback ||
                function () {
                    console.warn('no callback function setted!')
                }
            window[clickCallback] = callback

            buttonText = buttonText || {}
            let customIcon = buttonText.customIcon || ''
            // 去除base64的头部标识，app无法识别
            customIcon = customIcon.replace(/^data:image\/(png|ico|jpe|jpeg|gif);base64,/, '')
            // IOS不能在buttonText对象中带有多余的字段
            delete buttonText.customIcon
            const icon = buttonText.icon
            delete buttonText.icon
            return callApp('command_set_title_button', {
                type,
                visible: true,
                clickCallback,
                buttonText,
                icon,
                customIcon,
            })
        },
        /**
         * 获取消息提醒按钮开关状态
         * @returns {Boolean} true - 打开 false - 关闭
         */
        getMsgNotificationStatus() {
            return new Promise((res, rej) => {
                ;(callApp('get_msg_notification_status', {}) as Promise<unknown>)
                    .then(({ status }: any = {}) => {
                        res(status)
                    })
                    .catch(e => rej(e))
            })
        },
        // 消息提醒按钮页面 - 测试
        openMsgNotification() {
            return callApp('command_open_msg_notification', {})
        },

        // faceID
        callFaceId(idCardName = '', idCardNum = '') {
            return callApp('command_faceid_detect_verify', {
                idCardName,
                idCardNum,
            })
        },
        // 获取资产显示状态
        getAssetsShowStatus() {
            return (callApp('get_assets_show_status') as Promise<unknown>).then((data: any) => data.status)
        },

        // 设置资产展示状态
        setAssetsShowStatus(params: any = {}) {
            return callApp('command_set_assets_show_status', {
                status: params.showAssets,
            })
        },
        /**
         *
         * @param {Object} options 分享参数对象
         * @param {String} options.type 分享类型
         *   default: freedom
         *   freedom ===> 弹窗让用户自己选择分享类型
         *   wx_session ===> 微信好友
         *   wx_moments ===> 微信朋友圈
         *   facebook
         *   twitter
         * @param {String} options.title 分享标题
         * @param {String} options.desc 分享描述
         * @param {String} options.pageUrl 分享的页面地址
         * @param {String} options.thumbUrl 分享的缩略图url
         * @param {String} options.imageData 分享的base64图片数据
         */
        share(options = {}) {
            const params = {
                type: 'freedom',
                title: '',
                desc: '',
                pageUrl: '',
                thumbUrl: '',
                imageData: '',
            }
            Object.assign(params, options)
            if (params.imageData) {
                params.imageData = params.imageData.replace(/^data:image\/(png|ico|jpe|jpeg|gif);base64,/, '')
            }
            return callApp('command_share', params)
        },

        /**
         * @name 检查是否是自选
         * @param stockId
         */
        checkFavstock: function (stockId) {
            return callApp('command_check_favstock', { stockId })
        },

        /**
         * @name 添加自选
         * @param stockId
         * @param showResultPop 显示Native的添加结果的pop提示
         */
        addFavstock: function (stockId, showResultPop = true) {
            return callApp('command_add_favstock', { stockId, showResultPop })
        },

        /**
         * @name 删除自选
         * @param stockId
         * @param showResultPop 显示Native的添加结果的pop提示
         */
        removeFavstock: function (stockId, showResultPop = true) {
            return callApp('command_remove_favstock', {
                stockId,
                showResultPop,
            })
        },

        /**
         * @name 编辑自选分组
         * @param stockId
         */
        editFavgroup: function (stockId) {
            return callApp('command_edit_favgroup', { stockId })
        },

        /**
         * @name 设置页面刷新功能 - 也可以关闭webview页面刷新的功能
         * @params {Object} options
         * @params {Boolean} options.enable - 是否开始webview页面刷新功能
         */
        enabelPageRefreshFunction: function (options = { enable: true }) {
            return callApp('command_enable_pull_refresh', { ...options })
        },

        /**
         * @name LocalStorage读取
         * @params key {String} key、value都必须是string类型
         * @params value {String} key、value都必须是string类型
         */
        readLocalStorage: function (key = '') {
            return callApp('command_local_storage_read', { key })
        },

        /**
         * @name LocalStorage写入
         * @params {Object} key、value都必须是string类型
         */
        writeLocalStorage: function (key = '', value = '') {
            return callApp('command_local_storage_write', { key, value })
        },

        /**
         * @name 校验交易密码
         * @params mode {Number} mode: 0 - 白名单用户首次校验， 1 - 交易密码在其他平台被修改需要重新校验
         *
         */
        checkTradePwd: function (mode) {
            return callApp('command_trade_pwd_check', { mode })
        },

        /**
         * @name 重置交易密码
         */
        resetTradePwd: function () {
            return callApp('command_trade_pwd_reset')
        },

        /**
         * @name 核查交易密码是否可用
         * 1、如果App判断密码可用则直接返回 成功通知 enable = true
         * 2、如果需要初始设置则App会先跳去设置交易密码， 如果需要校验则先去校验，返回H5页面的时候通知JSCallback结果
         * enable: true - 交易密码可用， false - 交易密码不可用
         */
        verifyTradePwd: function () {
            return callApp('command_trade_pwd_verify')
        },
        /**
         * 基金持仓分享 - 存在版本兼容问题1.4版本以上
         * @returns Promise 分享成功与否
         */
        fundHoldShare: function (data) {
            return callApp('command_fund_hold_share', data)
        },
        /**
         * 保存图片	> 1.4.0版本
         * @returns 参考wiki
         */
        save_image_file: function (data) {
            return callApp('command_save_image_file', data)
        },
        /**
         * Adjust事件埋点 > 1.5.0版本
         * @returns 参考wiki
         */
        adjust_track: function (data) {
            return callApp('command_adjust_track', data)
        },
        /**
         * Adjust事件埋点 >= 1.8.0版本
         * @returns 参考wiki
         */
        event_track: function (data) {
            return callApp('command_event_track', data)
        },
        /**
         * 获取地理位置信息 >= 2.2.0版本
         * @returns 参考wiki
         */
        getGeolocation: function (data) {
            return callApp('get_geolocation', data)
        },
        /**
         * 获取资产币种 >= 2.5.0版本
         * @returns 参考wiki
         */
        getAssetsCurrency: function (data) {
            return callApp('get_assets_currency', data)
        },
        /**
         * 设置资产币种 >= 2.5.0版本
         * @returns 参考wiki
         */
        setSssetsCurrency: function (data) {
            return callApp('command_set_assets_currency', data)
        },
        /**
         * 复制剪贴板
         */
        getClipboardContent() {
            return (callApp('command_get_clipboard_content') as Promise<unknown>).then((data: any) => data.content)
        },
    }

    window['JSBridge'] = JSBridge
    window['WebViewBack'] = function () {
        return false
    }
    window['WebViewClose'] = function () {
        return false
    }
})()

export default JSBridge
