/* eslint-disable max-params */
import fl from './king-fisher-falcon-es'

window._commonBridge = {
    // iOS版标识
    iOSFlag: /(iPhone|iPad|Mac|iOS)/i.test(navigator.userAgent),
    // 是否为falcon web环境
    isFalconWeb: navigator.userAgent.indexOf('HiThink') > -1,
    getRandomId: function () {
        const randomNum = -6
        return String(Math.random()).slice(randomNum) + String(+new Date()).slice(randomNum)
    },
    // 格式化数据
    getFormattedRes: function (val) {
        if (typeof val === 'string' && val[0] === '{') {
            try {
                return JSON.parse(val)
            } catch (err) {
                return val
            }
        }
        return val
    },
}

// 是否是iOS
window._commonBridge.isCommonIos = window._commonBridge.iOSFlag

// iOS WKWebview web主动初始化
window._commonBridge.wkInitBridge = function () {
    const WVJBIframe = document.createElement('iframe')
    WVJBIframe.style.display = 'none'
    WVJBIframe.src = this.isCommonIos ? 'https://__bridge_loaded__' : 'wvjbscheme://__BRIDGE_LOADED__'
    document.documentElement.appendChild(WVJBIframe)
    setTimeout(function () {
        document.documentElement.removeChild(WVJBIframe)
    }, 0)
}

// iOS通用bridge方法
window._commonBridge.setupWebViewJavascriptBridge = function (callback) {
    if (window.WebViewJavascriptBridge) {
        return callback(window.WebViewJavascriptBridge)
    }
    if (window.WVJBCallbacks) {
        return window.WVJBCallbacks.push(callback)
    }
    window.WVJBCallbacks = [callback]
    this.wkInitBridge()
}
// 没有初始化完成时,data是只提供给callNativeHandler使用,registerWebHandler不会涉及传参data
window._commonBridge.prepareForBridgeReady = function (handler, handlername, callfunction, data) {
    const bridgeHandler = function () {
        if (data) {
            handler(handlername, data, callfunction)
        } else {
            handler(handlername, callfunction)
        }
    }
    if (window._commonBridge.isCommonIos) {
        window._commonBridge.setupWebViewJavascriptBridge(bridgeHandler)
    } else {
        document.addEventListener('WebViewJavascriptBridgeReady', bridgeHandler, false)
    }
}

// 初始化 连接桥函数定义
window._commonBridge.connectWebViewJavascriptBridge = function () {
    // 设置默认协议处理函数为console.log
    function _initWebViewJavascriptBridge(message) {
        window.console.log('WebViewJavascriptBridge init completed:', message)
    }
    if (!window._commonBridge.isCommonIos) {
        if (window.WebViewJavascriptBridge) {
            window.WebViewJavascriptBridge.init(_initWebViewJavascriptBridge)
        } else {
            document.addEventListener(
                'WebViewJavascriptBridgeReady',
                function () {
                    window.WebViewJavascriptBridge.init(_initWebViewJavascriptBridge)
                },
                false
            )
            //手炒iOS主动初始化
            window._commonBridge.iOSFlag && window._commonBridge.wkInitBridge()
        }
    } else {
        // iOS
        window._commonBridge.setupWebViewJavascriptBridge(_initWebViewJavascriptBridge)
    }
}
window._commonBridge._callHandler = function (handlername, data, callfunction) {
    if (typeof callfunction !== 'undefined') {
        window.WebViewJavascriptBridge.callHandler(handlername, data, callfunction)
    } else {
        window.WebViewJavascriptBridge.callHandler(handlername, data)
    }
}
/**
 * 调用客户端api
 * @param {string} handlername 协议名称
 * @param {object} 协议入参
 * @param {function} callfunction 回调函数
 */
window._commonBridge.callNativeHandler = function (handlername, data, callfunction) {
    if (window.WebViewJavascriptBridge) {
        window._commonBridge._callHandler(handlername, data, callfunction)
    } else {
        // data默认会有空对象
        window._commonBridge.prepareForBridgeReady(window._commonBridge._callHandler, handlername, callfunction, data || {})
    }
}
window._commonBridge._registerHandler = function (handlername, callfunction) {
    window.WebViewJavascriptBridge.registerHandler(handlername, callfunction)
}
/**
 * 注册监听函数，供客户端调用
 * @param {string} handlername 协议名称
 * @param {function} callfunction 回调函数
 */
window._commonBridge.registerWebHandler = function (handlername, callfunction) {
    if (window.WebViewJavascriptBridge) {
        window._commonBridge._registerHandler(handlername, callfunction)
    } else {
        window._commonBridge.prepareForBridgeReady(window._commonBridge._registerHandler, handlername, callfunction)
    }
}
window.registerWebListener = function (a, b) {
    try {
        window.WebViewJavascriptBridge
            ? window.WebViewJavascriptBridge.registerListener(a, b)
            : document.addEventListener(
                  'WebViewJavascriptBridgeReady',
                  function () {
                      window.WebViewJavascriptBridge.registerListener(a, b)
                  },
                  !1
              )
    } catch (a) {
        console.log('[window.registerWebListener]:', a)
    }
}

/******************  Falcon相关  ******************/

window._commonBridge.callFalconWebNativeHandler = function ({ actionName, componentName, objectId, syncFuncName, params, callbackId }) {
    const isFalconIos = typeof window._falcon !== 'undefined'
    const isFalconAndroid = typeof window.FalconJavaInterface !== 'undefined'
    if (!isFalconIos && !isFalconAndroid) {
        return
    }
    let res
    if (typeof window._falcon !== 'undefined') {
        res = window.prompt(actionName, JSON.stringify([componentName, objectId, syncFuncName, params, callbackId]))
    } else {
        let args = [componentName, objectId, syncFuncName, JSON.stringify(params)]
        callbackId && (args = [...args, callbackId])
        res = window.FalconJavaInterface[actionName](...args)
    }
    return window._commonBridge.getFormattedRes(res)
}
/** falcon同步调用方法 */
window._commonBridge.callWebNativeHandlerSync = function (syncFuncName, params, callback) {
    const res = this.callFalconWebNativeHandler({
        actionName: 'invokeSync',
        componentName: 'fl',
        objectId: '',
        syncFuncName,
        params,
    })
    if (callback) {
        // 兼容老bridge写法
        typeof callback === 'function' && callback(res)
    } else {
        // 兼容同步的写法，在调用falcon协议的场景触发
        return res
    }
}

/** falcon异步调用方法 */
window._commonBridge.callWebNativeHandlerAsync = function (syncFuncName, params, callback, objectId) {
    const callbackId = window.Falcon._addCallback(callback, syncFuncName)
    this.callFalconWebNativeHandler({
        actionName: 'invokeAsync',
        // 静态方法直接调用 componentName 为 fl，objectId 为空
        componentName: objectId ? syncFuncName : 'fl',
        objectId: objectId || '',
        syncFuncName,
        params,
        callbackId,
    })
}

/** 初始化falcon */
window._commonBridge.initCallFalconWebNative = function () {
    if (!window.Falcon) {
        window.Falcon = {
            // 回调
            _callbackMap: {},
            _addCallback: function (func, name) {
                const id = (name || '') + '-' + window._commonBridge.getRandomId()
                window.Falcon._callbackMap[id] = func
                return id
            },
            // 注册客户端事件回调
            _addEventCallback: function (func, name) {
                window.Falcon._callbackMap[name] = func
            },
            callback: function (jsonString, callbackId) {
                if (window.Falcon._callbackMap[callbackId]) {
                    window.Falcon._callbackMap[callbackId](window._commonBridge.getFormattedRes(jsonString))
                }
                delete window.Falcon._callbackMap[callbackId]
            },

            // 注册客户端事件
            call: function (funcName, jsonString) {
                if (window.Falcon._callbackMap[funcName]) {
                    window.Falcon._callbackMap[funcName](window._commonBridge.getFormattedRes(jsonString))
                }
                // 事件，不需要注销
            },

            // 注册订阅事件
            sendCustomEvent: function (apiName, jsonString) {
                if (window.Falcon._callbackMap[apiName]) {
                    window.Falcon._callbackMap[apiName](window._commonBridge.getFormattedRes(jsonString))
                }
                // 事件，不需要注销
            },
        }
    }

    // 网页，异步回调
    window.falconCallback = window.Falcon.callback

    // 网页，客户端事件
    window.falconCall = window.Falcon.call

    // 网页，监听事件
    window.falconSendCustomEvent = window.Falcon.sendCustomEvent

    return window.Falcon
}

/******************  初始化  ******************/
window._commonBridge.init = function () {
    if (this.isFalconWeb) {
        this.initCallFalconWebNative()
    } else {
        this.connectWebViewJavascriptBridge()
    }
}

const isHiThinkApp = () => {
    return navigator.userAgent.toLocaleLowerCase().indexOf('hithink') > -1
}

const isIos = () => {
    const u = navigator.userAgent
    if (u.indexOf('Android') > -1 || u.indexOf('Linux') > -1) {
        //安卓手机
        return false
    } else if (u.indexOf('iPhone') > -1) {
        //苹果手机
        return true
    } else if (u.indexOf('iPad') > -1) {
        //iPad
        return true
    } else if (u.indexOf('Windows Phone') > -1) {
        //winphone手机
        return false
    }
    return false
}

isHiThinkApp() && window._commonBridge.init()

/******************  对使用者暴露的api  ******************/
/* 通用的调用方式 */
window.callI18NNativeHandler = function (handlername, data, callfunction) {
    if (typeof data !== 'object') {
        // 默认这种方式调用的都是传的object类型
        window.console.error('callNativeHandler param is illegal')
        return
    }
    if (!window._commonBridge.isFalconWeb) {
        /* 手炒环境直接调用 */
        window._commonBridge.callNativeHandler(handlername, data, callfunction)
    } else {
        //业务协议，用falconBridge进行调用
        const transformedData = data
        window._commonBridge.callWebNativeHandlerAsync(handlername, [transformedData], callfunction)
    }
}

/* 通用的调用方式，监听 */
window.registerI18NWebHandler = function (handlername, callfunction) {
    if (!window._commonBridge.isFalconWeb) {
        window._commonBridge.registerWebHandler(handlername, callfunction)
    } else {
        /* 国际版falcon */
        window._commonBridge.callWebNativeHandlerAsync(handlername, [JSON.stringify({})], callfunction)
    }
}

/* falcon的调用方式 */
window.callNativeSync = window._commonBridge.callWebNativeHandlerSync
/* falcon的调用方式 */
window.callNativeAsync = window._commonBridge.callWebNativeHandlerAsync

// 参考 https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001005382

const callI18NNativeHandler = window.callI18NNativeHandler

const thsI18NJsBridge = {
    isTHSI18NApp() {
        return isHiThinkApp()
    },
    // 获取系统基础信息:
    // SDKVersion: 客户端基础库版本，version: 宿主app版本号，language:语言，theme: 主题  (dark：夜间 ，light 白天)
    getAppBaseInfo() {
        return window._commonBridge.callWebNativeHandlerSync('getAppBaseInfo', []).data
    },
    // 跳转登录页：
    gotoLoginPage() {
        callI18NNativeHandler('route', {
            url: 'hexin.aInvestLogin/thirdLogin',
            params: '',
        })
    },
    // 普通打开新webview，url不编码，url中不能带中文，中文需编码后拼接进url中
    gotoCommonPage({ url, title, fullscreen = false }) {
        callI18NNativeHandler('route', {
            url: 'hexin.curve/webContainer',
            params: {
                url,
                fullscreen, //全屏跳转
                title,
            },
        })
    },
    // 关闭当前webview
    goBack() {
        callI18NNativeHandler('goBack', { type: 'component' })
    },
    changeWebViewTitle(title: string) {
        if (isIos()) {
            callI18NNativeHandler('changeWebViewTitle', { title })
        } else {
            document.title = title
        }
    },
    // 展示导航栏关闭按钮
    showCloseBarItem() {
        callI18NNativeHandler('showCloseBarItem', {})
    },
    // 清空客户端堆栈（清空所有打开的webview）
    closeWebPage() {
        callI18NNativeHandler('closeWebPage', {})
    },
    // 端内获取userid
    getHostUserInfo(cb, errorCb) {
        callI18NNativeHandler('getHostUserInfo', {}, res => {
            if (res.errCode === 0) {
                cb && cb(res.data)
            } else {
                errorCb && errorCb(res)
            }
        })
    },
    // 打开pdf，url中不能包含中文，如文件名包含中文需要用 encodeURIComponent 编码文件名
    // ios端支持设置title，Android 不支持设置title，默认展示文件名
    // Andriod 调用手机系统能力打开pdf，打开文件有下载过程，打开大文件需要较长时间，表现为点击一段时间后有响应，可传入callback添加loading
    openPDF({ url, title, successCallback, failCallback }) {
        if (isIos()) {
            this.gotoCommonPage({ url, title })
        } else {
            fl.getFileSystemManager().access({
                path: title,
                success: function (res) {
                    console.log('文件存在', res)
                    fl.openDocument({
                        filePath: url,
                        success: function () {},
                    })
                },
                fail: function (res) {
                    failCallback && failCallback()
                    console.log('文件不存在,res,failCallback:', res, failCallback)
                    fl.downloadFile({
                        url: url,
                        success: function (res) {
                            successCallback && successCallback()
                            console.log('下载成功,res,successCallback:', res, successCallback)
                            const filePath = res.filePath
                            fl.openDocument({
                                filePath: filePath,
                                success: function () {},
                            })
                        },
                    })
                },
            })
        }
    },
    fl,
}

export default thsI18NJsBridge
