export {}

declare global {
    interface Window {
        HkAndroid: any
        webkit: any
        closeCurrentWebview: any
        closeWebview: any
        WebViewJavascriptBridge: any
        nativeRepeated: any
        callNativeHandler: any
        registerWebHandler: any
        registerWebHandlerRepeated: any
        registerWebListener: any
        connectWebViewJavascriptBridge: any
        initWebViewJavascriptBridge: any
        _commonBridge: any
        WVJBCallbacks: any
        _falcon: any
        FalconJavaInterface: any
        Falcon: any
        falconCallback: any
        falconCall: any
        falconSendCustomEvent: any
        callNativeSync: any
        callNativeAsync: any
        callI18NNativeHandler: any
        registerI18NWebHandler: any
    }
}
