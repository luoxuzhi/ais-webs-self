/* 渠道App JSBridge 2023/08/17 */
let channelJSBridge
;(function () {
    //获取客户端类型
    const isAndroid = navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Linux') > -1
    const ua = navigator.userAgent
    const isiOS =
        !!ua.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/) ||
        ua.indexOf('iPhone') > -1 ||
        ua.indexOf('iPad') > -1 ||
        ua.indexOf('fosunwealth-channel-ios') > -1 // 星财富APP中 IOS手机存在丢失ua原生前缀问题，因此需要增加多种情况判断逻辑
    const JSEventBridge = isAndroid
        ? window['JSEventBridge']
        : isiOS
        ? window['webkit'] && window['webkit']['messageHandlers'] && window['webkit']['messageHandlers']['JSEventBridge']
        : undefined
    // 监听页面显示状态
    const visibleCallback: Function[] = []
    const invisibleCallback: Function[] = []
    const watchFnc = data => {
        if (data.status === 'visible') {
            visibleCallback.forEach((fnc: Function) => fnc(data))
        } else {
            invisibleCallback.forEach((fnc: Function) => fnc(data))
        }
    }
    if (!JSEventBridge) return
    /**
     * 调用app方法
     * @param event：事件名称
     * @param data：json数据
     * @returns {Promise<object>}
     */
    // eslint-disable-next-line max-params
    const callApp = function (event: any, data: any | null = {}, successFnc?: any, failFnc?: any) {
        // 设置回调方法
        const callbackKey = 's' + Date.now() + '' + Math.floor(Math.random() * 100000) + event
        const registerCallback = (success, fail, callbackKey: string) => {
            window[callbackKey] = function (data) {
                typeof data === 'string' && (data = JSON.parse(data))
                console.log(event, data)
                if (data.code == 0) {
                    success(data.data)
                } else {
                    fail(data)
                }
                // window[callbackKey] = null // 释放内存
            }
        }
        const triggerNativeEvent = (event, data, callbackKey) => {
            // Android
            if (isAndroid) {
                data = JSON.stringify(data)
                JSEventBridge.dispatchEvent(event, data, callbackKey)
            }

            // ios
            if (isiOS) {
                JSEventBridge.postMessage({
                    method: 'dispatchEvent',
                    data: {
                        actionEvent: event,
                        paramsJsonValue: JSON.parse(JSON.stringify(data)),
                        callback: callbackKey,
                    },
                })
            }
        }
        if (typeof successFnc === 'function') {
            registerCallback(successFnc, failFnc, callbackKey)
            triggerNativeEvent(event, data, callbackKey)
        } else {
            return new Promise((resolve, reject) => {
                registerCallback(resolve, reject, callbackKey)
                triggerNativeEvent(event, data, callbackKey)
            })
        }
    }

    channelJSBridge = {
        /**
         * 跳转Native页面
         * @param {string} path 页面主路径
         * @param {boolean} isBlocking 是否跳转后页面执行完毕后再回调通知web端调用结果
         */
        goPage: function (path = '', isBlocking = false) {
            return callApp('goto_page', {
                // url: 'fosunhani://stock.goto/' + path,
                url: 'fosunwealth://channel.goto/' + path,
                isBlocking,
            })
        },
        /**
         * 获取网络状态
         */
        getNetwork: function () {
            return (callApp('monitor_network', null) as Promise<unknown>)
                .then(function (rst: any) {
                    return Promise.resolve(rst.networkType)
                })
                .catch(function (rst) {
                    return Promise.reject(rst)
                })
        },
        /**
         * 监听页面可见状态
         */
        getPageVisible: function () {
            return (callApp('monitor_page_status', null) as Promise<unknown>)
                .then(function (rst: any) {
                    // console.log(`Feng.chen:: 10:02:02 ===> `, rst)
                    return Promise.resolve(rst.status == 'visible')
                })
                .catch(function (rst) {
                    return Promise.reject(rst)
                })
        },
        watchPageVisible(onVisible, onInVisible) {
            if (!(visibleCallback.length || invisibleCallback.length)) {
                callApp('monitor_page_status', {}, watchFnc)
            }
            if (typeof onVisible === 'function') {
                visibleCallback.push(onVisible)
            }
            if (typeof onInVisible === 'function') {
                invisibleCallback.push(onInVisible)
            }
        },
        /**
         * 自研App代理请求
         * @param {string} id 请求唯一id
         * @param {object} params 请求参数  { method: 'GET/POST/OSS_GET_FILE', url:'https://x.xx.xxx/path', queryMap:{k1:v1,k2:v2,k3:v3...}, headerMap:{k1:v1,k2:v2,k3:v3...}, body: 'JSONString' }
         * @returns {data, origin} data 为返回body内容； origin 带请求状态的返回对象
         */
        request: function (id, params) {
            //简单判断请求路径是否为oss文件下载，启用单独的'OSS_GET_FILE'方法
            const re = /\/oss\/v\d\/Download/i
            re.test(params.url) && (params.method = 'OSS_GET_FILE')
            return (callApp('http_request_' + id, params) as Promise<unknown>)
                .then(function (rst: any) {
                    try {
                        typeof rst.body === 'string' && (rst.body = JSON.parse(rst.body))
                    } catch (error) {
                        console.log('error', error)
                    }
                    return Promise.resolve({ data: rst.body, origin: rst })
                })
                .catch(function (rst) {
                    return Promise.reject(rst)
                })
        },
        /**
         * 调用App登录
         */
        login: function () {
            return callApp('command_user_login', null)
        },
        /**
         * 调用App退出
         */
        logout: function () {
            return callApp('command_user_logout', null)
        },
        /**
         * 获取用户信息
         */
        getUserinfo: function (options = {}) {
            const params = { refresh: false, ...options }
            return (callApp('get_user_info', params) as Promise<unknown>)
                .then(function (rst: any) {
                    return Promise.resolve(rst.userInfo || rst)
                })
                .catch(function (rst) {
                    return Promise.reject(rst)
                })
        },
        /**
         *
         * @param {*} mode 0：白色状态栏，用于深色页面; 1：黑色状态栏，用于浅色页面
         * @returns
         */
        setStatusbarColor: function (mode = 0) {
            return callApp('command_set_statusbar_color', { mode })
        },
        /**
         * 设置webview title
         */
        setTitle: function (title = '') {
            return callApp('command_set_title', { title })
        },
        /**
         * 调用联系客服
         */
        contactUs: function () {
            return callApp('command_contact_us', null)
        },
        /**
         * 打开新的App webview页面或调用系统浏览器打开页面
         * @param {url} 必选参数，内容需要url encode
         * @param {title}  可选参数，默认是null，内容需要url encode 仅mode=webview时该参数有意义
         * @param {navbar} 是否显示导航，可选参数，默认是true
         * @param {inapp} 是否App内打开，否则调用手机默认浏览器必选参数，内容需要url encode
         * @param {type} 0: pdf 文件url ,   1: oss 下载文件的URL
         * @param {mode} 可选参数，webview: App内H5页面， immersive：App内沉浸式H5页面(1.6开始支持）， browser：手机浏览器
         */
        open: function ({ url = '', title = null, type = 0, navbar = true, inapp = true, mode = '' } = {}) {
            return this.goPage(
                `web?mode=${inapp ? (mode ? mode : 'webview') : 'browser'}&url=${url}&title=${title}&titlebarVisible=${navbar}&type=${type}`
            )
        },
        /**
         * 打开PDF
         *  * @param {type} 0: pdf 文件url ,   1: oss 下载文件的URL
         */
        openPDF: function ({ url = '', type = 0, title = '', filename = '' }) {
            return this.goPage(`pdf?url=${url}&title=${title}&type=${type}&filename=${filename}`)
        },
        /**
         * 设置点击App导航的 “X” 按钮是否可关闭webview
         * @param {key} 可选参数， true 可关闭， false 不可关闭
         */
        canClose: function (key = true) {
            window['WebViewClose'] = function () {
                return !key
            }
        },
        /**
         * 设置点击App导航的 “<” 按钮是否可后退历史记录
         * @param {key} 可选参数， true 可后退， false 不可后退
         */
        canBack: function (key = true) {
            window['WebViewBack'] = function () {
                return !key
            }
        },
        /**
         * 点击APP的关闭按钮回调H5页面的方法，但是  callback 必须返回 false 可后退， true 不可后退 否则页面会卡死
         * APP会等待H5的JS执行完成的返回值
         * @param {*} callback Function
         */
        callbackClose: function (callback) {
            if (callback) {
                window['WebViewClose'] = callback
            } else {
                return false
            }
        },
        /**
         * 点击APP的返回按钮回调H5页面的方法，但是  callback 必须返回 false 可后退， true 不可后退 否则页面会卡死
         * APP会等待H5的JS执行完成的返回值
         * @param {*} callback Function
         */
        callbackBack: function (callback) {
            if (callback) {
                window['WebViewBack'] = callback
            } else {
                return false
            }
        },

        /**
         * 关闭当前webview
         */
        close: function () {
            this.canClose(true)
            return callApp('command_close_webview', null)
        },
        /**
         * 返回上一页
         */
        back: function () {
            const _temp = window['WebViewBack']
            this.canBack(true)
            return (callApp('command_go_back', null) as Promise<unknown>).finally(() => {
                setTimeout(() => {
                    window['WebViewBack'] = _temp
                    return Promise.resolve()
                }, 1000)
            })
        },
        /**
         * 获取图片文件(从相册或者照相机)
         * @param   {title} string 底部弹窗（相机或相册）的title
         * @param   {category} string oss的category 具体取值参考oss接口文档（https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001000651）
         */
        upload: function (title, category = null) {
            return callApp('get_image_from_camera_or_album', {
                title,
                category,
            })
        },
        /**
         * 获取PDF文件夹或者图片（从相册、相机或者文件浏览器）
         * @param   {title} string 底部弹窗（相机或相册）的title
         * @param   {category} string oss的category 具体取值参考oss接口文档（https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001000651）
         */
        uploadPdfOrImage: function (title, category = null) {
            return callApp('get_pdf_or_image', {
                title,
                category,
            })
        },
        /**
         * 设置关闭按钮
         * @param {visible} boolean 是否显示关闭按钮
         */
        setClose: function (visible = true) {
            return callApp('command_set_title_button', {
                type: 'close',
                visible,
            })
        },
        /**
         * 设置导航栏左右按钮
         * @param {type} string button类型,可取值 right1 - 右1， right2 - 右2
         * @param {buttonText} object {
            "text":"xxx",
            "textColor":"0xFFFFFFFF",
            "textSize": "normal"/"small"/"large"
            "textStyle":"normal"/"bold"
            "icon":"search"/"message"/"setting"/"contactUs"/"share"/"more"
            "customIcon": "base64的图片链接" // 自定义图片，只支持正方形图片
            }
            buttonText 按钮样式如上，如果text不为空，则icon没意义，  如果text为空，则取icon赋值给对应的button
         * @param {callback} function 点击回调函数
         */
        setButton: function (type: string = 'right1', buttonText: any = {}, callback) {
            const clickCallback = 's' + Date.now() + '' + Math.floor(Math.random() * 100000)
            callback =
                callback ||
                function () {
                    console.warn('no callback function setted!')
                }
            window[clickCallback] = callback

            buttonText = buttonText || {}
            let customIcon = buttonText.customIcon || ''
            // 去除base64的头部标识，app无法识别
            customIcon = customIcon.replace(/^data:image\/(png|ico|jpe|jpeg|gif);base64,/, '')
            // IOS不能在buttonText对象中带有多余的字段
            delete buttonText.customIcon
            const icon = buttonText.icon
            delete buttonText.icon
            return callApp('command_set_title_button', {
                type,
                visible: true,
                clickCallback,
                buttonText,
                icon,
                customIcon,
            })
        },
        /**
         * 获取消息提醒按钮开关状态
         * @returns {Boolean} true - 打开 false - 关闭
         */
        getMsgNotificationStatus() {
            return new Promise((res, rej) => {
                ;(callApp('get_msg_notification_status', {}) as Promise<unknown>)
                    .then(({ status }: any = {}) => {
                        res(status)
                    })
                    .catch(e => rej(e))
            })
        },
        // 消息提醒按钮页面 - 测试
        openMsgNotification() {
            return callApp('command_open_msg_notification', {})
        },
        /**
         *
         * @param {Object} options 分享参数对象
         * @param {String} options.type 分享类型
         *   default: freedom
         *   freedom ===> 弹窗让用户自己选择分享类型
         *   wx_session ===> 微信好友
         *   wx_moments ===> 微信朋友圈
         *   facebook
         *   twitter
         * @param {String} options.title 分享标题
         * @param {String} options.desc 分享描述
         * @param {String} options.pageUrl 分享的页面地址
         * @param {String} options.thumbUrl 分享的缩略图url
         * @param {String} options.imageData 分享的base64图片数据
         */
        share(options = {}) {
            const params = {
                type: 'freedom',
                title: '',
                desc: '',
                pageUrl: '',
                thumbUrl: '',
                imageData: '',
            }
            Object.assign(params, options)
            if (params.imageData) {
                params.imageData = params.imageData.replace(/^data:image\/(png|ico|jpe|jpeg|gif);base64,/, '')
            }
            return callApp('command_share', params)
        },

        /**
         * @name 分享 PDF 文件
         * @param {String} url pdf文件下载地址，原生会先根据这个url下载pdf文件，然后调用手机系统的分享把pdf文件分享出去
         * @param {Number} type url类型， 0 - pdf文件url，1- oss pdf文件 url
         * @param {String} fileName pdf 文件名，带.pdf 后缀
         */
        sharePdf: function (url: String, type: Number, filename: String) {
            return callApp('command_share_pdf', {
                url,
                type,
                filename,
            })
        },

        /**
         * @name 设置页面刷新功能 - 也可以关闭webview页面刷新的功能
         * @params {Object} options
         * @params {Boolean} options.enable - 是否开始webview页面刷新功能
         */
        enabelPageRefreshFunction: function (options = { enable: true }) {
            return callApp('command_enable_pull_refresh', { ...options })
        },

        /**
         * @name LocalStorage读取
         * @params key {String} key、value都必须是string类型
         * @params value {String} key、value都必须是string类型
         */
        readLocalStorage: function (key = '') {
            return callApp('command_local_storage_read', { key })
        },

        /**
         * @name LocalStorage写入
         * @params {Object} key、value都必须是string类型
         */
        writeLocalStorage: function (key = '', value = '') {
            return callApp('command_local_storage_write', { key, value })
        },

        /**
         * 保存图片	> 1.4.0版本
         * @returns 参考wiki
         */
        save_image_file: function (data) {
            return callApp('command_save_image_file', data)
        },
        /**
         * 获取地理位置信息 >= 2.2.0版本
         * @returns 参考wiki
         */
        getGeolocation: function (data) {
            return callApp('get_geolocation', data)
        },
    }

    window['channelJSBridge'] = channelJSBridge
    window['WebViewBack'] = function () {
        return false
    }
    window['WebViewClose'] = function () {
        return false
    }
})()

export default channelJSBridge
