/* eslint-disable vars-on-top */
/* eslint-disable no-var */

/**
 * 同花顺jsBridge接口详情：https://www.tapd.cn/60236733/markdown_wikis/show/#1160236733001002132
 */
// 同花顺 bridge
const jsBridge = {
    // 方法触发器，所有jsbridge方法通过这个方法调用
    callNativeHandler: function callNativeHandler(a?: any, b?: any, c?: any) {
        window.WebViewJavascriptBridge
            ? void 0 !== c
                ? window.WebViewJavascriptBridge.callHandler(a, b, c)
                : window.WebViewJavascriptBridge.callHandler(a, b)
            : document.addEventListener(
                  'WebViewJavascriptBridgeReady',
                  function () {
                      void 0 !== c ? window.WebViewJavascriptBridge.callHandler(a, b, c) : window.WebViewJavascriptBridge.callHandler(a, b)
                  },
                  !1
              )
    },
    // 未使用
    registerWebHandler: function registerWebHandler(a?: any, b?: any) {
        window.WebViewJavascriptBridge
            ? window.WebViewJavascriptBridge.registerHandler(a, b)
            : document.addEventListener(
                  'WebViewJavascriptBridgeReady',
                  function () {
                      window.WebViewJavascriptBridge.registerHandler(a, b)
                  },
                  !1
              )
    },
    // 未使用
    registerWebHandlerRepeated: function registerWebHandlerRepeated(a?: any, b?: any, c?: any) {
        try {
            if ((window.nativeRepeated || (window.nativeRepeated = {}), window.nativeRepeated[a]))
                return window.nativeRepeated[a][b] ? window.nativeRepeated[a][b].push(c) : (window.nativeRepeated[a][b] = [c]), !1
            ;(window.nativeRepeated[a] = {}),
                (window.nativeRepeated[a][b] = [c]),
                window.WebViewJavascriptBridge
                    ? window.WebViewJavascriptBridge.registerHandler(a, function (b) {
                          const c = b.method || b.key
                          if (c && window.nativeRepeated[a][c] && '[object Array]' === Object.prototype.toString.call(window.nativeRepeated[a][c]))
                              for (let d = 0; d < window.nativeRepeated[a][c].length; d++) window.nativeRepeated[a][c][d](b)
                      })
                    : document.addEventListener(
                          'WebViewJavascriptBridgeReady',
                          function () {
                              window.WebViewJavascriptBridge.registerHandler(a, function (b) {
                                  const c = b.method || b.key
                                  if (
                                      c &&
                                      window.nativeRepeated[a][c] &&
                                      '[object Array]' === Object.prototype.toString.call(window.nativeRepeated[a][c])
                                  )
                                      for (let d = 0; d < window.nativeRepeated[a][c].length; d++) window.nativeRepeated[a][c][d](b)
                              })
                          },
                          !1
                      )
            // eslint-disable-next-line no-empty
        } catch (a) {}
    },
    // 未使用
    registerWebListener: function registerWebListener(a?: any, b?: any) {
        try {
            window.WebViewJavascriptBridge
                ? window.WebViewJavascriptBridge.registerListener(a, b)
                : document.addEventListener(
                      'WebViewJavascriptBridgeReady',
                      function () {
                          window.WebViewJavascriptBridge.registerListener(a, b)
                      },
                      !1
                  )
            // eslint-disable-next-line no-empty
        } catch (a) {}
    },
    // 初始化
    connectWebViewJavascriptBridge: function connectWebViewJavascriptBridge() {
        if (window.WebViewJavascriptBridge) window.WebViewJavascriptBridge.init(this.initWebViewJavascriptBridge)
        else {
            // eslint-disable-next-line consistent-this, @typescript-eslint/no-this-alias
            const that = this
            document.addEventListener(
                'WebViewJavascriptBridgeReady',
                function () {
                    window.WebViewJavascriptBridge.init(that.initWebViewJavascriptBridge)
                },
                !1
            )
            try {
                const a = {
                    versions: (function () {
                        const a = navigator.userAgent
                        navigator.appVersion
                        return { iPhone: a.indexOf('iPhone') > -1 || a.indexOf('Mac') > -1, iPad: a.indexOf('iPad') > -1 }
                    })(),
                    // @ts-ignore
                    language: (navigator.browserLanguage || navigator.language).toLowerCase(),
                }
                if (a.versions.iPhone || a.versions.iPad) var b = 'iphone'
                else var b = 'gphone'
                if ('iphone' === b) {
                    const c = document.createElement('iframe')
                    ;(c.style.display = 'none'),
                        (c.src = 'wvjbscheme://__BRIDGE_LOADED__'),
                        document.documentElement.appendChild(c),
                        setTimeout(function () {
                            document.documentElement.removeChild(c)
                        }, 0)
                }
                // eslint-disable-next-line no-empty
            } catch (a) {}
        }
    },
    // 未使用
    initWebViewJavascriptBridge: function initWebViewJavascriptBridge(a?: any, b?: any) {
        console.log('message:' + a), console.log('callback:' + b)
    },
}

const thsJsBridge = function () {
    const isTHSI18NApp = () => {
        return navigator.userAgent.toLocaleLowerCase().indexOf('hithink') > -1
    }
    /**
     * 是否是同花顺App, 国际版userAgent为'xxx hiThink xxx hexin'，需增加判断防止国际版被判断为公版，执行公版init
     */
    const isTHSApp = () => {
        const ua = navigator.userAgent.toLowerCase()
        return !!ua.match(/hexin/i) && !isTHSI18NApp()
    }

    if (isTHSApp()) {
        // 不推荐使用，防止被覆盖
        for (const key in jsBridge) {
            if (Object.prototype.hasOwnProperty.call(jsBridge, key)) {
                window[key] = jsBridge[key]
            }
        }

        // 初始化jsBridge - 异步
        jsBridge.connectWebViewJavascriptBridge()

        // 初始化完成后，设置header + 安卓返回键为客户端自行管理
        setTimeout(() => {
            console.log('thsJsBridge加载完毕，开始设置header配置-----')
            //判断是否处于同花顺android app里面，初始化后退拦截为客户端自行管理
            const andThs = navigator.userAgent.includes('Hexin_Gphone')
            if (andThs) {
                const data = {
                    method: 'setBrowserField',
                    params: {
                        isUseDefaultBack: 'true',
                    },
                }
                jsBridge.callNativeHandler('notifyWebHandleEvent', JSON.stringify(data))
            }

            // 设置title
            const title = document.getElementsByTagName('title')[0].text
            document.title = title
            if (navigator.userAgent.toLowerCase().indexOf('android') > 0) {
                jsBridge.callNativeHandler('changeWebViewTitle', { title, url: '' })
            } else {
                jsBridge.callNativeHandler('updateTitleAutomatically')
            }
            console.log('设置header配置结束-----')
        }, 0)
    }
}

export default thsJsBridge

// function callNativeHandler(a, b, c) {
//   window.WebViewJavascriptBridge
//     ? void 0 !== c
//       ? window.WebViewJavascriptBridge.callHandler(a, b, c)
//       : window.WebViewJavascriptBridge.callHandler(a, b)
//     : document.addEventListener(
//         'WebViewJavascriptBridgeReady',
//         function () {
//           void 0 !== c ? window.WebViewJavascriptBridge.callHandler(a, b, c) : window.WebViewJavascriptBridge.callHandler(a, b)
//         },
//         !1
//       )
// }
// function registerWebHandler(a, b) {
//   window.WebViewJavascriptBridge
//     ? window.WebViewJavascriptBridge.registerHandler(a, b)
//     : document.addEventListener(
//         'WebViewJavascriptBridgeReady',
//         function () {
//           window.WebViewJavascriptBridge.registerHandler(a, b)
//         },
//         !1
//       )
// }
// function registerWebHandlerRepeated(a, b, c) {
//   try {
//     if ((window.nativeRepeated || (window.nativeRepeated = {}), window.nativeRepeated[a]))
//       return window.nativeRepeated[a][b] ? window.nativeRepeated[a][b].push(c) : (window.nativeRepeated[a][b] = [c]), !1
//     ;(window.nativeRepeated[a] = {}),
//       (window.nativeRepeated[a][b] = [c]),
//       window.WebViewJavascriptBridge
//         ? window.WebViewJavascriptBridge.registerHandler(a, function (b) {
//             var c = b.method || b.key
//             if (c && window.nativeRepeated[a][c] && '[object Array]' === Object.prototype.toString.call(window.nativeRepeated[a][c]))
//               for (var d = 0; d < window.nativeRepeated[a][c].length; d++) window.nativeRepeated[a][c][d](b)
//           })
//         : document.addEventListener(
//             'WebViewJavascriptBridgeReady',
//             function () {
//               window.WebViewJavascriptBridge.registerHandler(a, function (b) {
//                 var c = b.method || b.key
//                 if (c && window.nativeRepeated[a][c] && '[object Array]' === Object.prototype.toString.call(window.nativeRepeated[a][c]))
//                   for (var d = 0; d < window.nativeRepeated[a][c].length; d++) window.nativeRepeated[a][c][d](b)
//               })
//             },
//             !1
//           )
//   } catch (a) {}
// }
// function registerWebListener(a, b) {
//   try {
//     window.WebViewJavascriptBridge
//       ? window.WebViewJavascriptBridge.registerListener(a, b)
//       : document.addEventListener(
//           'WebViewJavascriptBridgeReady',
//           function () {
//             window.WebViewJavascriptBridge.registerListener(a, b)
//           },
//           !1
//         )
//   } catch (a) {}
// }
// function connectWebViewJavascriptBridge() {
//   if (window.WebViewJavascriptBridge) window.WebViewJavascriptBridge.init(initWebViewJavascriptBridge)
//   else {
//     document.addEventListener(
//       'WebViewJavascriptBridgeReady',
//       function () {
//         window.WebViewJavascriptBridge.init(initWebViewJavascriptBridge)
//       },
//       !1
//     )
//     try {
//       var a = {
//         versions: (function () {
//           var a = navigator.userAgent
//           navigator.appVersion
//           return { iPhone: a.indexOf('iPhone') > -1 || a.indexOf('Mac') > -1, iPad: a.indexOf('iPad') > -1 }
//         })(),
//         // @ts-ignore
//         language: (navigator.browserLanguage || navigator.language).toLowerCase(),
//       }
//       if (a.versions.iPhone || a.versions.iPad) var b = 'iphone'
//       else var b = 'gphone'
//       if ('iphone' === b) {
//         var c = document.createElement('iframe')
//         ;(c.style.display = 'none'),
//           (c.src = 'wvjbscheme://__BRIDGE_LOADED__'),
//           document.documentElement.appendChild(c),
//           setTimeout(function () {
//             document.documentElement.removeChild(c)
//           }, 0)
//       }
//     } catch (a) {}
//   }
// }
// function initWebViewJavascriptBridge(a, b) {
//   console.log('message:' + a), console.log('callback:' + b)
// }

// connectWebViewJavascriptBridge()
// export default thsJsBridge
