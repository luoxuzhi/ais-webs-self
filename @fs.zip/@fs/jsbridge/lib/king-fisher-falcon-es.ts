/* eslint-disable prefer-rest-params */
/* eslint-disable no-var */
/* eslint-disable vars-on-top */
// @ts-nocheck

import e from './king-fisher-bridge-es'
var n = function (e, t) {
    return (
        (n =
            Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array &&
                function (e, n) {
                    e.__proto__ = n
                }) ||
            function (e, n) {
                for (var t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t])
            }),
        n(e, t)
    )
}
function t(e, t) {
    if ('function' !== typeof t && null !== t) throw new TypeError('Class extends value ' + String(t) + ' is not a constructor or null')
    function o() {
        this.constructor = e
    }
    n(e, t), (e.prototype = null === t ? Object.create(t) : ((o.prototype = t.prototype), new o()))
}
var o,
    c = function () {
        return (
            (c =
                Object.assign ||
                function (e) {
                    for (var n, t = 1, o = arguments.length; t < o; t++)
                        for (var c in (n = arguments[t])) Object.prototype.hasOwnProperty.call(n, c) && (e[c] = n[c])
                    return e
                }),
            c.apply(this, arguments)
        )
    }
function a(e, n) {
    var t = {}
    for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && n.indexOf(o) < 0 && (t[o] = e[o])
    if (null != e && 'function' === typeof Object.getOwnPropertySymbols) {
        var c = 0
        for (o = Object.getOwnPropertySymbols(e); c < o.length; c++)
            n.indexOf(o[c]) < 0 && Object.prototype.propertyIsEnumerable.call(e, o[c]) && (t[o[c]] = e[o[c]])
    }
    return t
}
!(function (e) {
    ;(e.windowResize = 'windowResize'),
        (e.themeChange = 'themeChange'),
        (e.appShow = 'appShow'),
        (e.appHide = 'appHide'),
        (e.networkStatusChange = 'networkStatusChange'),
        (e.keyboardHeightChange = 'keyboardHeightChange'),
        (e.memoryWarning = 'memoryWarning'),
        (e.userCaptureScreen = 'userCaptureScreen'),
        (e.onCreate = 'onCreate'),
        (e.onDestroy = 'onDestroy'),
        (e.onAppear = 'onAppear'),
        (e.onDisappear = 'onDisappear'),
        (e.onBack = 'onBack'),
        (e.customEvent = 'customEvent'),
        (e.hqAuthSuccess = 'hqAuthSuccess')
})(o || (o = {}))
var r,
    i = (function (e) {
        return {
            onWindowResize: function (n) {
                e.registerEventHandler(o.windowResize, [], n)
            },
            offWindowResize: function (n) {
                e.unregisterEventHandler(o.windowResize, [], n)
            },
            onThemeChange: function (n) {
                e.registerEventHandler(o.themeChange, [], n)
            },
            onAppShow: function (n) {
                e.registerEventHandler(o.appShow, [], n)
            },
            onAppHide: function (n) {
                e.registerEventHandler(o.appHide, [], n)
            },
            onKeyboardHeightChange: function (n) {
                e.registerEventHandler(o.keyboardHeightChange, [], n)
            },
            onMemoryWarning: function (n) {
                e.registerEventHandler(o.memoryWarning, [], n)
            },
            onUserCaptureScreen: function (n) {
                e.registerEventHandler(o.userCaptureScreen, [], n)
            },
            onNetworkStatusChange: function (n) {
                e.registerEventHandler(o.networkStatusChange, [], n)
            },
            onCreate: function (n) {
                e.registerEventHandler(o.onCreate, [], n)
            },
            onDestroy: function (n) {
                e.registerEventHandler(o.onDestroy, [], n)
            },
            onAppear: function (n) {
                e.registerEventHandler(o.onAppear, [], n)
            },
            onDisappear: function (n) {
                e.registerEventHandler(o.onDisappear, [], n)
            },
            onBack: function (n) {
                e.registerEventHandler(o.onBack, [], n)
            },
            onCustomEvent: function (n) {
                e.registerEventHandler(o.customEvent, [], n)
            },
            offThemeChange: function (n) {
                e.unregisterEventHandler(o.themeChange, [], n)
            },
            offAppShow: function (n) {
                e.unregisterEventHandler(o.appShow, [], n)
            },
            offAppHide: function (n) {
                e.unregisterEventHandler(o.appHide, [], n)
            },
            offKeyboardHeightChange: function (n) {
                e.unregisterEventHandler(o.keyboardHeightChange, [], n)
            },
            offMemoryWarning: function (n) {
                e.unregisterEventHandler(o.memoryWarning, [], n)
            },
            offUserCaptureScreen: function (n) {
                e.unregisterEventHandler(o.userCaptureScreen, [], n)
            },
            offNetworkStatusChange: function (n) {
                e.unregisterEventHandler(o.networkStatusChange, [], n)
            },
            offCreate: function (n) {
                e.unregisterEventHandler(o.onCreate, [], n)
            },
            offDestroy: function (n) {
                e.unregisterEventHandler(o.onDestroy, [], n)
            },
            offAppear: function (n) {
                e.unregisterEventHandler(o.onAppear, [], n)
            },
            offDisappear: function (n) {
                e.unregisterEventHandler(o.onDisappear, [], n)
            },
            offBack: function (n) {
                e.unregisterEventHandler(o.onBack, [], n)
            },
            offCustomEvent: function (n) {
                e.unregisterEventHandler(o.customEvent, [], n)
            },
        }
    })(e),
    l = function () {
        return String(Math.random()).slice(-6) + String(+new Date()).slice(-6)
    }
function s(e, n) {
    var t = n || {},
        o = t.success,
        c = t.fail,
        a = t.complete,
        i = e.errCode,
        l = e.data
    i !== r.SUCCESS ? (c && c(e), a && a(e)) : (o && o(null != l ? l : e), a && a(null != l ? l : e))
}
function u(e) {
    var n = e.errCode,
        t = e.data
    if (n !== r.SUCCESS) throw new Error('errCode:' + e.errCode + '\n' + e.errMsg)
    return t
}
!(function (e) {
    ;(e[(e.SUCCESS = 0)] = 'SUCCESS'),
        (e[(e.CANCEL = 1)] = 'CANCEL'),
        (e[(e.SYSTEM_PERMISSION_DENIED = 3)] = 'SYSTEM_PERMISSION_DENIED'),
        (e[(e.INTERNAL_ERROR = 4)] = 'INTERNAL_ERROR'),
        (e[(e.TIME_OUT = 5)] = 'TIME_OUT'),
        (e[(e.JS_API_NOT_SUPPORTED = 100)] = 'JS_API_NOT_SUPPORTED'),
        (e[(e.JS_API_INVALID_REQUEST_DATA = 101)] = 'JS_API_INVALID_REQUEST_DATA'),
        (e[(e.JS_API_HAS_NO_PERMISSION = 102)] = 'JS_API_HAS_NO_PERMISSION'),
        (e[(e.JS_API_USER_AUTHORIZE_DENIED = 103)] = 'JS_API_USER_AUTHORIZE_DENIED'),
        (e[(e.JS_API_USER_AUTHORIZE_CANCELED = 104)] = 'JS_API_USER_AUTHORIZE_CANCELED'),
        (e[(e.INVALID_JS_API_INDEX = 106)] = 'INVALID_JS_API_INDEX'),
        (e[(e.SERVER_SYSTEM_ERROR = 1e3)] = 'SERVER_SYSTEM_ERROR'),
        (e[(e.INVALID_REQUEST_PARAMETER = 1001)] = 'INVALID_REQUEST_PARAMETER'),
        (e[(e.EMPTY_REQUEST = 1002)] = 'EMPTY_REQUEST'),
        (e[(e.MEET_SERVER_FREQUENCY_LIMIT = 1003)] = 'MEET_SERVER_FREQUENCY_LIMIT'),
        (e[(e.INVALID_OPENID = 1004)] = 'INVALID_OPENID'),
        (e[(e.INVALID_APPID = 1005)] = 'INVALID_APPID'),
        (e[(e.INSERT_DATA_FAILED = 1006)] = 'INSERT_DATA_FAILED'),
        (e[(e.GET_NO_DATA = 1007)] = 'GET_NO_DATA'),
        (e[(e.UPDATE_DATA_FAILED = 1008)] = 'UPDATE_DATA_FAILED'),
        (e[(e.DATA_EXPIRED = 1009)] = 'DATA_EXPIRED'),
        (e[(e.DATA_DELETED = 1010)] = 'DATA_DELETED'),
        (e[(e.INVALID_USER = 1011)] = 'INVALID_USER'),
        (e[(e.API_NEED_POST_METHOD = 1012)] = 'API_NEED_POST_METHOD'),
        (e[(e.API_NEED_GET_METHOD = 1013)] = 'API_NEED_GET_METHOD'),
        (e[(e.INVALID_USER_TICKET = 1014)] = 'INVALID_USER_TICKET'),
        (e[(e.INVALID_API = 1015)] = 'INVALID_API'),
        (e[(e.NO_WEBSOCKET_CONN_INFO = 1016)] = 'NO_WEBSOCKET_CONN_INFO'),
        (e[(e.MEN_ERR = 1017)] = 'MEN_ERR'),
        (e[(e.DUPLICATED_UUID = 1018)] = 'DUPLICATED_UUID'),
        (e[(e.NOT_FRIEND = 1019)] = 'NOT_FRIEND'),
        (e[(e.CODE_ALREADY_USED = 1020)] = 'CODE_ALREADY_USED'),
        (e[(e.CODE_EXPIRED = 1021)] = 'CODE_EXPIRED'),
        (e[(e.INVALID_JSON = 1022)] = 'INVALID_JSON'),
        (e[(e.INVALID_STATE = 1023)] = 'INVALID_STATE'),
        (e[(e.JSON_PARSE_ERROR = 100001)] = 'JSON_PARSE_ERROR'),
        (e[(e.APPLY_UPDATE_HAS_BEEN_CALLED = 103101)] = 'APPLY_UPDATE_HAS_BEEN_CALLED'),
        (e[(e.UPDATE_IS_NOT_READY = 103102)] = 'UPDATE_IS_NOT_READY'),
        (e[(e.INVALID_RANDOM_VALUE_LENGTH = 109001)] = 'INVALID_RANDOM_VALUE_LENGTH'),
        (e[(e.UNKNOWN_NETWORK_ERROR = 6e5)] = 'UNKNOWN_NETWORK_ERROR'),
        (e[(e.CRONET_COMPONENT_ERROR = 600001)] = 'CRONET_COMPONENT_ERROR'),
        (e[(e.URL_NOT_IN_DOMAIN_LIST = 600002)] = 'URL_NOT_IN_DOMAIN_LIST'),
        (e[(e.NETWORK_INTERRUPTED_ERROR = 600003)] = 'NETWORK_INTERRUPTED_ERROR'),
        (e[(e.NETWORK_LOGIC_ERROR = 600004)] = 'NETWORK_LOGIC_ERROR'),
        (e[(e.NETWORK_ARGV_ERROR = 600005)] = 'NETWORK_ARGV_ERROR'),
        (e[(e.NETWORK_SYSTEM_ERROR = 600006)] = 'NETWORK_SYSTEM_ERROR'),
        (e[(e.NETWORK_EXCEED_MAX_TASK_COUNT = 600007)] = 'NETWORK_EXCEED_MAX_TASK_COUNT'),
        (e[(e.NETWORK_REACH_THE_MAX_REDIRECT_COUNT = 600008)] = 'NETWORK_REACH_THE_MAX_REDIRECT_COUNT'),
        (e[(e.INVALID_URL = 600009)] = 'INVALID_URL'),
        (e[(e.INVALID_REQUEST_DATA = 600010)] = 'INVALID_REQUEST_DATA'),
        (e[(e.UNKNOWN_NETWORK_REQUEST_ERROR = 602e3)] = 'UNKNOWN_NETWORK_REQUEST_ERROR'),
        (e[(e.REQUEST_SYSTEM_ERROR = 602001)] = 'REQUEST_SYSTEM_ERROR'),
        (e[(e.REQUEST_SERVER_HTTP_ERROR = 602002)] = 'REQUEST_SERVER_HTTP_ERROR'),
        (e[(e.NOT_BUY_HTTP_DNS_SERVICE = 602101)] = 'NOT_BUY_HTTP_DNS_SERVICE'),
        (e[(e.SERVICE_EXPIRED = 602102)] = 'SERVICE_EXPIRED'),
        (e[(e.NOT_ENOUGH_HTTP_DNS_QUOTA = 602103)] = 'NOT_ENOUGH_HTTP_DNS_QUOTA'),
        (e[(e.EMPTY_SERVICER_RETURN = 602104)] = 'EMPTY_SERVICER_RETURN'),
        (e[(e.TIME_OUT_WHEN_REQUEST_SERVICER = 602105)] = 'TIME_OUT_WHEN_REQUEST_SERVICER'),
        (e[(e.INVALID_SERVICER_RESPONSE = 602106)] = 'INVALID_SERVICER_RESPONSE'),
        (e[(e.EMPTY_DOMAIN_HTTP_DNS_RESULT = 602107)] = 'EMPTY_DOMAIN_HTTP_DNS_RESULT'),
        (e[(e.NOT_VALID_SERVICE_ID = 602108)] = 'NOT_VALID_SERVICE_ID'),
        (e[(e.CONVERT_NATIVE_BUFFER_PARAMETER_FAIL = 602300)] = 'CONVERT_NATIVE_BUFFER_PARAMETER_FAIL'),
        (e[(e.BIND_SOCKET_DEPENDENCY_IS_UNAVAILABLE = 602301)] = 'BIND_SOCKET_DEPENDENCY_IS_UNAVAILABLE'),
        (e[(e.RESPONSE_DATA_CONVERT_TO_UTF8_FAIL = 602302)] = 'RESPONSE_DATA_CONVERT_TO_UTF8_FAIL'),
        (e[(e.DOWNLOAD_SAVE_FILE_ERROR = 603300)] = 'DOWNLOAD_SAVE_FILE_ERROR'),
        (e[(e.EXCEED_MAX_FILE_SIZE = 603301)] = 'EXCEED_MAX_FILE_SIZE'),
        (e[(e.FILE_DATA_IS_EMPTY = 603302)] = 'FILE_DATA_IS_EMPTY'),
        (e[(e.PERMISSION_DENIED_CAN_NOT_OPEN_FILE = 603303)] = 'PERMISSION_DENIED_CAN_NOT_OPEN_FILE'),
        (e[(e.DELETE_FILE_ERROR = 603304)] = 'DELETE_FILE_ERROR'),
        (e[(e.MDNS_RESOLVE_SYSTEM_ERROR = 606101)] = 'MDNS_RESOLVE_SYSTEM_ERROR'),
        (e[(e.USER_CANCELED_CHOOSE_MEDIA = 1102701)] = 'USER_CANCELED_CHOOSE_MEDIA'),
        (e[(e.CHOOSE_MEDIA_FAILED = 1102702)] = 'CHOOSE_MEDIA_FAILED'),
        (e[(e.MAYBE_NOT_OPEN_GPS = 1505003)] = 'MAYBE_NOT_OPEN_GPS'),
        (e[(e.MAYBE_NOT_OBTAIN_GPS_PERMISSION = 1505004)] = 'MAYBE_NOT_OBTAIN_GPS_PERMISSION')
})(r || (r = {}))
var f = function () {
        this.instanceId = ''.concat(this.constructor.name, '_').concat(l())
    },
    p = function () {
        this.instanceId = ''.concat(this.constructor.name, '_').concat(l())
    },
    E = (function (e) {
        return {
            addPhoneCalendar: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('addPhoneCalendar', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            addPhoneRepeatCalendar: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('addPhoneRepeatCalendar', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
        }
    })(e),
    d = (function (e) {
        var n = (function (n) {
            function o() {
                return (null !== n && n.apply(this, arguments)) || this
            }
            return (
                t(o, n),
                (o.prototype.dateFormatter = function (n) {
                    return e.callNativeHandlerObjSync(o.componentName, 'dateFormatter', [n], this.instanceId)
                }),
                (o.prototype.stringFromTimestamp = function (n) {
                    return u(e.callNativeHandlerObjSync(o.componentName, 'stringFromTimestamp', [n], this.instanceId))
                }),
                (o.prototype.destroy = function () {
                    e.removeComponent(o.componentName, this.instanceId)
                }),
                (o.componentName = 'DateFormatter'),
                o
            )
        })(p)
        return {
            removeComponent: function (n, t) {
                e.removeComponent(n, t)
            },
            removeComponents: function (n) {
                e.removeComponents(n)
            },
            getClipboardData: function (n) {
                e.callNativeHandlerAsync('getClipboardData', [], function (e) {
                    s(c(c({}, e), { data: { data: e.data } }), n)
                })
            },
            setClipboardData: function (n) {
                e.callNativeHandlerAsync('setClipboardData', [n.data], function (e) {
                    s(e, n)
                })
            },
            vibrateShort: function (n) {
                e.callNativeHandlerAsync('vibrateShort', [null == n ? void 0 : n.type], function (e) {
                    s(e, n)
                })
            },
            vibrateLong: function (n) {
                e.callNativeHandlerAsync('vibrateLong', [], function (e) {
                    s(e, n || {})
                })
            },
            getLocation: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('getLocation', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            getNetworkType: function (n) {
                e.callNativeHandlerAsync('getNetworkType', [], function (e) {
                    s(e, n)
                })
            },
            dateFormatter: function (e) {
                var t = new n()
                return t.dateFormatter(e), t
            },
        }
    })(e),
    N = (function (e) {
        var n = (function (n) {
            function o() {
                return (null !== n && n.apply(this, arguments)) || this
            }
            return (
                t(o, n),
                (o.prototype.offHeadersReceived = function (e) {
                    throw new Error()
                }),
                (o.prototype.offProgressUpdate = function (e) {
                    throw new Error()
                }),
                (o.prototype.onHeadersReceived = function (e) {
                    throw new Error()
                }),
                (o.prototype.onProgressUpdate = function (e) {
                    throw new Error()
                }),
                (o.prototype.downloadFile = function (e) {
                    this.callInstanceMethod('downloadFile', e)
                }),
                (o.prototype.abort = function () {
                    return this.callInstanceMethodSync('abort')
                }),
                (o.prototype.callInstanceMethod = function (n, t) {
                    var c = t.success,
                        r = t.fail,
                        i = t.complete,
                        l = a(t, ['success', 'fail', 'complete'])
                    e.callNativeHandlerObj(
                        o.componentName,
                        n,
                        [l],
                        function (e) {
                            s(e, { success: c, fail: r, complete: i })
                        },
                        this.instanceId
                    )
                }),
                (o.prototype.callInstanceMethodSync = function (n, t) {
                    return void 0 === t && (t = []), e.callNativeHandlerObjSync(o.componentName, n, t, this.instanceId)
                }),
                (o.componentName = 'DownloadFile'),
                o
            )
        })(f)
        return {
            downloadFile: function (e) {
                var t = new n()
                return t.downloadFile(e), t
            },
        }
    })(e),
    _ = (function (e) {
        var n = (function (n) {
                function o() {
                    return (null !== n && n.apply(this, arguments)) || this
                }
                return (
                    t(o, n),
                    (o.prototype.readdirSync = function (e) {
                        return this.callInstanceMethodSync('readdirSync', [e])
                    }),
                    (o.prototype.access = function (e) {
                        this.callInstanceMethod('access', e)
                    }),
                    (o.prototype.accessSync = function (e) {
                        this.callInstanceMethodSync('accessSync', [e])
                    }),
                    (o.prototype.appendFile = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.appendFileSync = function (e, n, t) {
                        throw new Error()
                    }),
                    (o.prototype.close = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.copyFile = function (e) {
                        this.callInstanceMethod('copyFile', e)
                    }),
                    (o.prototype.fstat = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.ftruncate = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.getFileInfo = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.getSavedFileList = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.mkdir = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.mkdirSync = function (e, n) {
                        throw new Error()
                    }),
                    (o.prototype.open = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.read = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.readZipEntry = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.readdir = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.rmdir = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.rmdirSync = function (e, n) {
                        throw new Error()
                    }),
                    (o.prototype.stat = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.truncate = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.unlink = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.unlinkSync = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.unzip = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.write = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.readSync = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.fstatSync = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.statSync = function (e, n) {
                        throw new Error()
                    }),
                    (o.prototype.writeSync = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.openSync = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.closeSync = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.ftruncateSync = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.truncateSync = function (e) {
                        throw new Error()
                    }),
                    (o.prototype.readFile = function (n) {
                        var t = n.success,
                            c = n.fail,
                            i = n.complete,
                            l = a(n, ['success', 'fail', 'complete'])
                        e.callNativeHandlerObj(
                            o.componentName,
                            'readFile',
                            [l],
                            function (e) {
                                var n = e.errCode,
                                    o = e.data
                                if (n !== r.SUCCESS) c && c(e), i && i(e)
                                else {
                                    if (Array.isArray(o)) {
                                        var a = new Uint8Array(o).buffer
                                        e.data = a
                                    }
                                    t && t(e), i && i(e)
                                }
                            },
                            this.instanceId
                        )
                    }),
                    (o.prototype.rename = function (e) {
                        this.callInstanceMethod('rename', e)
                    }),
                    (o.prototype.saveFile = function (n) {
                        var t = n.success,
                            c = n.fail,
                            i = n.complete,
                            l = a(n, ['success', 'fail', 'complete'])
                        e.callNativeHandlerObj(
                            o.componentName,
                            'saveFile',
                            [l],
                            function (e) {
                                if (e.errCode !== r.SUCCESS) c && c(e), i && i(e)
                                else {
                                    var n = { savedFilePath: e.data, errMsg: e.errMsg }
                                    t && t(n), i && i(n)
                                }
                            },
                            this.instanceId
                        )
                    }),
                    (o.prototype.writeFile = function (e) {
                        var n = e
                        e.data instanceof ArrayBuffer && ((n.buffer = Array.from(new Uint8Array(e.data))), (e.data = '')),
                            this.callInstanceMethod('writeFile', n)
                    }),
                    (o.prototype.removeSavedFile = function (e) {
                        this.callInstanceMethod('removeSavedFile', e)
                    }),
                    (o.prototype.copyFileSync = function (e, n) {
                        this.callInstanceMethodSync('copyFileSync', [e, n])
                    }),
                    (o.prototype.readFileSync = function (e, n) {
                        var t = [e]
                        void 0 !== n && t.push(n)
                        var o = this.callInstanceMethodSync('readFileSync', t).data
                        return Array.isArray(o) ? new Uint8Array(o).buffer : o
                    }),
                    (o.prototype.renameSync = function (e, n) {
                        this.callInstanceMethodSync('renameSync', [e, n])
                    }),
                    (o.prototype.saveFileSync = function (e, n) {
                        return this.callInstanceMethodSync('saveFileSync', [e, n]).data
                    }),
                    (o.prototype.writeFileSync = function (e, n, t) {
                        var o = []
                        if ((o.push(e), n instanceof ArrayBuffer)) {
                            var c = Array.from(new Uint8Array(n))
                            o.push(null), o.push(c)
                        } else o.push(n), o.push(null)
                        void 0 !== t && o.push(t), this.callInstanceMethodSync('writeFileSync', o)
                    }),
                    (o.prototype.callInstanceMethod = function (n, t) {
                        var c = t.success,
                            r = t.fail,
                            i = t.complete,
                            l = a(t, ['success', 'fail', 'complete'])
                        e.callNativeHandlerObj(
                            o.componentName,
                            n,
                            [l],
                            function (e) {
                                s(e, { success: c, fail: r, complete: i })
                            },
                            this.instanceId
                        )
                    }),
                    (o.prototype.callInstanceMethodSync = function (n, t) {
                        void 0 === t && (t = [])
                        var c = e.callNativeHandlerObjSync(o.componentName, n, t, this.instanceId)
                        if (0 != c.errCode) throw new Error(c.errMsg)
                        return c
                    }),
                    (o.componentName = 'FileSystemManager'),
                    o
                )
            })(f),
            o = new n()
        return {
            getFileSystemManager: function () {
                return o
            },
        }
    })(e),
    A = (function (e) {
        var n = (function (n) {
                function o() {
                    return (null !== n && n.apply(this, arguments)) || this
                }
                return (
                    t(o, n),
                    (o.prototype.destroy = function () {
                        this.abort({}), e.removeComponent(o.componentName, this.instanceId)
                    }),
                    (o.prototype.abort = function (n) {
                        this.callbackId && e.removeCallback(this.callbackId), this.callInstanceMethod('abort', n)
                    }),
                    (o.prototype.request = function (e) {
                        this.callbackId = this.callInstanceMethod('request', e)
                    }),
                    (o.prototype.callInstanceMethod = function (n, t) {
                        var c = t.success,
                            r = t.fail,
                            i = t.complete,
                            l = a(t, ['success', 'fail', 'complete'])
                        return e.callNativeHandlerObj(
                            o.componentName,
                            n,
                            [l],
                            function (e) {
                                s(e, { success: c, fail: r, complete: i })
                            },
                            this.instanceId,
                            !0
                        )
                    }),
                    (o.prototype.callInstanceMethodSync = function (n, t) {
                        return void 0 === t && (t = []), e.callNativeHandlerObjSync(o.componentName, n, t, this.instanceId)
                    }),
                    (o.componentName = 'UnifiedRequest'),
                    o
                )
            })(f),
            r = (function (n) {
                function o() {
                    return (null !== n && n.apply(this, arguments)) || this
                }
                return (
                    t(o, n),
                    (o.prototype.destroy = function () {
                        this.cancel({}), e.removeComponent(o.componentName, this.instanceId)
                    }),
                    (o.prototype.cancel = function (n) {
                        this.callbackId && e.removeCallback(this.callbackId), this.callInstanceMethod('cancel', n)
                    }),
                    (o.prototype.request = function (e) {
                        this.callbackId = this.callInstanceMethod('request', e)
                    }),
                    (o.prototype.callInstanceMethod = function (n, t) {
                        var c = t.success,
                            r = t.fail,
                            i = t.complete,
                            l = a(t, ['success', 'fail', 'complete'])
                        return e.callNativeHandlerObj(
                            o.componentName,
                            n,
                            [l],
                            function (e) {
                                s(e, { success: c, fail: r, complete: i })
                            },
                            this.instanceId,
                            !0
                        )
                    }),
                    (o.prototype.callInstanceMethodSync = function (n, t) {
                        return void 0 === t && (t = []), e.callNativeHandlerObjSync(o.componentName, n, t, this.instanceId)
                    }),
                    (o.componentName = 'RealTimeDataRequest'),
                    o
                )
            })(f)
        return {
            isHqConnected: function (n) {
                e.callNativeHandlerAsync('isHqConnected', [], function (e) {
                    var t = e.data,
                        o = a(e, ['data'])
                    s(c(c({}, o), { data: Boolean(t) }), n)
                })
            },
            unifiedRequest: function (e) {
                var t = new n()
                return t.request(e), t
            },
            realTimeDataRequest: function (e) {
                var n = new r()
                return n.request(e), n
            },
            onHqAuthSuccess: function (n) {
                e.registerEventHandler(o.hqAuthSuccess, [], n)
            },
            offHqAuthSuccess: function (n) {
                e.unregisterEventHandler(o.hqAuthSuccess, [], n)
            },
        }
    })(e),
    S = (function (e) {
        var n = (function (n) {
            function o() {
                var e = (null !== n && n.apply(this, arguments)) || this
                return (e.componentName = ''), e
            }
            return (
                t(o, n),
                (o.prototype.destroy = function () {
                    e.removeComponent(this.componentName, this.instanceId)
                }),
                (o.prototype.removeCallback = function () {
                    this.callbackId && e.removeCallback(this.callbackId)
                }),
                (o.prototype.callInstanceMethod = function (n, t) {
                    var o = t.success,
                        c = t.fail,
                        r = t.complete,
                        i = a(t, ['success', 'fail', 'complete'])
                    e.callNativeHandlerObj(
                        this.componentName,
                        n,
                        [i],
                        function (e) {
                            s(e, { success: o, fail: c, complete: r })
                        },
                        this.instanceId
                    )
                }),
                (o.prototype.callOnInstanceMethod = function (n, t) {
                    var o = t.success,
                        c = t.fail,
                        r = t.complete,
                        i = a(t, ['success', 'fail', 'complete'])
                    return e.callNativeHandlerObj(
                        this.componentName,
                        n,
                        [i],
                        function (e) {
                            s(e, { success: o, fail: c, complete: r })
                        },
                        this.instanceId,
                        !0
                    )
                }),
                o
            )
        })(f)
        return {
            selfCodeAction: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('selfCodeAction', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            selfFundAction: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('selfFundAction', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            getHostUserInfo: function (n) {
                e.callNativeHandlerAsync('getHostUserInfo', [], function (e) {
                    s(e, n)
                })
            },
            login: function (n) {
                e.callNativeHandlerAsync('login', [], function (e) {
                    s(e, n)
                })
            },
            share: function (n) {
                n.success, n.fail, n.complete
                var t = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('share', [t], function (e) {
                    s(e, n)
                })
            },
            getHostDeviceInfo: function (n) {
                e.callNativeHandlerAsync('getHostDeviceInfo', [], function (e) {
                    s(e, n)
                })
            },
            isGrayReleaseOn: function (n) {
                e.callNativeHandlerAsync('isGrayReleaseOn', [n], function (e) {
                    s(e, n)
                })
            },
            isTransactionLogin: function (n) {
                e.callNativeHandlerAsync('isTransactionLogin', [n], function (e) {
                    s(e, n)
                })
            },
            getEventTracingRefers: function (n) {
                e.callNativeHandlerAsync('getEventTracingRefers', [n], function (e) {
                    s(e, n)
                })
            },
            reportEventTracing: function (n) {
                e.callNativeHandlerAsync('reportEventTracing', [n], function (e) {
                    s(e, n)
                })
            },
            hasAccountWithBroker: function (n) {
                e.callNativeHandlerAsync('hasAccountWithBroker', [n], function (e) {
                    s(e, n)
                })
            },
            showCollectDialog: function (n) {
                e.callNativeHandlerAsync('showCollectDialog', [n], function (e) {
                    s(e, n)
                })
            },
            showBottomSheet: function (n) {
                e.callNativeHandlerAsync('showBottomSheet', [n], function (e) {
                    s(e, n)
                })
            },
            hideBottomSheet: function (n) {
                e.callNativeHandlerAsync('hideBottomSheet', [n], function (e) {
                    s(e, n)
                })
            },
            onPageContentLoaded: function (n) {
                e.callNativeHandlerAsync('onPageContentLoaded', [n], function (e) {
                    s(e, n)
                })
            },
            eventCaptureRecord: function (n) {
                0 != n.isAutoSign && (n.isAutoSign = !0),
                    e.callNativeHandlerAsync('eventCaptureRecord', [n], function (e) {
                        s(e, n)
                    })
            },
            getUserData: function (n) {
                e.callNativeHandlerAsync('getUserData', [n], function (e) {
                    s(e, n)
                })
            },
            getAppData: function (n) {
                e.callNativeHandlerAsync('getAppData', [n], function (e) {
                    s(e, n)
                })
            },
            isShowNews: function (n) {
                e.callNativeHandlerAsync('isShowNews', [n], function (e) {
                    s(e, n)
                })
            },
            showNewsOfVictory: function (n) {
                e.callNativeHandlerAsync('showNewsOfVictory', [n], function (e) {
                    s(e, n)
                })
            },
            getClientBackupsDNS: function (n) {
                e.callNativeHandlerAsync('getClientBackupsDNS', [n], function (e) {
                    s(e, n)
                })
            },
            contentPublisher: function (n) {
                e.callNativeHandlerAsync('contentPublisher', [n], function (e) {
                    s(e, n)
                })
            },
            jumpKHOneStepAuth: function (n) {
                e.callNativeHandlerAsync('jumpKHOneStepAuth', [n], function (e) {
                    s(e, n)
                })
            },
            logout: function (n) {
                e.callNativeHandlerAsync('logout', [n], function (e) {
                    s(e, n)
                })
            },
            showLoginDialog: function (n) {
                e.callNativeHandlerAsync('showLoginDialog', [n], function (e) {
                    s(e, n)
                })
            },
            callAImeQuery: function (n) {
                e.callNativeHandlerAsync('callAImeQuery', [n], function (e) {
                    s(e, n)
                })
            },
            hideAnyWhereAIme: function (n) {
                e.callNativeHandlerAsync('hideAnyWhereAIme', [n], function (e) {
                    s(e, n)
                })
            },
            showAnyWhereAIme: function (n) {
                e.callNativeHandlerAsync('showAnyWhereAIme', [n], function (e) {
                    s(e, n)
                })
            },
            updateAnyWhereAImeSafeAreaInsets: function (n) {
                e.callNativeHandlerAsync('updateAnyWhereAImeSafeAreaInsets', [n], function (e) {
                    s(e, n)
                })
            },
            checkNativeAbility: function (n) {
                e.callNativeHandlerAsync('checkNativeAbility', [n], function (e) {
                    s(e, n)
                })
            },
            openAppStoreSubscriptions: function (n) {
                e.callNativeHandlerAsync('openAppStoreSubscriptions', [n], function (e) {
                    s(e, n)
                })
            },
            getHkUsTradeConnectType: function (n) {
                e.callNativeHandlerAsync('getHkUsTradeConnectType', [n], function (e) {
                    s(e, n)
                })
            },
            callAuctionTabInteraction: function (n) {
                e.callNativeHandlerAsync('callAuctionTabInteraction', [n], function (e) {
                    s(e, n)
                })
            },
            checkPeriodSupported: function (n) {
                e.callNativeHandlerAsync('checkPeriodSupported', [n], function (e) {
                    s(e, n)
                })
            },
            drawLineShareSuccessNotify: function (n) {
                e.callNativeHandlerAsync('drawLineShareSuccessNotify', [n], function (e) {
                    s(e, n)
                })
            },
            getDrawLineConfigInfo: function (n) {
                e.callNativeHandlerAsync('getDrawLineConfigInfo', [n], function (e) {
                    s(e, n)
                })
            },
            getDrawLineData: function (n) {
                e.callNativeHandlerAsync('getDrawLineData', [n], function (e) {
                    s(e, n)
                })
            },
            updateShareDrawLineData: function (n) {
                e.callNativeHandlerAsync('updateShareDrawLineData', [n], function (e) {
                    s(e, n)
                })
            },
            jumpDrawLinePlan: function (n) {
                e.callNativeHandlerAsync('jumpDrawLinePlan', [n], function (e) {
                    s(e, n)
                })
            },
            downloadAndUseDrawLineData: function (n) {
                e.callNativeHandlerAsync('downloadAndUseDrawLineData', [n], function (e) {
                    s(e, n)
                })
            },
            showBottomDialog: function (n) {
                e.callNativeHandlerAsync('showBottomDialog', [n], function (e) {
                    s(e, n)
                })
            },
            hideBottomDialog: function (n) {
                e.callNativeHandlerAsync('hideBottomDialog', [n], function (e) {
                    s(e, n)
                })
            },
            switchStockPeriod: function (n) {
                e.callNativeHandlerAsync('switchStockPeriod', [n], function (e) {
                    s(e, n)
                })
            },
            testNativeApi: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('testNativeApi', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            setRankConditionName: function (n) {
                e.callNativeHandlerAsync('setRankConditionName', [n], function (e) {
                    s(e, n)
                })
            },
            getRankConditionName: function (n) {
                e.callNativeHandlerAsync('getRankConditionName', [n], function (e) {
                    s(e, n)
                })
            },
            getSecurityPhoneNum: function (n) {
                e.callNativeHandlerAsync('getSecurityPhoneNum', [n], function (e) {
                    s(e, n)
                })
            },
            authPhoneNum: function (n) {
                e.callNativeHandlerAsync('authPhoneNum', [n], function (e) {
                    s(e, n)
                })
            },
            authPhoneNumResult: function (n) {
                e.callNativeHandlerAsync('authPhoneNumResult', [n], function (e) {
                    s(e, n)
                })
            },
            sendHXITRequest: function (n) {
                e.callNativeHandlerAsync('sendHXITRequest', [n], function (e) {
                    s(e, n)
                })
            },
            getSessionId: function (n) {
                n.success, n.fail, n.complete
                var t = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('getSessionId', [t], function (e) {
                    s(e, n)
                })
            },
            FalconHostInstanceAPI: n,
        }
    })(e),
    y = (function (e) {
        return {
            showToast: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('showToast', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            hideToast: function (n) {
                e.callNativeHandlerAsync('hideToast', [], function (e) {
                    s(e, n)
                })
            },
            showModal: function (n) {
                var t = n.success,
                    o = n.fail,
                    r = n.complete,
                    i = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('showModal', [i], function (e) {
                    var n, a, i, l, u
                    s(
                        ((a = (n = e).data),
                        (i = a.confirm),
                        (l = a.cancel),
                        (u = c(c({}, n.data), { confirm: Boolean(i), cancel: Boolean(l) })),
                        c(c({}, n), { data: u })),
                        { success: t, fail: o, complete: r }
                    )
                })
            },
        }
    })(e),
    I = (function (e) {
        return {
            chooseMedia: function (n) {
                var t = n.success,
                    o = n.fail,
                    r = n.complete,
                    i = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('chooseMedia', [i], function (e) {
                    s(
                        (function (e) {
                            if (void 0 === e.data || void 0 === e.data.tempFiles) return e
                            var n = e.data.tempFiles,
                                t = c({ tempFiles: n }, e.data)
                            return c(c({}, e), { data: t })
                        })(e),
                        { success: t, fail: o, complete: r }
                    )
                })
            },
            saveImageToPhotosAlbum: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('saveImageToPhotosAlbum', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
        }
    })(e),
    v = (function (e) {
        return {
            showMoreMenu: function (n) {
                e.callNativeHandlerAsync('showMoreMenu', [], function (e) {
                    s(e, n)
                })
            },
            getMenuConfig: function (n) {
                e.registerEventHandler('getMenuConfig', [], n)
            },
            getCollectState: function (n) {
                e.callNativeHandlerAsync('getCollectState', [], function (e) {
                    s(e, n)
                })
            },
            onClickMenuItem: function (n) {
                e.registerEventHandler('onClickMenuItem', [], n)
            },
            setNavigationBarButtons: function (n) {
                e.callNativeHandlerAsync('setNavigationBarButtons', [n], function (e) {
                    s(e, n)
                })
            },
            setNavigationBarTitle: function (n) {
                e.callNativeHandlerAsync('setNavigationBarTitle', [n], function (e) {
                    s(e, n)
                })
            },
            setNavigationBarColor: function (n) {
                e.callNativeHandlerAsync('setNavigationBarColor', [n], function (e) {
                    s(e, n)
                })
            },
            setNavigationBarStyle: function (n) {
                e.callNativeHandlerAsync('setNavigationBarStyle', [n], function (e) {
                    s(e, n)
                })
            },
            onClickNavigationBarButton: function (n) {
                e.registerEventHandler('onClickNavigationBarButton', [], n)
            },
        }
    })(e),
    m = (function (e) {
        var n = (function (n) {
            function o() {
                return (null !== n && n.apply(this, arguments)) || this
            }
            return (
                t(o, n),
                (o.prototype.offHeadersReceived = function (e) {
                    throw new Error()
                }),
                (o.prototype.onHeadersReceived = function (e) {
                    throw new Error()
                }),
                (o.prototype.request = function (e) {
                    this.callInstanceMethod('request', e)
                }),
                (o.prototype.abort = function () {
                    return this.callInstanceMethodSync('abort')
                }),
                (o.prototype.callInstanceMethod = function (n, t) {
                    var c = t.success,
                        r = t.fail,
                        i = t.complete,
                        l = a(t, ['success', 'fail', 'complete'])
                    e.callNativeHandlerObj(
                        o.componentName,
                        n,
                        [l],
                        function (e) {
                            s(e, { success: c, fail: r, complete: i })
                        },
                        this.instanceId
                    )
                }),
                (o.prototype.callInstanceMethodSync = function (n, t) {
                    return void 0 === t && (t = []), e.callNativeHandlerObjSync(o.componentName, n, t, this.instanceId)
                }),
                (o.componentName = 'Request'),
                o
            )
        })(f)
        return {
            request: function (e) {
                var t = new n()
                return t.request(e), t
            },
        }
    })(e),
    h = (function (e) {
        return {
            navigateBack: function (n) {
                var t = n || {},
                    o = t.success,
                    c = t.fail,
                    r = t.complete,
                    i = a(t, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('navigateBack', [i.delta], function (e) {
                    s(e, { success: o, fail: c, complete: r })
                })
            },
            navigateTo: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('navigateTo', [r.url], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            redirectTo: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('redirectTo', [r.url], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            switchTab: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('switchTab', [r.url], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            jumpNativePage: function (n) {
                e.callNativeHandlerAsync('jumpNativePage', [n.url], function (e) {
                    s(e, n)
                })
            },
            jumpStock: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('jumpStock', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            jumpFund: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('jumpFund', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
            jumpAccountOpening: function (n) {
                n.success, n.fail, n.complete
                var t = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('jumpAccountOpening', [t], function (e) {
                    s(e, n)
                })
            },
            jumpBrokerLogin: function (n) {
                n.success, n.fail, n.complete
                var t = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('jumpBrokerLogin', [t], function (e) {
                    s(e, n)
                })
            },
            jumpCalendar: function (n) {
                e.callNativeHandlerAsync('jumpCalendar', [n], function (e) {
                    s(e, n)
                })
            },
            jumpSetting: function (n) {
                e.callNativeHandlerAsync('jumpSetting', [], function (e) {
                    s(e, n)
                })
            },
            jumpNotificationSetting: function (n) {
                e.callNativeHandlerAsync('jumpNotificationSetting', [], function (e) {
                    s(e, n)
                })
            },
            jumpLogin: function (n) {
                e.callNativeHandlerAsync('jumpLogin', [n], function (e) {
                    s(e, n)
                })
            },
            jumpWeb: function (n) {
                n.success, n.fail, n.complete
                var t = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('jumpWeb', [t], function (e) {
                    s(e, n)
                })
            },
            exitMiniProgram: function (n) {
                e.callNativeHandlerAsync('exitMiniProgram', [], function (e) {
                    s(e, n || {})
                })
            },
            navigateToWeixinMiniProgram: function (n) {
                n.success, n.fail, n.complete
                var t = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('navigateToWeixinMiniProgram', [t], function (e) {
                    s(e, n)
                })
            },
            showTradingAccount: function (n) {
                e.callNativeHandlerAsync('showTradingAccount', [n], function (e) {
                    s(e, n)
                })
            },
        }
    })(e),
    R = (function (e) {
        return {
            getStorageInfoSync: function () {
                return u(e.callNativeHandlerSync('getStorageInfoSync', []))
            },
            setStorageSync: function (n, t) {
                e.callNativeHandlerSync('setStorageSync', [n, t])
            },
            getStorageSync: function (n) {
                return u(e.callNativeHandlerSync('getStorageSync', [n]))
            },
            clearStorageSync: function () {
                e.callNativeHandlerSync('clearStorageSync', [])
            },
            removeStorageSync: function (n) {
                e.callNativeHandlerSync('removeStorageSync', [n])
            },
        }
    })(e),
    T = (function (e) {
        return {
            canIUse: function (n) {
                var t,
                    o =
                        {
                            request: 'Request.request',
                            downloadFile: 'DownloadFile.downloadFile',
                            uploadFile: 'UploadFile.uploadFile',
                            unifiedRequest: 'UnifiedRequest.request',
                            realTimeDataRequest: 'RealTimeDataRequest.request',
                            dateFormatter: 'DateFormatter.stringFromTimestamp',
                        }[n] || n
                return !0 === (null === (t = e.callNativeHandlerSync('canIUse', [o])) || void 0 === t ? void 0 : t.data)
            },
            getAppAuthorizeSetting: function (n) {
                e.callNativeHandlerAsync('getAppAuthorizeSetting', [], function (e) {
                    s(e, n)
                })
            },
            getAppBaseInfo: function () {
                return u(e.callNativeHandlerSync('getAppBaseInfo', []))
            },
            getDeviceInfo: function () {
                return u(e.callNativeHandlerSync('getDeviceInfo', []))
            },
            getWindowInfo: function () {
                return u(e.callNativeHandlerSync('getWindowInfo', []))
            },
            getSystemInfoSync: function () {
                return u(e.callNativeHandlerSync('getSystemInfoSync', []))
            },
        }
    })(e),
    g = (function (e) {
        var n = (function (n) {
            function o() {
                return (null !== n && n.apply(this, arguments)) || this
            }
            return (
                t(o, n),
                (o.prototype.offHeadersReceived = function (e) {
                    throw new Error()
                }),
                (o.prototype.offProgressUpdate = function (e) {
                    throw new Error()
                }),
                (o.prototype.onHeadersReceived = function (e) {
                    throw new Error()
                }),
                (o.prototype.onProgressUpdate = function (e) {
                    throw new Error()
                }),
                (o.prototype.uploadFile = function (e) {
                    this.callInstanceMethod('uploadFile', e)
                }),
                (o.prototype.abort = function () {
                    return this.callInstanceMethodSync('abort')
                }),
                (o.prototype.callInstanceMethod = function (n, t) {
                    var c = t.success,
                        r = t.fail,
                        i = t.complete,
                        l = a(t, ['success', 'fail', 'complete'])
                    e.callNativeHandlerObj(
                        o.componentName,
                        n,
                        [l],
                        function (e) {
                            s(e, { success: c, fail: r, complete: i })
                        },
                        this.instanceId
                    )
                }),
                (o.prototype.callInstanceMethodSync = function (n, t) {
                    return void 0 === t && (t = []), e.callNativeHandlerObjSync(o.componentName, n, t, this.instanceId)
                }),
                (o.componentName = 'UploadFile'),
                o
            )
        })(f)
        return {
            uploadFile: function (e) {
                var t = new n()
                return t.uploadFile(e), t
            },
        }
    })(e),
    D = (function (e) {
        var n = (function (n) {
            function o() {
                return (null !== n && n.apply(this, arguments)) || this
            }
            return (
                t(o, n),
                (o.prototype.callInstanceMethod = function (n, t) {
                    var c = t.success,
                        r = t.fail,
                        i = t.complete,
                        l = a(t, ['success', 'fail', 'complete'])
                    e.callNativeHandlerObj(
                        o.componentName,
                        n,
                        [l],
                        function (e) {
                            s(e, { success: c, fail: r, complete: i })
                        },
                        this.instanceId
                    )
                }),
                (o.prototype.cloudStorage = function (e) {
                    this.callInstanceMethod('cloudStorage', e)
                }),
                (o.prototype.setStorage = function (e) {
                    this.callInstanceMethod('setStorage', e)
                }),
                (o.prototype.getStorage = function (e) {
                    this.callInstanceMethod('getStorage', e)
                }),
                (o.componentName = 'CloudStorage'),
                o
            )
        })(f)
        return {
            cloudStorage: function (e) {
                var t = new n()
                return t.cloudStorage(e), t
            },
        }
    })(e),
    H = (function (e) {
        return {
            openDocument: function (n) {
                var t = n.success,
                    o = n.fail,
                    c = n.complete,
                    r = a(n, ['success', 'fail', 'complete'])
                e.callNativeHandlerAsync('openDocument', [r], function (e) {
                    s(e, { success: t, fail: o, complete: c })
                })
            },
        }
    })(e),
    O = (function (e) {
        return {
            goBack: function (n) {
                e.callNativePromise('goback', n)
                    .then(function (e) {
                        s({ errCode: 0, errMsg: '', data: e }, n)
                    })
                    .catch(function (e) {
                        s({ errCode: 4, errMsg: e, data: null }, n)
                    })
            },
        }
    })(e),
    w = c(c(c(c(c(c(c(c(c(c(c(c(c(c(c(c(c(c({}, i), E), d), N), _), A), S), y), I), v), m), h), R), T), g), D), H), O)
export { w as default }
