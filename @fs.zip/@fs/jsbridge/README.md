# @fs/jsbridge

@fs/jsbridge 是一个公共的 jsbridge 库

---

## 快速开始

### 主页

http://gl.fotechwealth.com.local/H5/common/tree/release/projects/@fs-jsbridge

### 安装

```bash
yarn add @fs/jsbridge
```

### API

[API 文档](http://gl.fotechwealth.com.local/H5/common/tree/release/projects/@fs-jsbridge/doc)
