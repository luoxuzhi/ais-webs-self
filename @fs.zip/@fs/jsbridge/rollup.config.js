// 参考文档：https://www.rollupjs.com/guide/command-line-reference

import ts from 'rollup-plugin-typescript2'
import { terser } from 'rollup-plugin-terser'
import clear from 'rollup-plugin-clear'

export default {
    input: 'index.ts',
    output: [
        {
            // dir: 'dist',
            name: 'fs-jsbridge',
            file: 'dist/fs-jsbridge.umd.js',
            format: 'umd', // 输出类型 (amd, cjs, es, iife, umd, system)
        },
        {
            name: 'fs-jsbridge',
            file: 'dist/fs-jsbridge.esm.js',
            format: 'es', // 输出类型 (amd, cjs, es, iife, umd, system)
        },
    ],
    plugins: [
        clear({
            // 清除文件夹
            targets: ['dist', 'types'],
        }),
        ts(), // ts编译
        terser(), // 压缩
    ],
}
